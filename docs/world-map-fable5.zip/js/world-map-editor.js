/**
 * 世界地図エディタ（admin）
 * 座標: スポットは正規化 (0–1) で保存。地形編集はワールド座標。
 */
import * as THREE from 'three';

const LAYER_ID = 'hirao';
const PERSON_M = 1.7;
const CAR_LEN_M = 4.5;
const CAR_W_M = 1.8;
const CAR_H_M = 1.5;

/** コヌイの路：ゾーン定義（名称は将来変更可） */
const KONUI_LEGACY_ZONE_ID = 'zone-4';
const KONUI_ZONES = [
  {
    id: 'zone-1',
    num: '①',
    name: '約束の地',
    hint: 'ツインコモンズ',
    color: '#6a8ab8',
    tx: 0.04,
    ty: 0.06,
    tw: 0.32,
    th: 0.28,
  },
  {
    id: 'zone-2',
    num: '②',
    name: '緑の子午線',
    hint: '372号',
    color: '#4a7c59',
    tx: 0.28,
    ty: 0.32,
    tw: 0.38,
    th: 0.22,
  },
  {
    id: 'zone-3',
    num: '③',
    name: 'フラワーゲート',
    hint: '花田IC',
    color: '#c9a86a',
    tx: 0.1,
    ty: 0.62,
    tw: 0.44,
    th: 0.22,
  },
  {
    id: 'zone-4',
    num: '④',
    name: 'フォークノード',
    hint: '道の駅・天川',
    color: '#6f9e72',
    tx: 0.58,
    ty: 0.28,
    tw: 0.36,
    th: 0.38,
  },
];

const WORLD_PRESETS = {
  'new-harima': {
    worldId: 'new-harima',
    label: 'ニューハリマ',
    shortLabel: 'ニューハリマ',
    hint: '淡路島〜雪彦山・神戸〜赤穂・瀬戸内海を含む広大なワールド',
    size: 1200,
    seg: 160,
    gridCell: 100,
    metersPerUnit: 240,
    gridLabel: '格子1マス ≈ 数kmほどの感覚',
    riverWidthDefaultMeters: 50,
    riverWidthMaxMeters: 200,
    waterWidthDefaultMeters: 80,
    waterWidthMaxMeters: 200,
    leveeHeightDefaultMeters: 3,
    leveeTopWidthDefaultMeters: 5,
    leveeSlopeWidthDefaultMeters: 30,
    brushRadius: 48,
    orbitDefault: 580,
    planZoomMin: 0.5,
  },
  'hime-memory': {
    worldId: 'hime-memory',
    label: 'ヒメモリの地',
    shortLabel: 'ヒメモリの地',
    hint: 'お城〜市川・花田・天川、西・東の広いエリア',
    size: 3600,
    seg: 200,
    gridCell: 50,
    metersPerUnit: 16,
    gridLabel: '格子1マス ≈ 数百m・町の塊の感覚',
    riverWidthDefaultMeters: 10,
    riverWidthMaxMeters: 200,
    waterWidthDefaultMeters: 30,
    waterWidthMaxMeters: 200,
    leveeHeightDefaultMeters: 2,
    leveeTopWidthDefaultMeters: 4,
    leveeSlopeWidthDefaultMeters: 20,
    brushRadius: 70,
    orbitDefault: 1400,
    planZoomDefault: 2.8,
    planZoomMin: 1.0,
  },
  'konui-michi': {
    worldId: 'konui-michi',
    label: 'コヌイの路',
    shortLabel: 'コヌイの路',
    hint: '花田IC〜道の駅〜ツインコモンズ（半径〜1km圏）',
    size: 500,
    sizeZ: 580,
    mapOffsetZ: 40,
    seg: 480,
    gridCell: 25,
    metersPerUnit: 2,
    gridLabel: '格子1マス ≈ 50m前後の感覚',
    riverWidthDefaultMeters: 12,
    riverWidthMinMeters: 2,
    riverWidthMaxMeters: 60,
    waterWidthDefaultMeters: 30,
    waterWidthMinMeters: 2,
    waterWidthMaxMeters: 60,
    riverDepthDefaultMeters: 1,
    riverWaterLevelDefaultMeters: 2,
    leveeHeightDefaultMeters: 2,
    leveeTopWidthDefaultMeters: 4,
    leveeSlopeWidthDefaultMeters: 15,
    brushRadius: 12,
    orbitDefault: 280,
    guideImage: '../images/konui-guide.png',
    zones: KONUI_ZONES,
    overviewTrace: '../images/konui-guide.png',
    /** ゾーン詳細編集（④の既存データと同じ解像度を維持） */
    zoneDetail: {
      size: 500,
      seg: 480,
      metersPerUnit: 2,
      gridCell: 25,
      orbitDefault: 280,
      brushRadius: 12,
    },
  },
};

const PRESET_ORDER = ['konui-michi', 'hime-memory', 'new-harima'];

const BRUSH_STRENGTH = 1.2;
const RIVER_STRENGTH = 2.8;
const RIVER_WIDTH_MAX = 200;
const WATER_LEVEL_MIN = 0.1; // 水面の高さ(m)＝地表(Y=0)からどれだけ下か（水平な水面）
const WATER_LEVEL_MAX = 8;
const WATER_LEVEL_STEP = 0.1;
const ROAD_WIDTH_MIN = 2;
const ROAD_WIDTH_MAX = 12;
const HIGHWAY_WIDTH_MAX = 50;
const GROUND_BRUSH_MIN = 4;
const GROUND_BRUSH_MAX = 80;
const GROUND_HEIGHT_MIN = 0.5;
const GROUND_HEIGHT_MAX = 6;
const GROUND_HEIGHT_STEP = 0.5;
const GROUND_FLAT_FRACTION = 0.58; // ブラシ中央の平坦な上面の割合
const HIGHWAY_DECK_MIN = 0;
const HIGHWAY_DECK_MAX = 20;
const HIGHWAY_DECK_DEFAULT = 10;
const HIGHWAY_DECK_STEP = 1;
const HIGHWAY_DECK_THICKNESS_M = 1.5;
const HIGHWAY_PILLAR_SPACING_M = 28;
const HIGHWAY_GIRDER_SLICE_M = 4;
const HIGHWAY_GIRDER_WIDTH_RATIO = 0.5;
const HIGHWAY_PLANK_WIDTH_M = 1.0;
const HIGHWAY_PLANK_GAP_M = 0.1;
const HIGHWAY_ELEV_MIN_UNITS = 0.35;
const HIGHWAY_DECK_HEIGHT_RATIO = 0.85;
const MAT_EARTH = 1;
const MAT_GRASS = 2;
const MAT_CONCRETE = 3;
const MAT_ASPHALT = 4;
const MAT_HIGHWAY = 5;

const ROAD_STYLES_KEY = 'banshu_world_map_road_styles_v1';
const DEFAULT_ROAD_STYLES = {
  roadColor: '#858c94',
  highwayColor: '#c9b07a',
  highwayGirderColor: '#5c636b',
  highwayOutline: true,
  highwayDeckMeters: HIGHWAY_DECK_DEFAULT,
};

const TREE_HEIGHT_MIN = 1;
const TREE_HEIGHT_MAX = 20;
const TREE_CROWN_MIN = 1;
const TREE_CROWN_MAX = 15;
const TREE_BRUSH_MIN = 2;
const TREE_BRUSH_MAX = 40;
const DEFAULT_TREE_FOLIAGE = '#4a7c4e';
const DEFAULT_TREE_TRUNK = '#6b4423';

const TOOL_SETTINGS_TITLES = {
  dig: '川を掘る',
  water: '水を流す',
  ground: '地面を盛る',
  road: '道路',
  highway: '幹線道路',
  tree: '植生',
  raise: '山を盛る',
  lower: 'へこます',
  erase: '消す',
  area: 'エリア塗る',
};

function toolHasSettingsPanel(t) {
  return (
    t === 'dig' ||
    t === 'water' ||
    t === 'ground' ||
    t === 'road' ||
    t === 'highway' ||
    t === 'tree' ||
    t === 'raise' ||
    t === 'lower' ||
    t === 'erase' ||
    t === 'area'
  );
}

const ORBIT_KEY_STEP = 5;
const AZIMUTH_KEY_STEP = 0.035;
const POLAR_MIN = 0.12;
const POLAR_MAX = 1.48;
const ALTITUDE_MIN = -140;
const ALTITUDE_MAX = 220;
const ALTITUDE_KEY_STEP = 4;
const POLAR_KEY_STEP = 0.022;
const PLAN_ZOOM_MIN = 0.35;
const PLAN_ZOOM_MAX = 48;
const PLAN_ZOOM_KEY_STEP = 0.045;
const ZOOM_FACTOR_KEY = 0.965; // 1フレームあたりの倍率（指数ズーム。1未満で寄る）
const PLAN_ZOOM_FACTOR_KEY = 1.035;

const HEIGHT_BANDS = [
  { max: 8, label: '平地', css: '#8a9e6e' },
  { max: 22, label: '低い丘', css: '#9a8a5c' },
  { max: 40, label: '播磨の山', css: '#a67a45' },
  { max: 9999, label: '高め', css: '#c9a86a' },
];

const AREA_PALETTE = ['#c9a574', '#8fad7a', '#7a9eb8', '#b88a9a', '#a890c4', '#d4a05c', '#8a8a9e'];

export function initWorldMapEditor({ supabase, onStatus, readOnly = false, defaultPreset = null }) {
  const app = document.getElementById('world-map-app');
  if (!app) return;

  if (readOnly) {
    document.body.classList.add('world-map-readonly');
  }

  const panel = document.getElementById('world-map-panel');
  const spotbox = document.getElementById('world-map-spotbox');
  const nameInput = document.getElementById('world-map-spot-name');
  const slugInput = document.getElementById('world-map-spot-slug');
  const spotDeleteBtn = document.getElementById('world-map-spot-delete');
  const spotCancelBtn = document.getElementById('world-map-spot-cancel');
  const loadingEl = document.getElementById('world-map-loading');
  const minimapEl = document.getElementById('world-map-minimap');
  const minimapCanvas = document.getElementById('world-map-minimap-canvas');
  const minimapDot = document.getElementById('world-map-minimap-dot');
  const minimapOpenBtn = document.getElementById('world-map-minimap-open');
  const minimapModal = document.getElementById('world-map-minimap-modal');
  const minimapModalCanvas = document.getElementById('world-map-minimap-modal-canvas');
  const minimapModalDot = document.getElementById('world-map-minimap-modal-dot');
  const minimapModalClose = document.getElementById('world-map-minimap-close');
  const minimapModalBackdrop = document.getElementById('world-map-minimap-backdrop');
  const minimapModalSceneFrame = document.getElementById('world-map-minimap-modal-scene');
  const minimapModalOverviewFrame = document.getElementById('world-map-minimap-modal-overview');
  const overviewModalCanvas = document.getElementById('world-map-overview-modal-canvas');
  const overviewModalHighlight = document.getElementById('world-map-overview-modal-highlight');
  const overviewContextDot = document.getElementById('world-map-zone-context-dot');
  const overviewModalDot = document.getElementById('world-map-overview-modal-dot');
  const minimapModalTitle = document.getElementById('world-map-minimap-modal-title');
  const minimapModalHint = document.getElementById('world-map-minimap-modal-hint');
  const zoneContextOpenBtn = document.getElementById('world-map-zone-context-open');
  const shirasagiWrap = document.getElementById('world-map-shirasagi-wrap');
  const shirasagiImg = document.getElementById('world-map-shirasagi');

  const W = () => app.clientWidth;
  const H = () => app.clientHeight;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0xe9e1d2);
  scene.fog = null;

  const perspCamera = new THREE.PerspectiveCamera(48, W() / H(), 0.1, 12000);
  const orthoCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 20000);
  let activeCamera = perspCamera;
  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(W(), H());
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.domElement.classList.add('world-map-gl');
  app.appendChild(renderer.domElement);

  const minimapCamera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 20000);
  let minimapRenderer = null;
  let minimapModalRenderer = null;
  let overviewModalRenderer = null;
  let minimapModalOpen = false;
  let minimapModalMode = 'scene';
  const MINIMAP_PX = 188;
  const MINIMAP_MODAL_PX = 480;

  if (minimapCanvas) {
    minimapRenderer = new THREE.WebGLRenderer({
      canvas: minimapCanvas,
      antialias: true,
      alpha: false,
      powerPreference: 'low-power',
    });
    minimapRenderer.setClearColor(0xe9e1d2, 1);
  }

  scene.add(new THREE.HemisphereLight(0xfff4e0, 0x6b5b40, 1.0));
  const sun = new THREE.DirectionalLight(0xfff0d8, 0.8);
  sun.position.set(120, 180, 80);
  scene.add(sun);

  const guideTextureLoader = new THREE.TextureLoader();
  let guidePlane = null;
  let guideVisible = !readOnly;
  let guideOpacity = 0.5;
  let viewMode = '3d';

  let currentPresetId = defaultPreset || (readOnly ? 'hime-memory' : 'konui-michi');
  const bootParams = new URLSearchParams(location.search);
  const bootMapParam = bootParams.get('map');
  const bootZoneParam = bootParams.get('zone');
  if (bootMapParam && WORLD_PRESETS[bootMapParam]) {
    currentPresetId = bootMapParam;
  }
  /** コヌイの路：選択中ゾーン（null = 俯瞰） */
  let currentZoneId = null;
  let konuiOverviewMode = false;
  let overviewState = null;
  let zoneMarkerGroup = null;
  let overviewMiniScene = null;
  let overviewMiniLand = null;
  let overviewPlanRenderer = null;
  const OVERVIEW_CTX_PX = 188;
  let SIZE;
  let SIZE_X;
  let SIZE_Z;
  let MAP_OFFSET_Z;
  let SEG;
  let GRID_CELL;
  let WORLD_ID;
  let N;
  let brushRadius;
  let tool = 'look';
  let brushMeters;
  let riverBrushRadius;
  let riverWidthMeters;
  let waterBrushRadius;
  let waterWidthMeters;
  let riverDepthMeters;
  let riverWaterLevelMeters;
  let digMaterial = MAT_CONCRETE;
  let groundBrushMeters;
  let groundBrushRadius;
  let groundHeightMeters;
  let roadWidthMeters;
  let roadBrushRadius;
  let roadStyles = { ...DEFAULT_ROAD_STYLES };
  let highwayDeckMeters = HIGHWAY_DECK_DEFAULT;
  let highwayDeckH;
  let highwayViaductGroup = null;
  let treeHeightMeters = 5;
  let treeCrownMeters = 3;
  let treeShape = 'round';
  let treeFoliageColor = DEFAULT_TREE_FOLIAGE;
  let treeTrunkColor = DEFAULT_TREE_TRUNK;
  let treeBrushMeters = 8;
  let treeBrushRadius = 4;
  let treeEraseMode = false;
  let nextTreeId = 1;
  let toolSettingsOpen = true;
  let geo;
  let pos;
  let heights;
  let water;
  let waterY; // セル毎の水面の高さ（ワールド単位・絶対Y）
  let groundMat; // 0=自動 1=土 2=草 3=コンクリ(薄灰) 4=アスファルト(道)
  let areaGrid;
  let areas = [];
  let currentAreaId = 0;
  let colAttr;
  let land;
  let wireMesh;
  let gridHelper;
  let scaleMarkerGroup;
  let margin;
  let riverPreview = null;
  let shirasagiShadow = null;

  function ensureShirasagiShadow() {
    if (shirasagiShadow) return;
    const cv = document.createElement('canvas');
    cv.width = cv.height = 128;
    const g = cv.getContext('2d');
    const grad = g.createRadialGradient(64, 64, 4, 64, 64, 62);
    grad.addColorStop(0, 'rgba(18, 26, 14, 0.5)');
    grad.addColorStop(0.55, 'rgba(18, 26, 14, 0.26)');
    grad.addColorStop(1, 'rgba(18, 26, 14, 0)');
    g.fillStyle = grad;
    g.fillRect(0, 0, 128, 128);
    const tex = new THREE.CanvasTexture(cv);
    tex.colorSpace = THREE.SRGBColorSpace;
    shirasagiShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(1, 1),
      new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false }),
    );
    shirasagiShadow.rotation.x = -Math.PI / 2;
    shirasagiShadow.renderOrder = 4;
    shirasagiShadow.visible = false;
    scene.add(shirasagiShadow);
  }

  /** 白鷺の地表からの高度（ワールド単位）。W/Sで上下、最低限は地面すれすれ */
  function heronAltUnits() {
    const base = SIZE * 0.04;
    const v = base + altitudeOffset * 0.5;
    return Math.max(SIZE * 0.012, Math.min(SIZE * 0.7, v));
  }

  function updateShirasagiShadow() {
    if (!shirasagiShadow) return;
    if (viewMode !== '3d') {
      shirasagiShadow.visible = false;
      return;
    }
    const gy = groundY(target.x, target.z);
    shirasagiShadow.position.set(target.x, gy + 0.25, target.z);
    // 高度が高いほど影は小さく薄く（＝影の大きさで高度がわかる）
    const altRatio = heronAltUnits() / (SIZE * 0.5);
    const r0 = Math.max(3, SIZE * 0.015);
    const r = r0 / (1 + altRatio * 1.4);
    shirasagiShadow.scale.set(r, r, 1);
    shirasagiShadow.material.opacity = Math.max(0.12, Math.min(0.6, 0.6 / (1 + altRatio * 1.2)));
    shirasagiShadow.material.transparent = true;
    shirasagiShadow.visible = true;
  }

  const _heronAnchor = new THREE.Vector3();

  /** 白鷺の向き：ドラッグ/Q/E で変わる azimuth のみ（十字キー移動では変えない） */
  function heronTiltRad() {
    if (viewMode !== '3d') return 0;
    return -azimuth;
  }

  /** 白鷺アバターを影の真上に投影配置。ズームで大きさが変わる（寄ると大・引くと小） */
  function updateShirasagiAvatar() {
    if (!shirasagiWrap) return;
    // 平面（地図）モードでは白鷺アイコンは出さない
    if (viewMode !== '3d') {
      shirasagiWrap.style.opacity = '0';
      return;
    }
    const gy = groundY(target.x, target.z);
    _heronAnchor.set(target.x, gy + heronAltUnits(), target.z);
    const v = _heronAnchor.clone().project(activeCamera);
    const onScreen = v.z < 1 && v.x > -1.4 && v.x < 1.4 && v.y > -1.4 && v.y < 1.4;
    if (!onScreen) {
      shirasagiWrap.style.opacity = '0';
      return;
    }
    const sx = (v.x * 0.5 + 0.5) * W();
    const sy = (-v.y * 0.5 + 0.5) * H();
    let scale;
    let fade;
    if (viewMode === 'plan') {
      scale = Math.max(0.4, Math.min(3.2, planZoom * 0.42));
      // 平面でも寄りすぎたら邪魔なので薄く
      fade = 1 - (planZoom - PLAN_ZOOM_MAX * 0.45) / (PLAN_ZOOM_MAX * 0.35);
    } else {
      const dist = perspCamera.position.distanceTo(_heronAnchor);
      scale = Math.max(0.35, Math.min(3.2, (SIZE * 0.45) / Math.max(1, dist)));
      // 寄る（orbitが小さい）ほど白鷺を薄く→作業の邪魔にならない
      const fadeStart = SIZE * 0.22;
      const fadeEnd = SIZE * 0.1;
      fade = (orbit - fadeEnd) / (fadeStart - fadeEnd);
    }
    fade = Math.max(0, Math.min(1, fade));
    const rot = viewMode === '3d' ? `rotate(${heronTiltRad()}rad)` : '';
    shirasagiWrap.style.opacity = String(fade);
    shirasagiWrap.style.left = sx + 'px';
    shirasagiWrap.style.top = sy + 'px';
    shirasagiWrap.style.transform = `translate(-50%, -50%) ${rot} scale(${scale})`;
  }

  function ensureRiverPreview() {
    if (riverPreview) return;
    riverPreview = new THREE.Mesh(
      new THREE.RingGeometry(0.88, 1, 56),
      new THREE.MeshBasicMaterial({
        color: 0x4a8ab8,
        transparent: true,
        opacity: 0.42,
        side: THREE.DoubleSide,
        depthWrite: false,
      }),
    );
    riverPreview.rotation.x = -Math.PI / 2;
    riverPreview.visible = false;
    scene.add(riverPreview);
  }

  function previewToolActive() {
    return (
      tool === 'dig' ||
      tool === 'water' ||
      tool === 'ground' ||
      tool === 'road' ||
      tool === 'highway' ||
      tool === 'tree' ||
      tool === 'raise' ||
      tool === 'lower' ||
      tool === 'erase'
    );
  }

  function activeBrushRadius() {
    if (tool === 'dig') return riverSculptRadius();
    if (tool === 'water') return waterSculptRadius();
    if (tool === 'ground') return groundSculptRadius();
    if (tool === 'road' || tool === 'highway') return roadSculptRadius();
    if (tool === 'tree') return treeBrushRadius;
    return brushRadius;
  }

  function previewColorHexForTool() {
    if (tool === 'highway') return roadStyles.highwayColor;
    if (tool === 'road') return roadStyles.roadColor;
    return null;
  }

  function previewColorForTool() {
    const hex = previewColorHexForTool();
    if (hex) return parseInt(hex.replace('#', ''), 16);
    if (tool === 'erase') return 0xc05a4a;
    if (tool === 'raise' || tool === 'lower') return 0xc08a3a;
    if (tool === 'ground') return 0x6f8f4e;
    if (tool === 'tree') return parseInt((treeFoliageColor || DEFAULT_TREE_FOLIAGE).replace('#', ''), 16);
    return 0x4a8ab8;
  }

  function updateRiverPreviewScale() {
    if (!riverPreview) return;
    const r = activeBrushRadius();
    riverPreview.scale.set(r, r, 1);
  }

  function updateRiverPreview(p) {
    if (!riverPreview || readOnly || !previewToolActive() || painting || draggingSpot) {
      if (riverPreview) riverPreview.visible = false;
      return;
    }
    if (!p) {
      riverPreview.visible = false;
      return;
    }
    riverPreview.material.color.setHex(previewColorForTool());
    riverPreview.visible = true;
    const y = groundY(p.x, p.z) + 0.9;
    riverPreview.position.set(p.x, y, p.z);
    updateRiverPreviewScale();
  }

  function hideRiverPreview() {
    if (riverPreview) riverPreview.visible = false;
  }

  function riverRadiusFromMeters(m) {
    return Math.max(0.03, m / 2 / preset().metersPerUnit);
  }

  function brushMaxMeters() {
    // マップの実寸（おおよそ）の3割くらいまで。最低でも80m。
    return Math.max(80, Math.round(SIZE * preset().metersPerUnit * 0.3));
  }

  function syncBrushRadiusFromMeters() {
    brushRadius = Math.max(0.05, brushMeters / 2 / preset().metersPerUnit);
  }

  function terrainCellSize() {
    return Math.min(SIZE_X, SIZE_Z) / SEG;
  }

  /** コヌイの路 (500) を基準に、大きいマップでも凹凸が見えるようスケール */
  function reliefScale() {
    return Math.sqrt(SIZE / 500);
  }

  function brushStrength() {
    return BRUSH_STRENGTH * reliefScale();
  }

  /** 地面を盛る：目標高さの断面（山のような加算はしない） */
  function groundTargetHeight(d, radius) {
    const targetH = metersToUnits(groundHeightMeters);
    if (targetH <= 0) return null;
    const t = d / Math.max(0.001, radius);
    if (t > 1) return null;
    if (t <= GROUND_FLAT_FRACTION) return targetH;
    const u = (t - GROUND_FLAT_FRACTION) / (1 - GROUND_FLAT_FRACTION);
    const ease = 0.5 * (1 + Math.cos(Math.PI * u));
    return targetH * ease;
  }

  function isElevatedHighwayCell(i) {
    const fullDeck = metersToUnits(highwayDeckMeters);
    return (
      groundMat[i] === MAT_HIGHWAY &&
      fullDeck > HIGHWAY_ELEV_MIN_UNITS &&
      highwayDeckH[i] >= fullDeck * HIGHWAY_DECK_HEIGHT_RATIO &&
      highwayDeckH[i] > heights[i] + HIGHWAY_ELEV_MIN_UNITS
    );
  }

  /** 旧データの段差付き路面高を、平坦な設計高さに揃える */
  function snapHighwayDeckHeights() {
    const full = metersToUnits(highwayDeckMeters);
    if (full <= HIGHWAY_ELEV_MIN_UNITS) return;
    for (let i = 0; i < N; i++) {
      if (groundMat[i] !== MAT_HIGHWAY) {
        highwayDeckH[i] = 0;
        continue;
      }
      if (highwayDeckH[i] >= full * HIGHWAY_DECK_HEIGHT_RATIO) {
        highwayDeckH[i] = full;
      } else if (highwayDeckH[i] > 0) {
        highwayDeckH[i] = 0;
      }
    }
  }

  function riverDepthUnits() {
    // 実寸の深さ(m)をワールド単位へ。幅とは独立。
    const depthM = riverDepthMeters ?? preset().riverDepthDefaultMeters ?? 1;
    return depthM / preset().metersPerUnit;
  }

  function riverDepthTarget(f) {
    // f: 中心=1, 岸=0 のなだらかな椀形
    return -(riverDepthUnits() * f);
  }

  function metersToUnits(m) {
    return m / preset().metersPerUnit;
  }

  function digSculptRadius() {
    const cell = terrainCellSize();
    return Math.max(riverBrushRadius, cell * 0.55);
  }

  /** 地形頂点の間隔より細い川幅でも、必ず頂点に当たるよう補正した半径 */
  function riverSculptRadius() {
    return digSculptRadius();
  }

  function syncGroundRadiusFromMeters() {
    groundBrushRadius = Math.max(0.05, groundBrushMeters / 2 / preset().metersPerUnit);
  }

  function roadWidthMaxMeters() {
    return tool === 'highway' ? HIGHWAY_WIDTH_MAX : ROAD_WIDTH_MAX;
  }

  function syncRoadRadiusFromMeters() {
    roadBrushRadius = riverRadiusFromMeters(roadWidthMeters);
  }

  function groundSculptRadius() {
    const cell = terrainCellSize();
    return Math.max(groundBrushRadius, cell * 0.55);
  }

  function roadSculptRadius() {
    const cell = terrainCellSize();
    return Math.max(roadBrushRadius, cell * 0.55);
  }

  function groundBrushMaxMeters() {
    return Math.min(GROUND_BRUSH_MAX, Math.max(GROUND_BRUSH_MIN, Math.round(SIZE * preset().metersPerUnit * 0.12)));
  }

  function syncRiverRadiusFromMeters() {
    riverBrushRadius = riverRadiusFromMeters(riverWidthMeters);
  }

  function syncWaterRadiusFromMeters() {
    waterBrushRadius = riverRadiusFromMeters(waterWidthMeters);
  }

  /** 水を流す：川幅とは別に、塗りブラシの幅を設定できる */
  function waterSculptRadius() {
    const cell = terrainCellSize();
    return Math.max(waterBrushRadius, cell * 0.55);
  }

  function waterWidthMaxMeters() {
    const p = preset();
    return Math.min(RIVER_WIDTH_MAX, p.waterWidthMaxMeters ?? p.riverWidthMaxMeters ?? RIVER_WIDTH_MAX);
  }

  function waterWidthMinMeters() {
    return preset().waterWidthMinMeters ?? preset().riverWidthMinMeters ?? 2;
  }

  function applyPanPixels(dx, dy) {
    const scale = panDragScale() * 0.55;
    const mx = -dx * scale;
    const mz = -dy * scale;
    // 平面ビューは北向き固定なので回転を掛けない
    const ang = viewMode === 'plan' ? 0 : azimuth;
    const c = Math.cos(ang);
    const s = Math.sin(ang);
    target.x += mx * c - mz * s;
    target.z += mx * s + mz * c;
  }

  function panDragScale() {
    if (viewMode === 'plan') {
      return (SIZE / planZoom) / Math.min(W(), H());
    }
    return (orbit * 0.85) / Math.min(W(), H());
  }

  function preset() {
    return WORLD_PRESETS[currentPresetId];
  }

  function konuiZones() {
    return preset().zones || null;
  }

  function isKonuiZoned() {
    return currentPresetId === 'konui-michi' && !!konuiZones()?.length;
  }

  function isKonuiOverview() {
    return isKonuiZoned() && konuiOverviewMode && !currentZoneId;
  }

  /** コヌイの路：全体平面ビュー用（1km四方） */
  function overviewSpec() {
    const p = preset();
    return {
      size: p.size,
      sizeZ: p.sizeZ,
      mapOffsetZ: p.mapOffsetZ,
      seg: p.seg,
      gridCell: p.gridCell,
      metersPerUnit: p.metersPerUnit,
      orbitDefault: p.orbitDefault,
      brushRadius: p.brushRadius,
      gridLabel: p.gridLabel,
    };
  }

  function applyMapSizesFromSpec() {
    const p = terrainSpec();
    SIZE_X = p.sizeX ?? p.size;
    SIZE_Z = p.sizeZ ?? p.size;
    MAP_OFFSET_Z = p.mapOffsetZ ?? 0;
    SIZE = Math.max(SIZE_X, SIZE_Z);
  }

  function mapBoundX() {
    return { min: -SIZE_X / 2, max: SIZE_X / 2 };
  }

  function mapBoundZ() {
    return { min: -SIZE_Z / 2 + MAP_OFFSET_Z, max: SIZE_Z / 2 + MAP_OFFSET_Z };
  }

  function clampMapX(x) {
    const b = mapBoundX();
    return Math.max(b.min + margin, Math.min(b.max - margin, x));
  }

  function clampMapZ(z) {
    const b = mapBoundZ();
    return Math.max(b.min + margin, Math.min(b.max - margin, z));
  }

  function gridCoordX(x) {
    return ((x + SIZE_X / 2) / SIZE_X) * SEG;
  }

  function gridCoordZ(z) {
    return ((z - MAP_OFFSET_Z + SIZE_Z / 2) / SIZE_Z) * SEG;
  }

  /** いま編集中の地形パラメータ */
  function terrainSpec() {
    const p = preset();
    if (isKonuiOverview()) return { ...p, ...overviewSpec() };
    if (isKonuiZoned() && currentZoneId && p.zoneDetail) return { ...p, ...p.zoneDetail };
    return p;
  }

  function activeLayerId() {
    if (isKonuiZoned() && currentZoneId) return `${LAYER_ID}-${currentZoneId}`;
    if (isKonuiZoned() && konuiOverviewMode) return `${LAYER_ID}-overview`;
    return LAYER_ID;
  }

  function legacyKonuiLocalKey() {
    return 'banshu_world_map_v3_konui-michi';
  }

  function migrateKonuiLegacyLocal() {
    if (readOnly) return;
    try {
      const base = legacyKonuiLocalKey();
      const legacy = localStorage.getItem(base);
      const z4Key = `${base}_${KONUI_LEGACY_ZONE_ID}`;
      const z1Key = `${base}_zone-1`;
      if (legacy && !localStorage.getItem(z4Key)) {
        localStorage.setItem(z4Key, legacy);
      }
      // 誤って zone-1 へ移した分を ④ へ（④が空のときのみ）
      const z1Data = localStorage.getItem(z1Key);
      if (z1Data && !localStorage.getItem(z4Key)) {
        localStorage.setItem(z4Key, z1Data);
      }
    } catch {
      /* ignore */
    }
  }

  function zoneWorldRect(z) {
    const halfX = SIZE_X / 2;
    const halfZ = SIZE_Z / 2;
    return {
      x0: z.tx * SIZE_X - halfX,
      z0: z.ty * SIZE_Z - halfZ + MAP_OFFSET_Z,
      x1: (z.tx + z.tw) * SIZE_X - halfX,
      z1: (z.ty + z.th) * SIZE_Z - halfZ + MAP_OFFSET_Z,
    };
  }

  function findKonuiZone(id) {
    return (konuiZones() || []).find((z) => z.id === id) || null;
  }

  function currentZoneLabel() {
    const z = findKonuiZone(currentZoneId);
    return z ? `${z.num} ${z.name}` : '';
  }

  function localKey() {
    const base = `banshu_world_map_v3_${WORLD_ID}`;
    if (isKonuiZoned() && currentZoneId) return `${base}_${currentZoneId}`;
    if (isKonuiZoned() && konuiOverviewMode) return `${base}_overview`;
    return base;
  }

  function destroyZoneMarkers() {
    if (!zoneMarkerGroup) return;
    scene.remove(zoneMarkerGroup);
    zoneMarkerGroup.traverse((o) => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) o.material.dispose();
    });
    zoneMarkerGroup = null;
    destroyZoneLinkOverlays();
  }

  const zoneLinkItems = [];

  function zoneOverviewHref() {
    const file = location.pathname.split('/').pop() || 'world-map.html';
    return `${file}?map=konui-michi`;
  }

  function zoneDetailHref(zoneId) {
    const file = location.pathname.split('/').pop() || 'world-map.html';
    return `${file}?map=konui-michi&zone=${encodeURIComponent(zoneId)}`;
  }

  function syncZoneUrl() {
    if (!readOnly) return;
    try {
      const url = new URL(location.href);
      if (isKonuiZoned() && currentZoneId) {
        url.searchParams.set('map', 'konui-michi');
        url.searchParams.set('zone', currentZoneId);
      } else if (currentPresetId === 'konui-michi' && isKonuiOverview()) {
        url.searchParams.set('map', 'konui-michi');
        url.searchParams.delete('zone');
      }
      history.replaceState(null, '', url);
      if (zoneBackBtn && zoneBackBtn.tagName === 'A') {
        zoneBackBtn.href = zoneOverviewHref();
      }
    } catch {
      /* ignore */
    }
  }

  function destroyZoneLinkOverlays() {
    for (const item of zoneLinkItems) item.el.remove();
    zoneLinkItems.length = 0;
  }

  function buildZoneLinkOverlays() {
    destroyZoneLinkOverlays();
    if (!readOnly || !isKonuiOverview() || !konuiZones()) return;
    for (const z of konuiZones()) {
      const a = document.createElement('a');
      a.className = 'world-map-zone-link';
      a.href = zoneDetailHref(z.id);
      a.title = `${z.num} ${z.name} — 立体ビュー`;
      a.setAttribute('aria-label', `${z.num} ${z.name}の立体ビューへ`);
      a.style.setProperty('--zone-color', z.color);
      a.innerHTML = `<span class="world-map-zone-link__label"><span class="world-map-zone-link__num">${z.num}</span><span class="world-map-zone-link__name">${z.name}</span></span>`;
      a.addEventListener('click', (e) => {
        e.preventDefault();
        enterKonuiZone(z.id);
      });
      app.appendChild(a);
      zoneLinkItems.push({ zone: z, el: a });
    }
    updateZoneLinkPositions();
  }

  function updateZoneLinkPositions() {
    if (!readOnly) return;
    for (const item of zoneLinkItems) {
      item.el.style.opacity = '0';
      item.el.style.pointerEvents = 'none';
    }
    if (!zoneLinkItems.length || !isKonuiOverview() || viewMode !== 'plan' || !SIZE_X) return;

    for (const item of zoneLinkItems) {
      const r = zoneWorldRect(item.zone);
      const corners = [
        { x: r.x0, z: r.z0 },
        { x: r.x1, z: r.z0 },
        { x: r.x1, z: r.z1 },
        { x: r.x0, z: r.z1 },
      ];
      const pts = corners.map((p) => {
        const v = new THREE.Vector3(p.x, 1.4, p.z).project(activeCamera);
        return {
          sx: (v.x * 0.5 + 0.5) * W(),
          sy: (-v.y * 0.5 + 0.5) * H(),
          vis: v.z < 1,
        };
      });
      if (!pts.every((p) => p.vis)) continue;
      const xs = pts.map((p) => p.sx);
      const ys = pts.map((p) => p.sy);
      const left = Math.min(...xs);
      const top = Math.min(...ys);
      const width = Math.max(...xs) - left;
      const height = Math.max(...ys) - top;
      item.el.style.left = left + 'px';
      item.el.style.top = top + 'px';
      item.el.style.width = Math.max(28, width) + 'px';
      item.el.style.height = Math.max(28, height) + 'px';
      item.el.style.opacity = '1';
      item.el.style.pointerEvents = 'auto';
    }
  }

  function buildZoneMarkersOnPlan() {
    destroyZoneMarkers();
    if (!isKonuiOverview() || !konuiZones()) return;
    zoneMarkerGroup = new THREE.Group();
    for (const z of konuiZones()) {
      const r = zoneWorldRect(z);
      const y = 1.4;
      const pts = [
        new THREE.Vector3(r.x0, y, r.z0),
        new THREE.Vector3(r.x1, y, r.z0),
        new THREE.Vector3(r.x1, y, r.z1),
        new THREE.Vector3(r.x0, y, r.z1),
        new THREE.Vector3(r.x0, y, r.z0),
      ];
      const lineGeo = new THREE.BufferGeometry().setFromPoints(pts);
      const lineMat = new THREE.LineBasicMaterial({
        color: z.color,
        transparent: true,
        opacity: 0.9,
        depthTest: false,
      });
      const line = new THREE.Line(lineGeo, lineMat);
      line.renderOrder = 1001;
      zoneMarkerGroup.add(line);
    }
    zoneMarkerGroup.visible = viewMode === 'plan';
    scene.add(zoneMarkerGroup);
    buildZoneLinkOverlays();
  }

  function destroyOverviewMiniLand() {
    if (overviewMiniLand && overviewMiniScene) {
      overviewMiniScene.remove(overviewMiniLand);
      overviewMiniLand.geometry.dispose();
      overviewMiniLand.material.dispose();
      overviewMiniLand = null;
    }
  }

  function areaColorFromList(areaList, id) {
    const a = (areaList || []).find((x) => x.id === id);
    if (!a?.color) return null;
    const hex = a.color.replace('#', '');
    return {
      r: parseInt(hex.slice(0, 2), 16) / 255,
      g: parseInt(hex.slice(2, 4), 16) / 255,
      b: parseInt(hex.slice(4, 6), 16) / 255,
    };
  }

  function colorOverviewMiniVertices(col, st) {
    const hArr = st.h;
    const gMat = st.gm || [];
    const aGrid = st.ag || [];
    const areaList = st.a || [];
    for (let i = 0; i < hArr.length; i++) {
      if (gMat[i] > 0) {
        const mc = matColor(gMat[i]);
        col.setXYZ(i, mc.r, mc.g, mc.b);
        continue;
      }
      const y = hArr[i];
      if (y < -0.01) {
        col.setXYZ(i, cCutGray.r, cCutGray.g, cCutGray.b);
        continue;
      }
      if (aGrid[i] > 0) {
        const ac = areaColorFromList(areaList, aGrid[i]);
        if (ac) {
          col.setXYZ(i, ac.r, ac.g, ac.b);
          continue;
        }
      }
      let band = HEIGHT_BANDS[HEIGHT_BANDS.length - 1];
      for (const b of HEIGHT_BANDS) {
        if (y < b.max) {
          band = b;
          break;
        }
      }
      const hex = band.css.replace('#', '');
      col.setXYZ(i, parseInt(hex.slice(0, 2), 16) / 255, parseInt(hex.slice(2, 4), 16) / 255, parseInt(hex.slice(4, 6), 16) / 255);
    }
    col.needsUpdate = true;
  }

  function rebuildOverviewMiniLand() {
    destroyOverviewMiniLand();
    if (!overviewState?.h?.length) return;
    if (!overviewMiniScene) {
      overviewMiniScene = new THREE.Scene();
      overviewMiniScene.background = new THREE.Color(0xe9e1d2);
    }
    const st = overviewState;
    const seg = st.seg;
    const sx = st.sizeX || st.size || preset().size;
    const sz = st.sizeZ || st.size || preset().size;
    const oz = st.oz || 0;
    const geo = new THREE.PlaneGeometry(sx, sz, seg, seg);
    geo.rotateX(-Math.PI / 2);
    const vPos = geo.attributes.position;
    for (let i = 0; i < vPos.count; i++) {
      vPos.setY(i, st.h[i] || 0);
    }
    vPos.needsUpdate = true;
    geo.computeVertexNormals();
    const col = new THREE.Float32BufferAttribute(new Float32Array(vPos.count * 3), 3);
    geo.setAttribute('color', col);
    colorOverviewMiniVertices(col, st);
    overviewMiniLand = new THREE.Mesh(
      geo,
      new THREE.MeshBasicMaterial({ vertexColors: true }),
    );
    overviewMiniLand.position.set(0, 0, oz);
    overviewMiniScene.add(overviewMiniLand);
  }

  function captureOverviewState() {
    if (!heights || !isKonuiOverview()) return;
    overviewState = { ...localPayload(), size: SIZE, sizeX: SIZE_X, sizeZ: SIZE_Z, oz: MAP_OFFSET_Z, seg: SEG };
    rebuildOverviewMiniLand();
  }

  function ensureOverviewPlanRenderer() {
    const canvas = document.getElementById('world-map-zone-context-canvas');
    if (!canvas) return null;
    if (!overviewPlanRenderer) {
      overviewPlanRenderer = new THREE.WebGLRenderer({
        canvas,
        antialias: true,
        alpha: false,
        powerPreference: 'low-power',
      });
      overviewPlanRenderer.setClearColor(0xe9e1d2, 1);
    }
    return overviewPlanRenderer;
  }

  function renderOverviewPlanTo(renderer, px) {
    if (!overviewState || !overviewMiniLand || !renderer) return;
    const sz = overviewState.sizeZ || overviewState.size || preset().size;
    const sx = overviewState.sizeX || overviewState.size || preset().size;
    const span = Math.max(sx, sz);
    const half = span * 0.52;
    minimapCamera.left = -half;
    minimapCamera.right = half;
    minimapCamera.top = half;
    minimapCamera.bottom = -half;
    minimapCamera.position.set(0, span * 0.65, 0);
    minimapCamera.up.set(0, 0, -1);
    minimapCamera.lookAt(0, 0, 0);
    minimapCamera.updateProjectionMatrix();
    const pr = Math.min(window.devicePixelRatio, 2);
    renderer.setPixelRatio(pr);
    renderer.setSize(px, px, false);
    renderer.render(overviewMiniScene, minimapCamera);
  }

  function renderOverviewPlanContext() {
    if (!overviewState || !currentZoneId || viewMode !== '3d') return;
    const r = ensureOverviewPlanRenderer();
    if (!r) return;
    renderOverviewPlanTo(r, OVERVIEW_CTX_PX);
    updateOverviewMinimapDot(overviewContextDot);
    if (minimapModalOpen && minimapModalMode === 'overview') {
      renderOverviewModal();
    }
  }

  function ensureOverviewModalRenderer() {
    if (!overviewModalCanvas) return null;
    if (!overviewModalRenderer) {
      overviewModalRenderer = new THREE.WebGLRenderer({
        canvas: overviewModalCanvas,
        antialias: true,
        alpha: false,
      });
      overviewModalRenderer.setClearColor(0xe9e1d2, 1);
    }
    return overviewModalRenderer;
  }

  function renderOverviewModal() {
    const r = ensureOverviewModalRenderer();
    if (!r) return;
    renderOverviewPlanTo(r, MINIMAP_MODAL_PX);
    syncOverviewModalHighlight();
    updateOverviewMinimapDot(overviewModalDot);
  }

  function syncOverviewModalHighlight() {
    const z = findKonuiZone(currentZoneId);
    if (!overviewModalHighlight || !z) return;
    overviewModalHighlight.style.left = z.tx * 100 + '%';
    overviewModalHighlight.style.top = z.ty * 100 + '%';
    overviewModalHighlight.style.width = z.tw * 100 + '%';
    overviewModalHighlight.style.height = z.th * 100 + '%';
    overviewModalHighlight.style.borderColor = z.color;
    overviewModalHighlight.style.background = z.color + '33';
  }

  function setMinimapModalPanels(mode) {
    if (minimapModalSceneFrame) minimapModalSceneFrame.hidden = mode !== 'scene';
    if (minimapModalOverviewFrame) minimapModalOverviewFrame.hidden = mode !== 'overview';
    if (minimapModalTitle) {
      minimapModalTitle.textContent = mode === 'overview' ? 'コヌイの路 — 全体' : '俯瞰マップ';
    }
    if (minimapModalHint) {
      minimapModalHint.textContent =
        mode === 'overview' ? '赤い点＝白鷺の位置 · 枠＝いまのブロック' : '赤い点＝いまの視点';
    }
  }

  /** ブロック内の target をコヌイ全体平面のワールド座標へ */
  function zoneTargetToOverviewWorld() {
    const z = findKonuiZone(currentZoneId);
    if (!z || !overviewState) return null;
    const osx = overviewState.sizeX || overviewState.size;
    const osz = overviewState.sizeZ || overviewState.size;
    const oz = overviewState.oz || 0;
    const nx = (target.x + SIZE_X / 2) / SIZE_X;
    const nz = (target.z - MAP_OFFSET_Z + SIZE_Z / 2) / SIZE_Z;
    const onx = z.tx + nx * z.tw;
    const onz = z.ty + nz * z.th;
    return {
      x: onx * osx - osx / 2,
      z: onz * osz - osz / 2 + oz,
    };
  }

  function updateOverviewMinimapDot(dotEl) {
    if (!dotEl || !overviewState || !currentZoneId) return;
    const w = zoneTargetToOverviewWorld();
    if (!w) return;
    const osx = overviewState.sizeX || overviewState.size;
    const osz = overviewState.sizeZ || overviewState.size;
    const oz = overviewState.oz || 0;
    dotEl.style.left = ((w.x + osx / 2) / osx) * 100 + '%';
    dotEl.style.top = ((w.z - oz + osz / 2) / osz) * 100 + '%';
  }

  function orbitMin() {
    // かなり地表に寄れるように（小さいマップでもグッと近づける）
    return Math.max(2.5, SIZE * 0.004);
  }

  function orbitMax() {
    return SIZE * 0.95;
  }

  function planZoomMin() {
    const p = preset();
    if (p.planZoomMin != null) return p.planZoomMin;
    return Math.max(0.35, SIZE / 4800);
  }

  function syncCameraFar() {
    const far = SIZE * 2.8;
    perspCamera.far = far;
    perspCamera.updateProjectionMatrix();
    orthoCamera.far = far;
    orthoCamera.updateProjectionMatrix();
  }

  function destroyTerrain() {
    clearSpots();
    clearTrees();
    destroyGuidePlane();
    destroyWaterSurface();
    destroyZoneMarkers();
    destroyHighwayViaduct();
    if (land) {
      scene.remove(land, wireMesh, gridHelper, scaleMarkerGroup);
      geo.dispose();
      land.material.dispose();
      wireMesh.material.dispose();
      gridHelper.geometry.dispose();
      gridHelper.material.dispose();
      scaleMarkerGroup.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) o.material.dispose();
      });
      land = wireMesh = gridHelper = scaleMarkerGroup = null;
    }
  }

  function destroyGuidePlane() {
    if (!guidePlane) return;
    scene.remove(guidePlane);
    guidePlane.geometry.dispose();
    if (guidePlane.material.map) guidePlane.material.map.dispose();
    guidePlane.material.dispose();
    guidePlane = null;
  }

  function zoneTraceStorageKey() {
    if (readOnly || !isKonuiZoned() || !currentZoneId || isKonuiOverview()) return null;
    return `banshu_world_map_zone_trace_v1_${WORLD_ID}_${currentZoneId}`;
  }

  function loadImageFromDataUrl(dataUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = () => reject(new Error('image load failed'));
      img.src = dataUrl;
    });
  }

  /** localStorage 向けに縮小・JPEG圧縮（トレース用なので解像度は控えめで十分） */
  async function compressZoneTraceDataUrl(dataUrl) {
    const img = await loadImageFromDataUrl(dataUrl);
    const MAX_EDGE = 1920;
    const MAX_BYTES = 1_200_000;
    let w = img.naturalWidth || img.width;
    let h = img.naturalHeight || img.height;
    let edgeScale = Math.min(1, MAX_EDGE / Math.max(w, h));
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('canvas unavailable');

    const tryEncode = () => {
      let quality = 0.82;
      let out = canvas.toDataURL('image/jpeg', quality);
      while (out.length > MAX_BYTES && quality > 0.35) {
        quality -= 0.08;
        out = canvas.toDataURL('image/jpeg', quality);
      }
      return out;
    };

    for (let pass = 0; pass < 4; pass += 1) {
      w = Math.max(1, Math.round((img.naturalWidth || img.width) * edgeScale));
      h = Math.max(1, Math.round((img.naturalHeight || img.height) * edgeScale));
      canvas.width = w;
      canvas.height = h;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, w, h);
      ctx.drawImage(img, 0, 0, w, h);
      const out = tryEncode();
      if (out.length <= MAX_BYTES) return out;
      edgeScale *= 0.75;
    }
    return tryEncode();
  }

  function loadZoneTraceFromStorage() {
    try {
      const key = zoneTraceStorageKey();
      if (!key) return null;
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  }

  function saveZoneTraceToStorage(dataUrl) {
    const key = zoneTraceStorageKey();
    if (!key || !dataUrl) return false;
    try {
      localStorage.setItem(key, dataUrl);
      return true;
    } catch {
      return false;
    }
  }

  function clearZoneTraceStorage() {
    const key = zoneTraceStorageKey();
    if (!key) return;
    try {
      localStorage.removeItem(key);
    } catch {
      /* ignore */
    }
  }

  function isZoneTraceMode() {
    return !readOnly && isKonuiZoned() && !!currentZoneId && !isKonuiOverview();
  }

  function shouldShowGuidePanel() {
    if (readOnly) return false;
    if (isKonuiOverview() && preset().guideImage) return true;
    if (isZoneTraceMode()) return true;
    if (!isKonuiZoned() && preset().guideImage) return true;
    return false;
  }

  function activeGuideSource() {
    if (isKonuiOverview() && preset().guideImage) return preset().guideImage;
    if (isZoneTraceMode()) return loadZoneTraceFromStorage();
    if (!isKonuiZoned() && preset().guideImage) return preset().guideImage;
    return null;
  }

  function applyGuideTexture(tex) {
    if (!guidePlane) return;
    tex.colorSpace = THREE.SRGBColorSpace;
    guidePlane.material.map = tex;
    guidePlane.material.needsUpdate = true;
    const iw = tex.image && tex.image.width ? tex.image.width : 1;
    const ih = tex.image && tex.image.height ? tex.image.height : 1;
    const aspect = iw / ih;
    const fieldAspect = SIZE_X / SIZE_Z;
    if (aspect >= fieldAspect) {
      guidePlane.scale.set(1, 1, fieldAspect / aspect);
    } else {
      guidePlane.scale.set(aspect / fieldAspect, 1, 1);
    }
    applyGuideVisibility();
  }

  async function applyZoneTraceImage(dataUrl) {
    if (!isZoneTraceMode()) return false;
    setStatus('下絵を圧縮しています…', 0);
    let compressed;
    try {
      compressed = await compressZoneTraceDataUrl(dataUrl);
    } catch {
      setStatus('下絵の読み込みに失敗しました', 5000);
      return false;
    }
    if (!saveZoneTraceToStorage(compressed)) {
      setStatus('下絵の保存に失敗しました（画像が大きすぎる可能性があります）', 5000);
      return false;
    }
    guideVisible = true;
    buildGuidePlane();
    if (viewMode !== 'plan') setViewMode('plan');
    updateGuideUI();
    const kb = Math.round(compressed.length / 1024);
    setStatus(`下絵を貼り付けました（${kb}KB）— 平面でトレースできます`, 4000);
    return true;
  }

  function buildGuidePlane() {
    destroyGuidePlane();
    const src = activeGuideSource();
    if (!src) {
      updateGuideUI();
      return;
    }
    const geoG = new THREE.PlaneGeometry(SIZE_X, SIZE_Z);
    geoG.rotateX(-Math.PI / 2);
    const mat = new THREE.MeshBasicMaterial({
      transparent: true,
      opacity: guideOpacity,
      depthTest: false,
      depthWrite: false,
    });
    guidePlane = new THREE.Mesh(geoG, mat);
    guidePlane.position.set(0, 4, MAP_OFFSET_Z);
    guidePlane.renderOrder = 999;
    guidePlane.visible = false;
    scene.add(guidePlane);
    if (String(src).startsWith('data:')) {
      guideTextureLoader.load(src, applyGuideTexture, undefined, () => updateGuideUI());
    } else {
      guideTextureLoader.load(src, applyGuideTexture, undefined, () => updateGuideUI());
    }
    applyGuideVisibility();
    updateGuideUI();
  }

  function applyGuideVisibility() {
    if (!guidePlane) return;
    guidePlane.visible = guideVisible && viewMode === 'plan' && !!guidePlane.material.map;
    guidePlane.material.opacity = guideOpacity;
  }

  function updateGuideUI() {
    const wrap = document.getElementById('world-map-guide');
    if (!wrap) return;
    const hasGuide = !!activeGuideSource();
    wrap.hidden = !shouldShowGuidePanel();
    const toggle = document.getElementById('world-map-guide-toggle');
    if (toggle) {
      toggle.classList.toggle('on', guideVisible && hasGuide);
      if (isZoneTraceMode()) {
        toggle.textContent = guideVisible && hasGuide ? '🗺 下絵: 表示' : hasGuide ? '🗺 下絵: 非表示' : '🗺 下絵: 未設定';
      } else {
        toggle.textContent = guideVisible ? '🗺 下絵: 表示' : '🗺 下絵: 非表示';
      }
      toggle.disabled = isZoneTraceMode() && !hasGuide;
    }
    const slider = document.getElementById('world-map-guide-opacity');
    if (slider) {
      slider.value = String(Math.round(guideOpacity * 100));
      slider.disabled = !guideVisible || !hasGuide;
    }
    const uploadWrap = document.getElementById('world-map-zone-trace-upload-wrap');
    const clearBtn = document.getElementById('world-map-zone-trace-clear');
    if (uploadWrap) uploadWrap.hidden = !isZoneTraceMode();
    if (clearBtn) clearBtn.hidden = !isZoneTraceMode() || !hasGuide;
  }

  function buildScaleMarkers() {
    const mpu = preset().metersPerUnit;
    const personH = PERSON_M / mpu;
    const carL = CAR_LEN_M / mpu;
    const carW = CAR_W_M / mpu;
    const carH = CAR_H_M / mpu;
    scaleMarkerGroup = new THREE.Group();
    const personMesh = new THREE.Mesh(
      new THREE.BoxGeometry(personH * 0.35, personH, personH * 0.35),
      new THREE.MeshBasicMaterial({ color: 0x2a2018, transparent: true, opacity: 0.65 }),
    );
    personMesh.position.y = personH / 2;
    const carMesh = new THREE.Mesh(
      new THREE.BoxGeometry(carL, carH, carW),
      new THREE.MeshBasicMaterial({ color: 0x4a4030, transparent: true, opacity: 0.55 }),
    );
    carMesh.position.set(personH * 0.5 + carL / 2 + 2, carH / 2, 0);
    scaleMarkerGroup.add(personMesh);
    scaleMarkerGroup.add(carMesh);
    scene.add(scaleMarkerGroup);
  }

  function updateScaleMarkerPosition() {
    if (!scaleMarkerGroup) return;
    const ox = SIZE * 0.3;
    const oz = SIZE * 0.3;
    const ty = groundY(target.x + ox, target.z + oz);
    scaleMarkerGroup.position.set(target.x + ox, ty + 0.5, target.z + oz);
  }

  function buildTerrain() {
    const p = terrainSpec();
    applyMapSizesFromSpec();
    SEG = p.seg;
    GRID_CELL = p.gridCell;
    WORLD_ID = preset().worldId;
    brushRadius = p.brushRadius ?? preset().brushRadius;
    brushMeters = Math.round(brushRadius * 2 * p.metersPerUnit);
    riverWidthMeters = p.riverWidthDefaultMeters ?? 10;
    waterWidthMeters = p.waterWidthDefaultMeters ?? riverWidthMeters * 2;
    riverDepthMeters = p.riverDepthDefaultMeters ?? 1;
    riverWaterLevelMeters = p.riverWaterLevelDefaultMeters ?? 1;
    digMaterial = MAT_CONCRETE;
    groundBrushMeters = p.groundBrushDefaultMeters ?? p.leveeSlopeWidthDefaultMeters ?? 20;
    groundHeightMeters = p.groundHeightDefaultMeters ?? p.leveeHeightDefaultMeters ?? 2;
    roadWidthMeters = p.roadWidthDefaultMeters ?? p.leveeTopWidthDefaultMeters ?? 4;
    syncRiverRadiusFromMeters();
    syncWaterRadiusFromMeters();
    syncGroundRadiusFromMeters();
    syncRoadRadiusFromMeters();
    syncTreeRadiusFromMeters();
    margin = SIZE * 0.015;
    syncCameraFar();

    geo = new THREE.PlaneGeometry(SIZE_X, SIZE_Z, SEG, SEG);
    geo.rotateX(-Math.PI / 2);
    if (MAP_OFFSET_Z) geo.translate(0, 0, MAP_OFFSET_Z);
    pos = geo.attributes.position;
    N = pos.count;
    heights = new Float32Array(N);
    water = new Float32Array(N);
    waterY = new Float32Array(N);
    groundMat = new Uint8Array(N);
    highwayDeckH = new Float32Array(N);
    areaGrid = new Uint16Array(N);
    areas = [];
    currentAreaId = 0;
    colAttr = new THREE.Float32BufferAttribute(new Float32Array(N * 3), 3);
    geo.setAttribute('color', colAttr);

    land = new THREE.Mesh(
      geo,
      new THREE.MeshStandardMaterial({
        vertexColors: true,
        roughness: 0.95,
        metalness: 0,
        flatShading: false,
      }),
    );
    scene.add(land);
    wireMesh = new THREE.Mesh(
      geo,
      new THREE.MeshBasicMaterial({
        color: 0x3a2c1a,
        wireframe: true,
        transparent: true,
        opacity: 0.05,
      }),
    );
    scene.add(wireMesh);

    const gridSpan = Math.max(SIZE_X, SIZE_Z);
    const gridDivisions = Math.round(gridSpan / GRID_CELL);
    gridHelper = new THREE.GridHelper(gridSpan, gridDivisions, 0x5c4a32, 0x8a7a62);
    gridHelper.material.transparent = true;
    gridHelper.material.opacity = 0.22;
    gridHelper.position.set(0, 0.4, MAP_OFFSET_Z);
    scene.add(gridHelper);

    buildScaleMarkers();
    ensureRiverPreview();
    ensureShirasagiShadow();
    syncRiverBrushUI();
    updateScaleLegend();
    setupMinimapCamera();
    if (isKonuiOverview() || !isKonuiZoned() || isZoneTraceMode()) buildGuidePlane();
    if (isKonuiOverview()) buildZoneMarkersOnPlan();
  }

  if (!isKonuiZoned()) {
    buildTerrain();
  } else {
    WORLD_ID = preset().worldId;
    konuiOverviewMode = true;
  }

  const cLow = new THREE.Color(0x83975a);
  const cMid = new THREE.Color(0x9c7b46);
  const cHigh = new THREE.Color(0xcdbb8c);
  const cCutGray = new THREE.Color(0x8a9098);

  // 地表素材（1=土, 2=草, 3=コンクリ薄灰, 4=アスファルト）
  const cMatEarth = new THREE.Color(0x9c7b4e);
  const cMatGrass = new THREE.Color(0x6f8f4e);
  const cMatConcrete = new THREE.Color(0x9aa0a3);
  const cMatAsphalt = new THREE.Color(0x858c94);
  const cMatHighway = new THREE.Color(0xc9b07a);

  function applyHexToColor(hex, target) {
    const h = (hex || '#888888').replace('#', '');
    if (h.length !== 6) return;
    target.setRGB(
      parseInt(h.slice(0, 2), 16) / 255,
      parseInt(h.slice(2, 4), 16) / 255,
      parseInt(h.slice(4, 6), 16) / 255,
    );
  }

  function loadRoadStyles() {
    try {
      const raw = localStorage.getItem(ROAD_STYLES_KEY);
      if (!raw) return;
      const d = JSON.parse(raw);
      roadStyles = { ...DEFAULT_ROAD_STYLES, ...d };
    } catch {
      roadStyles = { ...DEFAULT_ROAD_STYLES };
    }
    highwayDeckMeters = Math.max(
      HIGHWAY_DECK_MIN,
      Math.min(HIGHWAY_DECK_MAX, roadStyles.highwayDeckMeters ?? HIGHWAY_DECK_DEFAULT),
    );
    roadStyles.highwayDeckMeters = highwayDeckMeters;
    applyHexToColor(roadStyles.roadColor, cMatAsphalt);
    applyHexToColor(roadStyles.highwayColor, cMatHighway);
  }

  function saveRoadStyles() {
    try {
      localStorage.setItem(ROAD_STYLES_KEY, JSON.stringify(roadStyles));
    } catch {
      /* ignore */
    }
  }

  function syncRoadStyleUI() {
    const roadColorInput = document.getElementById('world-map-road-color');
    const highwayColorInput = document.getElementById('world-map-highway-color');
    const girderColorInput = document.getElementById('world-map-highway-girder-color');
    const outlineInput = document.getElementById('world-map-highway-outline');
    const deckSlider = document.getElementById('world-map-highway-deck');
    const deckMetersEl = document.getElementById('world-map-highway-deck-meters');
    if (roadColorInput) roadColorInput.value = roadStyles.roadColor;
    if (highwayColorInput) highwayColorInput.value = roadStyles.highwayColor;
    if (girderColorInput) {
      girderColorInput.value = roadStyles.highwayGirderColor || DEFAULT_ROAD_STYLES.highwayGirderColor;
    }
    if (outlineInput) outlineInput.checked = !!roadStyles.highwayOutline;
    if (deckSlider) {
      deckSlider.min = String(HIGHWAY_DECK_MIN);
      deckSlider.max = String(HIGHWAY_DECK_MAX);
      deckSlider.step = String(HIGHWAY_DECK_STEP);
      deckSlider.value = String(Math.round(highwayDeckMeters));
    }
    if (deckMetersEl) deckMetersEl.textContent = highwayDeckText();
  }

  function matColor(id) {
    if (id === MAT_GRASS) return cMatGrass;
    if (id === MAT_CONCRETE) return cMatConcrete;
    if (id === MAT_ASPHALT) return cMatAsphalt;
    if (id === MAT_HIGHWAY) return cMatHighway;
    return cMatEarth;
  }

  loadRoadStyles();

  // 川の水面（フラットな青い面）。掘った地形(河床・堤防)とは別レイヤーで描く。
  let waterSurfaceMesh = null;
  let waterDirty = false;

  /** 水平な水面の絶対Y（地表0から riverWaterLevelMeters だけ下） */
  function flatWaterSurfaceY() {
    const m = riverWaterLevelMeters ?? 1;
    return -m / preset().metersPerUnit;
  }

  function destroyWaterSurface() {
    if (!waterSurfaceMesh) return;
    scene.remove(waterSurfaceMesh);
    waterSurfaceMesh.geometry.dispose();
    waterSurfaceMesh.material.dispose();
    waterSurfaceMesh = null;
  }

  function rebuildWaterSurface() {
    destroyWaterSurface();
    if (!pos) return;
    const cols = SEG + 1;
    const positions = [];
    const index = [];
    let v = 0;
    for (let gz = 0; gz < SEG; gz++) {
      for (let gx = 0; gx < SEG; gx++) {
        const i00 = gz * cols + gx;
        const i10 = gz * cols + gx + 1;
        const i01 = (gz + 1) * cols + gx;
        const i11 = (gz + 1) * cols + gx + 1;
        const corners = [i00, i10, i01, i11];
        let wsum = 0;
        let wyAcc = 0;
        for (const ci of corners) {
          if (water[ci] > 0.5) {
            wsum++;
            wyAcc += waterY[ci];
          }
        }
        if (wsum < 3) continue;
        // 水面の高さはセル毎の値の平均（川ごとに水位が違ってもOK）
        const wy = wyAcc / wsum;
        positions.push(
          pos.getX(i00), wy, pos.getZ(i00),
          pos.getX(i10), wy, pos.getZ(i10),
          pos.getX(i01), wy, pos.getZ(i01),
          pos.getX(i11), wy, pos.getZ(i11),
        );
        index.push(v, v + 2, v + 1, v + 1, v + 2, v + 3);
        v += 4;
      }
    }
    if (positions.length === 0) return;
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    g.setIndex(index);
    g.computeVertexNormals();
    const mat = new THREE.MeshStandardMaterial({
      color: 0x4f86a6,
      transparent: true,
      opacity: 0.9,
      roughness: 0.25,
      metalness: 0.0,
      side: THREE.DoubleSide,
    });
    waterSurfaceMesh = new THREE.Mesh(g, mat);
    waterSurfaceMesh.renderOrder = 3;
    scene.add(waterSurfaceMesh);
  }

  function clearHighwayViaductMeshes() {
    if (!highwayViaductGroup) return;
    while (highwayViaductGroup.children.length) {
      const ch = highwayViaductGroup.children[0];
      highwayViaductGroup.remove(ch);
      ch.geometry?.dispose();
      if (ch.material) {
        if (Array.isArray(ch.material)) ch.material.forEach((m) => m.dispose());
        else ch.material.dispose();
      }
    }
  }

  function destroyHighwayViaduct() {
    clearHighwayViaductMeshes();
    if (highwayViaductGroup) {
      scene.remove(highwayViaductGroup);
      highwayViaductGroup = null;
    }
  }

  function ensureHighwayViaductGroup() {
    if (highwayViaductGroup) return;
    highwayViaductGroup = new THREE.Group();
    highwayViaductGroup.name = 'highwayViaduct';
    scene.add(highwayViaductGroup);
  }

  function mergeUnitBoxes(boxes) {
    if (!boxes.length) return null;
    const unit = new THREE.BoxGeometry(1, 1, 1);
    const posAttr = unit.getAttribute('position');
    const normAttr = unit.getAttribute('normal');
    const idx = unit.getIndex();
    const positions = [];
    const normals = [];
    const indices = [];
    const m = new THREE.Matrix4();
    const q = new THREE.Quaternion();
    const pos = new THREE.Vector3();
    const scl = new THREE.Vector3();
    const v = new THREE.Vector3();
    const n = new THREE.Vector3();
    let vertexOffset = 0;
    for (const b of boxes) {
      q.setFromAxisAngle(new THREE.Vector3(0, 1, 0), b.rotY || 0);
      scl.set(b.sx, b.sy, b.sz);
      pos.set(b.x, b.y, b.z);
      m.compose(pos, q, scl);
      for (let vi = 0; vi < posAttr.count; vi++) {
        v.set(posAttr.getX(vi), posAttr.getY(vi), posAttr.getZ(vi)).applyMatrix4(m);
        positions.push(v.x, v.y, v.z);
        n.set(normAttr.getX(vi), normAttr.getY(vi), normAttr.getZ(vi)).applyQuaternion(q);
        normals.push(n.x, n.y, n.z);
      }
      for (let i = 0; i < idx.count; i++) {
        indices.push(idx.getX(i) + vertexOffset);
      }
      vertexOffset += posAttr.count;
    }
    unit.dispose();
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    g.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
    g.setIndex(indices);
    return g;
  }

  /** 幹線の進行方向（ワールドXZ・ラジアン） */
  function highwayTangentAngle(gx, gz, cols) {
    let sxx = 0;
    let szz = 0;
    let sxz = 0;
    let n = 0;
    const r = 10;
    for (let dz = -r; dz <= r; dz++) {
      for (let dx = -r; dx <= r; dx++) {
        const nx = gx + dx;
        const nz = gz + dz;
        if (nx < 0 || nx > SEG || nz < 0 || nz > SEG) continue;
        if (groundMat[nz * cols + nx] !== MAT_HIGHWAY) continue;
        sxx += dx * dx;
        szz += dz * dz;
        sxz += dx * dz;
        n++;
      }
    }
    if (n < 4) return 0;
    const tr = sxx + szz;
    const det = sxx * szz - sxz * sxz;
    const lambda1 = tr / 2 + Math.sqrt(Math.max(0, tr * tr * 0.25 - det));
    let vx = sxz;
    let vz = lambda1 - sxx;
    if (Math.hypot(vx, vz) < 0.01) {
      vx = 1;
      vz = 0;
    }
    return Math.atan2(vz, vx);
  }

  function elevatedHighwayAtIndex(i, deckMinY) {
    return (
      groundMat[i] === MAT_HIGHWAY &&
      highwayDeckH[i] >= deckMinY &&
      highwayDeckH[i] > heights[i] + HIGHWAY_ELEV_MIN_UNITS
    );
  }

  /** 進行方向に対して垂直な現地の幹線幅（はみ出し防止） */
  function localHighwayWidthAt(wx, wz, theta, deckMinY) {
    const cell = terrainCellSize();
    const perpX = -Math.sin(theta);
    const perpZ = Math.cos(theta);
    const search = metersToUnits(roadWidthMeters) * 0.55;
    const step = cell * 0.42;
    let minT = Infinity;
    let maxT = -Infinity;
    for (let t = -search; t <= search; t += step) {
      const x = wx + perpX * t;
      const z = wz + perpZ * t;
      const i = nearestIndex(x, z);
      if (!elevatedHighwayAtIndex(i, deckMinY)) continue;
      minT = Math.min(minT, t);
      maxT = Math.max(maxT, t);
    }
    if (!isFinite(minT)) return 0;
    return Math.max(cell * 0.9, maxT - minT);
  }

  function isHighwayCenterline(gx, gz, cols, theta, deckMinY) {
    const i = gz * cols + gx;
    if (!elevatedHighwayAtIndex(i, deckMinY)) return false;
    const wx = pos.getX(i);
    const wz = pos.getZ(i);
    const perpX = -Math.sin(theta);
    const perpZ = Math.cos(theta);
    const cell = terrainCellSize();
    const step = cell * 0.45;
    const maxSteps = Math.ceil(metersToUnits(roadWidthMeters) / step) + 1;
    let posN = 0;
    let negN = 0;
    for (let s = 1; s <= maxSteps; s++) {
      const ip = nearestIndex(wx + perpX * step * s, wz + perpZ * step * s);
      if (elevatedHighwayAtIndex(ip, deckMinY)) posN++;
      else break;
    }
    for (let s = 1; s <= maxSteps; s++) {
      const im = nearestIndex(wx - perpX * step * s, wz - perpZ * step * s);
      if (elevatedHighwayAtIndex(im, deckMinY)) negN++;
      else break;
    }
    if (posN < 1 || negN < 1) return false;
    return Math.abs(posN - negN) <= 1;
  }

  function girderTooClose(sites, x, z, minDist) {
    for (const s of sites) {
      if (Math.hypot(s.x - x, s.z - z) < minDist) return true;
    }
    return false;
  }

  /** 幹線の進行方向を近傍で平均（セル単位のブレを抑える） */
  function smoothedHighwayAngle(gx, gz, cols, deckMinY) {
    let sumSin = 0;
    let sumCos = 0;
    let n = 0;
    for (let dz = -2; dz <= 2; dz++) {
      for (let dx = -2; dx <= 2; dx++) {
        const nx = gx + dx;
        const nz = gz + dz;
        if (nx < 0 || nx > SEG || nz < 0 || nz > SEG) continue;
        const ni = nz * cols + nx;
        if (!elevatedHighwayAtIndex(ni, deckMinY)) continue;
        const t = highwayTangentAngle(nx, nz, cols);
        sumSin += Math.sin(t);
        sumCos += Math.cos(t);
        n++;
      }
    }
    if (n < 1) return highwayTangentAngle(gx, gz, cols);
    return Math.atan2(sumSin / n, sumCos / n);
  }

  /** 中心線用の板長（隣接セルと重ねて段差を抑える） */
  function centerlineAlongSpan(cell) {
    return cell * 2.35;
  }

  /** 立体幹線の板張り路面（進行方向に細長い板＋溝） */
  function appendHighwayDeckPlanks(x, z, theta, widthU, alongU, fullDeckY, thick, deckBoxes, grooveBoxes) {
    const rotY = theta + Math.PI / 2;
    const perpX = -Math.sin(theta);
    const perpZ = Math.cos(theta);
    const plankWU = metersToUnits(HIGHWAY_PLANK_WIDTH_M);
    const gapU = metersToUnits(HIGHWAY_PLANK_GAP_M);
    const plankCap = metersToUnits(0.14);
    const bodyH = Math.max(metersToUnits(0.35), thick - plankCap);

    deckBoxes.push({
      x,
      y: fullDeckY - thick / 2 + plankCap / 2,
      z,
      sx: widthU,
      sy: bodyH,
      sz: alongU,
      rotY,
    });

    const n = Math.max(1, Math.floor((widthU + gapU) / (plankWU + gapU)));
    const total = n * plankWU + Math.max(0, n - 1) * gapU;
    const startT = -total / 2 + plankWU / 2;
    const plankY = fullDeckY - plankCap / 2;

    for (let k = 0; k < n; k++) {
      const t = startT + k * (plankWU + gapU);
      deckBoxes.push({
        x: x + perpX * t,
        y: plankY,
        z: z + perpZ * t,
        sx: plankWU,
        sy: plankCap,
        sz: alongU,
        rotY,
      });
      if (k < n - 1) {
        const gt = t + plankWU / 2 + gapU / 2;
        grooveBoxes.push({
          x: x + perpX * gt,
          y: fullDeckY - plankCap * 0.35,
          z: z + perpZ * gt,
          sx: gapU * 0.92,
          sy: plankCap * 0.55,
          sz: alongU * 0.98,
          rotY,
        });
      }
    }
  }

  function rebuildHighwayViaduct() {
    ensureHighwayViaductGroup();
    clearHighwayViaductMeshes();
    const show = viewMode === '3d' && !!heights && !!highwayDeckH && !!pos;
    highwayViaductGroup.visible = show;
    if (!show) return;

    const cell = terrainCellSize();
    const thick = metersToUnits(HIGHWAY_DECK_THICKNESS_M);
    const fullDeckY = metersToUnits(highwayDeckMeters);
    if (fullDeckY <= HIGHWAY_ELEV_MIN_UNITS) return;

    const cols = SEG + 1;
    const deckMinY = fullDeckY * HIGHWAY_DECK_HEIGHT_RATIO;
    const deckBoxes = [];
    const grooveBoxes = [];
    const girderSites = [];
    const minGirderDist = metersToUnits(HIGHWAY_PILLAR_SPACING_M);
    const deckWidthU = metersToUnits(roadWidthMeters) + cell * 0.25;

    for (let i = 0; i < N; i++) {
      if (!elevatedHighwayAtIndex(i, deckMinY)) continue;
      const x = pos.getX(i);
      const z = pos.getZ(i);
      const gx = i % cols;
      const gz = Math.floor(i / cols);
      const theta = smoothedHighwayAngle(gx, gz, cols, deckMinY);
      if (!isHighwayCenterline(gx, gz, cols, theta, deckMinY)) continue;
      const alongU = centerlineAlongSpan(cell);
      appendHighwayDeckPlanks(x, z, theta, deckWidthU, alongU, fullDeckY, thick, deckBoxes, grooveBoxes);
      const widthU = localHighwayWidthAt(x, z, theta, deckMinY);
      if (widthU <= 0) continue;
      if (girderTooClose(girderSites, x, z, minGirderDist)) continue;
      girderSites.push({ x, z, deckY: fullDeckY, gy: heights[i], theta, widthU });
    }
    if (!deckBoxes.length) return;

    const deckGeo = mergeUnitBoxes(deckBoxes);
    if (deckGeo) {
      const deckMat = new THREE.MeshStandardMaterial({
        color: cMatHighway.clone(),
        roughness: 0.88,
        metalness: 0.02,
        flatShading: false,
      });
      highwayViaductGroup.add(new THREE.Mesh(deckGeo, deckMat));
    }

    if (grooveBoxes.length) {
      const grooveGeo = mergeUnitBoxes(grooveBoxes);
      if (grooveGeo) {
        const grooveCol = cMatHighway.clone().lerp(new THREE.Color(0x1a1c1e), 0.42);
        const grooveMat = new THREE.MeshStandardMaterial({
          color: grooveCol,
          roughness: 0.95,
          metalness: 0,
        });
        highwayViaductGroup.add(new THREE.Mesh(grooveGeo, grooveMat));
      }
    }

    if (!girderSites.length) return;
    const girderSlice = metersToUnits(HIGHWAY_GIRDER_SLICE_M);
    const girderBoxes = [];
    for (const c of girderSites) {
      const h = Math.max(metersToUnits(1.5), c.deckY - thick - c.gy);
      girderBoxes.push({
        x: c.x,
        y: c.gy + h / 2,
        z: c.z,
        sx: c.widthU * HIGHWAY_GIRDER_WIDTH_RATIO,
        sy: h,
        sz: girderSlice,
        rotY: c.theta,
      });
    }
    const girderGeo = mergeUnitBoxes(girderBoxes);
    if (!girderGeo) return;
    const girderCol = new THREE.Color(roadStyles.highwayGirderColor || DEFAULT_ROAD_STYLES.highwayGirderColor);
    const girderMat = new THREE.MeshStandardMaterial({ color: girderCol, roughness: 0.92, metalness: 0.02 });
    highwayViaductGroup.add(new THREE.Mesh(girderGeo, girderMat));
  }

  function syncHighwayViaductVisibility() {
    if (!highwayViaductGroup) return;
    highwayViaductGroup.visible = viewMode === '3d';
  }

  function areaColorById(id) {
    const a = areas.find((x) => x.id === id);
    if (!a) return null;
    return new THREE.Color(a.color);
  }

  function tintWithArea(base, id, strength) {
    const ac = areaColorById(id);
    if (!ac) return base;
    return base.clone().lerp(ac, strength);
  }

  function recolor3d() {
    for (let i = 0; i < N; i++) {
      const y = heights[i];
      let c;
      if (groundMat[i] > 0 && !isElevatedHighwayCell(i)) {
        c = matColor(groundMat[i]);
      } else if (y < -0.01) {
        c = cCutGray;
      } else if (y < 6) {
        c = cLow.clone().lerp(cMid, Math.min(1, y / 40));
      } else if (y < 40) {
        c = cLow.clone().lerp(cMid, y / 40);
      } else {
        c = cMid.clone().lerp(cHigh, Math.min(1, (y - 40) / 50));
      }
      if (areaGrid[i] > 0) c = tintWithArea(c, areaGrid[i], viewMode === 'plan' ? 0.72 : 0.45);
      colAttr.setXYZ(i, c.r, c.g, c.b);
    }
    colAttr.needsUpdate = true;
  }

  function applyHighwayPlanDecorations() {
    if (viewMode !== 'plan' || !roadStyles.highwayOutline) return;
    const cols = SEG + 1;
    const cOutline = new THREE.Color(0x4a4035);

    for (let i = 0; i < N; i++) {
      if (groundMat[i] !== MAT_HIGHWAY) continue;
      const gx = i % cols;
      const gz = Math.floor(i / cols);
      let edge = false;
      for (const [dx, dz] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ]) {
        const nx = gx + dx;
        const nz = gz + dz;
        if (nx < 0 || nx > SEG || nz < 0 || nz > SEG) {
          edge = true;
          break;
        }
        if (groundMat[nz * cols + nx] !== MAT_HIGHWAY) {
          edge = true;
          break;
        }
      }
      if (!edge) continue;
      const r = colAttr.getX(i);
      const g = colAttr.getY(i);
      const b = colAttr.getZ(i);
      colAttr.setXYZ(
        i,
        r * 0.5 + cOutline.r * 0.5,
        g * 0.5 + cOutline.g * 0.5,
        b * 0.5 + cOutline.b * 0.5,
      );
    }
    colAttr.needsUpdate = true;
  }

  function recolorPlan() {
    for (let i = 0; i < N; i++) {
      if (groundMat[i] > 0) {
        const mc = matColor(groundMat[i]);
        colAttr.setXYZ(i, mc.r, mc.g, mc.b);
        continue;
      }
      const y = heights[i];
      if (y < -0.01) {
        colAttr.setXYZ(i, cCutGray.r, cCutGray.g, cCutGray.b);
        continue;
      }
      let r;
      let g;
      let bch;
      if (areaGrid[i] > 0) {
        const ac = areaColorById(areaGrid[i]);
        if (ac) {
          colAttr.setXYZ(i, ac.r, ac.g, ac.b);
          continue;
        }
      }
      let band = HEIGHT_BANDS[HEIGHT_BANDS.length - 1];
      for (const b of HEIGHT_BANDS) {
        if (y < b.max) {
          band = b;
          break;
        }
      }
      const hex = band.css.replace('#', '');
      r = parseInt(hex.slice(0, 2), 16) / 255;
      g = parseInt(hex.slice(2, 4), 16) / 255;
      bch = parseInt(hex.slice(4, 6), 16) / 255;
      colAttr.setXYZ(i, r, g, bch);
    }
    colAttr.needsUpdate = true;
    applyHighwayPlanDecorations();
  }

  function recolor() {
    if (viewMode === 'plan') recolorPlan();
    else recolor3d();
  }

  function sampleMaxHeight() {
    let max = 0;
    for (let i = 0; i < N; i++) {
      if (water[i] > 0.5) continue;
      if (heights[i] > max) max = heights[i];
    }
    return max;
  }

  function heightBandLabel(y) {
    for (const b of HEIGHT_BANDS) {
      if (y < b.max) return b.label;
    }
    return HEIGHT_BANDS[HEIGHT_BANDS.length - 1].label;
  }

  function updateScaleLegend() {
    const p = terrainSpec();
    const mpu = p.metersPerUnit;
    const gridM = GRID_CELL * mpu;
    const gridEl = document.getElementById('world-map-grid-hint');
    if (gridEl) gridEl.textContent = p.gridLabel + '（約' + formatMeters(gridM) + '）';

    const presetHint = document.getElementById('world-map-preset-hint');
    if (presetHint) presetHint.textContent = p.hint;

    const legendPx = 36;
    const personPx = Math.max(4, Math.min(28, (PERSON_M / mpu) * legendPx));
    const carPx = Math.max(6, Math.min(36, (CAR_LEN_M / mpu) * legendPx));
    const personEl = document.getElementById('world-map-ref-person');
    const carEl = document.getElementById('world-map-ref-car');
    if (personEl) {
      personEl.style.height = personPx + 'px';
      personEl.style.width = Math.max(4, personPx * 0.35) + 'px';
    }
    if (carEl) carEl.style.width = carPx + 'px';

    const peakEl = document.getElementById('world-map-peak-hint');
    if (!peakEl) return;
    const peak = sampleMaxHeight();
    if (peak < 1) {
      peakEl.textContent = 'いまの地形：ほぼ平地';
    } else {
      peakEl.textContent = 'いまの最高付近：' + heightBandLabel(peak) + 'くらいの感じ';
    }
  }

  function formatMeters(m) {
    if (m >= 1000) return Math.round(m / 100) / 10 + 'km';
    return Math.round(m) + 'm';
  }

  function riverWidthLabel() {
    const m = riverWidthMeters;
    if (m < 5) return '細い水路';
    if (m < 15) return '小川';
    if (m < 30) return '川';
    return '広い川';
  }

  function depthMetersText() {
    return '約' + (Math.round(riverDepthMeters * 10) / 10) + 'm';
  }

  function digLegendText() {
    const matLabel = digMaterial === MAT_GRASS ? '草' : digMaterial === MAT_CONCRETE ? 'コンクリ' : '土';
    return (
      '川を掘る：幅 約' +
      formatMeters(riverWidthMeters) +
      ' · 深さ ' +
      depthMetersText() +
      ' · ' +
      matLabel
    );
  }

  function groundHeightText() {
    return '地面より +' + (Math.round(groundHeightMeters * 10) / 10) + 'm';
  }

  function groundLegendText() {
    return (
      '地面を盛る：高さ ' +
      groundHeightText() +
      ' · 幅 約' +
      formatMeters(groundBrushMeters) +
      ' · 草'
    );
  }

  function roadLegendText() {
    return '道路：道幅 約' + formatMeters(roadWidthMeters);
  }

  function highwayLegendText() {
    const deck =
      highwayDeckMeters > 0
        ? ' · 路面 ' + Math.round(highwayDeckMeters) + 'm 高架'
        : ' · 平面で縁取り';
    return '幹線道路：道幅 約' + formatMeters(roadWidthMeters) + deck;
  }

  function highwayDeckText() {
    if (highwayDeckMeters <= 0) return '路面 平地（0m）';
    return '路面 ' + Math.round(highwayDeckMeters) + 'm（立体で橋桁）';
  }

  function treeLegendText() {
    const shapeLabel = treeShape === 'pointed' ? 'とがった' : '丸い';
    return (
      '植生：高さ ' +
      Math.round(treeHeightMeters) +
      'm · 葉幅 約' +
      formatMeters(treeCrownMeters) +
      ' · ' +
      shapeLabel
    );
  }

  function roadWidthText() {
    return '約' + Math.round(roadWidthMeters) + 'm';
  }

  function syncToolSettingsPanel() {
    const wrapper = document.getElementById('world-map-tool-settings');
    const openBtn = document.getElementById('world-map-tool-settings-open');
    const titleEl = document.getElementById('world-map-tool-settings-title');
    const riverPanel = document.getElementById('world-map-river-brush');
    const groundPanel = document.getElementById('world-map-ground-panel');
    const roadPanel = document.getElementById('world-map-road-panel');
    const highwayPanel = document.getElementById('world-map-highway-panel');
    const treePanel = document.getElementById('world-map-tree-panel');
    const roadColorRow = document.getElementById('world-map-road-color-row');
    const roadNote = document.getElementById('world-map-road-note');
    const brushPanel = document.getElementById('world-map-brush-panel');
    const areaPanel = document.getElementById('world-map-area-panel');
    const hasSettings = toolHasSettingsPanel(tool);

    if (riverPanel) riverPanel.hidden = tool !== 'dig' && tool !== 'water';
    if (groundPanel) groundPanel.hidden = tool !== 'ground';
    if (roadPanel) roadPanel.hidden = tool !== 'road' && tool !== 'highway';
    if (highwayPanel) highwayPanel.hidden = tool !== 'highway';
    if (treePanel) treePanel.hidden = tool !== 'tree';
    if (roadColorRow) roadColorRow.hidden = tool !== 'road';
    if (roadNote) roadNote.hidden = tool === 'highway';
    if (brushPanel) brushPanel.hidden = tool !== 'raise' && tool !== 'lower' && tool !== 'erase';
    if (areaPanel) areaPanel.hidden = tool !== 'area';
    if (titleEl) titleEl.textContent = TOOL_SETTINGS_TITLES[tool] || '詳細設定';
    if (wrapper) wrapper.hidden = !hasSettings || !toolSettingsOpen;
    if (openBtn) openBtn.hidden = !hasSettings || toolSettingsOpen;
  }

  function waterLevelText() {
    const m = riverWaterLevelMeters ?? 1;
    return '地表から ' + m.toFixed(1) + 'm 下';
  }

  function syncRiverBrushUI() {
    const slider = document.getElementById('world-map-river-width');
    const feelEl = document.getElementById('world-map-river-width-label');
    const widthMetersEl = document.getElementById('world-map-river-width-meters');
    const waterSlider = document.getElementById('world-map-water-width');
    const waterWidthMetersEl = document.getElementById('world-map-water-width-meters');
    const depthSlider = document.getElementById('world-map-river-depth');
    const depthMetersEl = document.getElementById('world-map-river-depth-meters');
    const groundSlider = document.getElementById('world-map-ground-width');
    const groundMetersEl = document.getElementById('world-map-ground-width-meters');
    const groundHeightSlider = document.getElementById('world-map-ground-height');
    const groundHeightMetersEl = document.getElementById('world-map-ground-height-meters');
    const roadSlider = document.getElementById('world-map-road-width');
    const roadMetersEl = document.getElementById('world-map-road-width-meters');
    const wlSlider = document.getElementById('world-map-river-waterlevel');
    const wlMetersEl = document.getElementById('world-map-river-waterlevel-meters');
    const legendRiver = document.getElementById('world-map-river-scale-hint');
    const riverPanel = document.getElementById('world-map-river-brush');
    const mapToolActive =
      (tool === 'dig' ||
        tool === 'water' ||
        tool === 'ground' ||
        tool === 'road' ||
        tool === 'highway' ||
        tool === 'tree') &&
      !readOnly;
    const p = preset();
    const minM = p.riverWidthMinMeters ?? 2;
    const maxM = Math.min(RIVER_WIDTH_MAX, p.riverWidthMaxMeters ?? RIVER_WIDTH_MAX);

    // ツールに応じて「掘る」用と「水を流す」用の行を出し分け
    if (riverPanel) {
      riverPanel.querySelectorAll('[data-for]').forEach((row) => {
        const forTool = row.getAttribute('data-for');
        row.hidden = forTool !== tool;
      });
    }

    if (slider) {
      slider.min = String(minM);
      slider.max = String(maxM);
      riverWidthMeters = Math.max(minM, Math.min(riverWidthMeters, maxM));
      slider.value = String(Math.round(riverWidthMeters));
    }
    if (feelEl) feelEl.textContent = riverWidthLabel();
    if (widthMetersEl) widthMetersEl.textContent = '幅 約' + formatMeters(riverWidthMeters);
    const wMinM = waterWidthMinMeters();
    const wMaxM = waterWidthMaxMeters();
    if (waterSlider) {
      waterSlider.min = String(wMinM);
      waterSlider.max = String(wMaxM);
      waterWidthMeters = Math.max(wMinM, Math.min(waterWidthMeters, wMaxM));
      waterSlider.value = String(Math.round(waterWidthMeters));
    }
    if (waterWidthMetersEl) waterWidthMetersEl.textContent = '幅 約' + formatMeters(waterWidthMeters);
    if (depthSlider) depthSlider.value = String(riverDepthMeters);
    if (depthMetersEl) depthMetersEl.textContent = '深さ ' + depthMetersText();
    const gMin = GROUND_BRUSH_MIN;
    const gMax = groundBrushMaxMeters();
    if (groundSlider) {
      groundSlider.min = String(gMin);
      groundSlider.max = String(gMax);
      groundBrushMeters = Math.max(gMin, Math.min(gMax, Math.round(groundBrushMeters)));
      groundSlider.value = String(groundBrushMeters);
    }
    if (groundMetersEl) groundMetersEl.textContent = '幅 約' + formatMeters(groundBrushMeters);
    if (groundHeightSlider) {
      groundHeightSlider.min = String(GROUND_HEIGHT_MIN);
      groundHeightSlider.max = String(GROUND_HEIGHT_MAX);
      groundHeightSlider.step = String(GROUND_HEIGHT_STEP);
      groundHeightMeters = Math.max(
        GROUND_HEIGHT_MIN,
        Math.min(
          GROUND_HEIGHT_MAX,
          Math.round(groundHeightMeters / GROUND_HEIGHT_STEP) * GROUND_HEIGHT_STEP,
        ),
      );
      groundHeightSlider.value = String(groundHeightMeters);
    }
    if (groundHeightMetersEl) groundHeightMetersEl.textContent = groundHeightText();
    if (roadSlider) {
      const rwMax = roadWidthMaxMeters();
      roadSlider.min = String(ROAD_WIDTH_MIN);
      roadSlider.max = String(rwMax);
      roadWidthMeters = Math.max(ROAD_WIDTH_MIN, Math.min(rwMax, Math.round(roadWidthMeters)));
      roadSlider.value = String(roadWidthMeters);
    }
    if (roadMetersEl) roadMetersEl.textContent = '道幅 ' + roadWidthText();
    if (wlSlider) wlSlider.value = String(riverWaterLevelMeters);
    if (wlMetersEl) wlMetersEl.textContent = '水位 ' + waterLevelText();

    document.querySelectorAll('.world-map-mat-btn').forEach((b) => {
      b.classList.toggle('on', (parseInt(b.dataset.mat, 10) || MAT_EARTH) === digMaterial);
    });

    if (legendRiver) {
      if (mapToolActive) {
        legendRiver.hidden = false;
        if (tool === 'water') {
          legendRiver.textContent =
            '水を流す：幅 約' + formatMeters(waterWidthMeters) + ' · ' + waterLevelText() + '（水平）';
        } else if (tool === 'ground') {
          legendRiver.textContent = groundLegendText();
        } else if (tool === 'road') {
          legendRiver.textContent = roadLegendText();
        } else if (tool === 'highway') {
          legendRiver.textContent = highwayLegendText();
        } else if (tool === 'tree') {
          legendRiver.textContent = treeLegendText();
        } else {
          legendRiver.textContent = digLegendText();
        }
      } else {
        legendRiver.hidden = true;
      }
    }
    updateRiverPreviewScale();
    syncToolSettingsPanel();
  }

  function syncTreeUI() {
    const heightSlider = document.getElementById('world-map-tree-height');
    const heightMetersEl = document.getElementById('world-map-tree-height-meters');
    const crownSlider = document.getElementById('world-map-tree-crown');
    const crownMetersEl = document.getElementById('world-map-tree-crown-meters');
    const brushSlider = document.getElementById('world-map-tree-brush');
    const brushMetersEl = document.getElementById('world-map-tree-brush-meters');
    const foliageInput = document.getElementById('world-map-tree-foliage-color');
    const trunkInput = document.getElementById('world-map-tree-trunk-color');
    const eraseBtn = document.getElementById('world-map-tree-erase');

    if (heightSlider) {
      heightSlider.min = String(TREE_HEIGHT_MIN);
      heightSlider.max = String(TREE_HEIGHT_MAX);
      treeHeightMeters = Math.max(TREE_HEIGHT_MIN, Math.min(TREE_HEIGHT_MAX, Math.round(treeHeightMeters)));
      heightSlider.value = String(treeHeightMeters);
    }
    if (heightMetersEl) heightMetersEl.textContent = '高さ ' + treeHeightMeters + 'm';
    if (crownSlider) {
      crownSlider.min = String(TREE_CROWN_MIN);
      crownSlider.max = String(TREE_CROWN_MAX);
      treeCrownMeters = Math.max(TREE_CROWN_MIN, Math.min(TREE_CROWN_MAX, Math.round(treeCrownMeters)));
      crownSlider.value = String(treeCrownMeters);
    }
    if (crownMetersEl) crownMetersEl.textContent = '葉幅 約' + formatMeters(treeCrownMeters);
    if (brushSlider) {
      brushSlider.min = String(TREE_BRUSH_MIN);
      brushSlider.max = String(TREE_BRUSH_MAX);
      treeBrushMeters = Math.max(TREE_BRUSH_MIN, Math.min(TREE_BRUSH_MAX, Math.round(treeBrushMeters)));
      brushSlider.value = String(treeBrushMeters);
    }
    if (brushMetersEl) brushMetersEl.textContent = 'ブラシ 約' + formatMeters(treeBrushMeters);
    if (foliageInput) foliageInput.value = treeFoliageColor;
    if (trunkInput) trunkInput.value = treeTrunkColor;
    if (eraseBtn) eraseBtn.classList.toggle('on', treeEraseMode);
    document.querySelectorAll('.world-map-tree-shape-btn').forEach((b) => {
      b.classList.toggle('on', b.dataset.shape === treeShape);
    });
    syncTreeRadiusFromMeters();
    updateRiverPreviewScale();
    syncRiverBrushUI();
  }

  function syncBrushUI() {
    const slider = document.getElementById('world-map-brush-size');
    const metersEl = document.getElementById('world-map-brush-meters');
    const nameEl = document.getElementById('world-map-brush-name');
    const maxM = brushMaxMeters();
    if (slider) {
      slider.min = '2';
      slider.max = String(maxM);
      brushMeters = Math.max(2, Math.min(maxM, Math.round(brushMeters)));
      slider.value = String(brushMeters);
    }
    if (metersEl) metersEl.textContent = '幅 約' + formatMeters(brushMeters);
    if (nameEl) {
      if (tool === 'erase') nameEl.textContent = '消しゴム幅';
      else if (tool === 'raise') nameEl.textContent = '山の幅';
      else if (tool === 'lower') nameEl.textContent = '山の幅';
      else nameEl.textContent = 'ブラシ幅';
    }
  }

  async function switchWorldPreset(id) {
    if (!WORLD_PRESETS[id] || id === currentPresetId) return;
    if (!readOnly) saveLocal();
    deletedSpotSlugs.length = 0;
    currentZoneId = null;
    konuiOverviewMode = false;
    destroyTerrain();
    currentPresetId = id;
    target.set(0, 0, 0);
    orbit = preset().orbitDefault;
    if (isKonuiZoned()) {
      WORLD_ID = preset().worldId;
      migrateKonuiLegacyLocal();
      await showKonuiOverview();
      syncPresetNav();
      setStatus(preset().label + ' — 平面ビューで編集', 4000);
      return;
    }
    buildTerrain();
    riverWidthMeters = preset().riverWidthDefaultMeters ?? 10;
    waterWidthMeters = preset().waterWidthDefaultMeters ?? riverWidthMeters * 2;
    riverDepthMeters = preset().riverDepthDefaultMeters ?? 1;
    riverWaterLevelMeters = preset().riverWaterLevelDefaultMeters ?? 1;
    digMaterial = MAT_CONCRETE;
    groundBrushMeters = preset().groundBrushDefaultMeters ?? preset().leveeSlopeWidthDefaultMeters ?? 20;
    groundHeightMeters = preset().groundHeightDefaultMeters ?? preset().leveeHeightDefaultMeters ?? 2;
    roadWidthMeters = preset().roadWidthDefaultMeters ?? preset().leveeTopWidthDefaultMeters ?? 4;
    syncRiverRadiusFromMeters();
    syncWaterRadiusFromMeters();
    syncGroundRadiusFromMeters();
    syncRoadRadiusFromMeters();
    planZoom = preset().planZoomDefault ?? 1;
    planZoom = Math.max(planZoomMin(), planZoom);
    applyHeights();
    const sel = document.getElementById('world-map-preset');
    if (sel) sel.value = id;
    const remote = await loadFromSupabase();
    const local = readOnly ? null : readLocalData();
    const localAt = local?.savedAt || 0;
    if (local && localAt > remote.updatedAt + 500) {
      applyLocalData(local);
    } else if (!remote.loaded && local) {
      applyLocalData(local);
    }
    setViewMode(viewMode);
    if (!readOnly) initHistory();
    syncPresetNav();
    setStatus(preset().label + ' に切り替えました');
  }

  function syncPresetNav() {
    const idx = PRESET_ORDER.indexOf(currentPresetId);
    if (idx < 0) return;
    const prevId = PRESET_ORDER[(idx - 1 + PRESET_ORDER.length) % PRESET_ORDER.length];
    const nextId = PRESET_ORDER[(idx + 1) % PRESET_ORDER.length];
    const prevBtn = document.getElementById('world-map-preset-prev');
    const nextBtn = document.getElementById('world-map-preset-next');
    const label = document.getElementById('world-map-preset-nav-label');
    if (prevBtn) prevBtn.title = '← ' + WORLD_PRESETS[prevId].shortLabel;
    if (nextBtn) nextBtn.title = WORLD_PRESETS[nextId].shortLabel + ' →';
    if (label) {
      const base = preset().shortLabel || preset().label;
      if (currentZoneId) label.textContent = `${base} · ${currentZoneLabel()}`;
      else if (isKonuiOverview()) label.textContent = `${base} · 平面`;
      else label.textContent = base;
    }
  }

  const zonePickerEl = document.getElementById('world-map-zone-picker');
  const zonePickerList = document.getElementById('world-map-zone-picker-list');
  const zoneContextEl = document.getElementById('world-map-zone-context');
  const zoneContextHighlight = document.getElementById('world-map-zone-context-highlight');
  const zoneBackBtn = document.getElementById('world-map-zone-back');

  function buildZonePickerList() {
    if (!zonePickerList || !konuiZones()) return;
    zonePickerList.innerHTML = '';
    for (const z of konuiZones()) {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'world-map-zone-picker__btn';
      btn.style.setProperty('--zone-color', z.color);
      btn.innerHTML = `<span class="world-map-zone-picker__num">${z.num}</span><span class="world-map-zone-picker__name">${z.name}</span>`;
      btn.addEventListener('click', () => enterKonuiZone(z.id));
      zonePickerList.appendChild(btn);
    }
  }

  function updateZoneContextHighlight() {
    const z = findKonuiZone(currentZoneId);
    if (!zoneContextHighlight || !z) return;
    zoneContextHighlight.style.left = z.tx * 100 + '%';
    zoneContextHighlight.style.top = z.ty * 100 + '%';
    zoneContextHighlight.style.width = z.tw * 100 + '%';
    zoneContextHighlight.style.height = z.th * 100 + '%';
    zoneContextHighlight.style.borderColor = z.color;
    zoneContextHighlight.style.background = z.color + '33';
  }

  function syncKonuiViewToggle() {
    const planBtn = document.querySelector('.world-map-view-toggle button[data-view="plan"]');
    const d3Btn = document.querySelector('.world-map-view-toggle button[data-view="3d"]');
    if (!isKonuiZoned()) return;
    if (isKonuiOverview()) {
      if (planBtn) {
        planBtn.hidden = false;
        planBtn.classList.add('on');
      }
      if (d3Btn) {
        d3Btn.hidden = true;
        d3Btn.classList.remove('on');
      }
    } else if (currentZoneId) {
      if (readOnly) {
        if (planBtn) {
          planBtn.hidden = true;
          planBtn.classList.remove('on');
        }
        if (d3Btn) {
          d3Btn.hidden = false;
          d3Btn.classList.add('on');
        }
      } else {
        if (planBtn) planBtn.hidden = false;
        if (d3Btn) d3Btn.hidden = false;
      }
    }
  }

  function syncKonuiZoneUI() {
    const overview = isKonuiOverview();
    document.body.classList.remove('world-map-body--zone-overview');
    if (zonePickerEl) zonePickerEl.hidden = !overview;
    if (zoneBackBtn) zoneBackBtn.hidden = overview || !currentZoneId;
    if (minimapEl) {
      minimapEl.hidden = overview || viewMode !== '3d' || (isKonuiZoned() && !!currentZoneId);
    }
    if (zoneContextEl) {
      zoneContextEl.hidden = overview || !currentZoneId || viewMode !== '3d';
      if (currentZoneId) updateZoneContextHighlight();
    }
    if (zoneMarkerGroup) zoneMarkerGroup.visible = overview && viewMode === 'plan';
    if (zoneLinkItems.length) updateZoneLinkPositions();
    syncKonuiViewToggle();
    syncPresetNav();
  }

  async function loadOverviewData() {
    const remote = await loadFromSupabase();
    const local = readOnly ? null : readLocalData();
    const localAt = local?.savedAt || 0;
    if (local && localAt > remote.updatedAt + 500) {
      applyLocalData(local);
    } else if (!remote.loaded && local) {
      applyLocalData(local);
    } else if (land) {
      applyHeights();
    }
  }

  async function showKonuiOverview() {
    konuiOverviewMode = true;
    currentZoneId = null;
    destroyTerrain();
    buildTerrain();
    target.set(0, 0, 0);
    orbit = preset().orbitDefault;
    azimuth = 0;
    polar = 0.95;
    planZoom = preset().planZoomDefault ?? 1;
    planZoom = Math.max(planZoomMin(), planZoom);
    tool = 'look';
    document.querySelectorAll('.world-map-tools button').forEach((x) => {
      x.classList.toggle('on', x.dataset.tool === 'look');
    });
    await loadOverviewData();
    buildZoneMarkersOnPlan();
    setViewMode('plan');
    syncKonuiZoneUI();
    if (!readOnly) initHistory();
    if (loadingEl) loadingEl.style.display = 'none';
  }

  async function loadZoneData() {
    migrateKonuiLegacyLocal();
    const remote = await loadFromSupabase();
    const local = readOnly ? null : readLocalData();
    const localAt = local?.savedAt || 0;
    if (local && localAt > remote.updatedAt + 500) {
      applyLocalData(local);
    } else if (!remote.loaded && local) {
      applyLocalData(local);
    } else if (land) {
      applyHeights();
    }
  }

  async function enterKonuiZone(zoneId) {
    if (!findKonuiZone(zoneId)) return;
    if (!readOnly && isKonuiOverview() && heights) saveLocal();
    captureOverviewState();
    currentZoneId = zoneId;
    konuiOverviewMode = false;
    destroyTerrain();
    buildTerrain();
    target.set(0, 0, 0);
    orbit = terrainSpec().orbitDefault ?? preset().orbitDefault;
    azimuth = 0;
    polar = 0.95;
    planZoom = preset().planZoomDefault ?? 1;
    planZoom = Math.max(planZoomMin(), planZoom);
    tool = 'look';
    document.querySelectorAll('.world-map-tools button').forEach((x) => {
      x.classList.toggle('on', x.dataset.tool === 'look');
    });
    syncKonuiZoneUI();
    syncToolSettingsPanel();
    updateZoneContextHighlight();
    updateGuideUI();
    await loadZoneData();
    if (!readOnly) {
      buildGuidePlane();
      setViewMode(loadZoneTraceFromStorage() ? 'plan' : '3d');
    } else {
      setViewMode('3d');
    }
    if (!readOnly) initHistory();
    syncZoneUrl();
    setStatus(
      readOnly
        ? `${currentZoneLabel()} — 立体ビュー`
        : loadZoneTraceFromStorage()
          ? `${currentZoneLabel()} — 平面/立体を切り替えて編集 · 下絵でトレース`
          : `${currentZoneLabel()} — 立体ビューで編集 · 📷で下絵を貼れます`,
      5000,
    );
  }

  async function returnToKonuiOverview() {
    if (!readOnly && currentZoneId) saveLocal();
    await showKonuiOverview();
    syncZoneUrl();
    setStatus('コヌイの路 — 平面ビューで編集', 4000);
  }

  if (zoneBackBtn) {
    zoneBackBtn.addEventListener('click', (e) => {
      if (zoneBackBtn.tagName === 'A') e.preventDefault();
      returnToKonuiOverview();
    });
    if (zoneBackBtn.tagName === 'A') zoneBackBtn.href = zoneOverviewHref();
  }

  buildZonePickerList();

  function switchPresetStep(delta) {
    const idx = PRESET_ORDER.indexOf(currentPresetId);
    if (idx < 0) return;
    const nextIdx = (idx + delta + PRESET_ORDER.length) % PRESET_ORDER.length;
    switchWorldPreset(PRESET_ORDER[nextIdx]);
  }

  function applyHeights() {
    for (let i = 0; i < N; i++) {
      pos.setY(i, heights[i]);
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
    recolor();
    if (waterDirty) {
      rebuildWaterSurface();
      waterDirty = false;
    }
    rebuildHighwayViaduct();
    updateScaleLegend();
    updateAllTreeGroundY();
  }

  function worldToNorm(x, z) {
    return {
      x: (x + SIZE_X / 2) / SIZE_X,
      z: (z - MAP_OFFSET_Z + SIZE_Z / 2) / SIZE_Z,
    };
  }

  function normToWorld(nx, nz) {
    return {
      x: nx * SIZE_X - SIZE_X / 2,
      z: nz * SIZE_Z - SIZE_Z / 2 + MAP_OFFSET_Z,
    };
  }

  function nearestIndex(x, z) {
    const gx = Math.round(gridCoordX(x));
    const gz = Math.round(gridCoordZ(z));
    const cx = Math.max(0, Math.min(SEG, gx));
    const cz = Math.max(0, Math.min(SEG, gz));
    return cz * (SEG + 1) + cx;
  }

  const spots = [];
  const deletedSpotSlugs = [];
  const seedMat = new THREE.MeshBasicMaterial({ color: 0xffe9b0 });

  function spotScale() {
    return SIZE / 700;
  }

  function addSpot(worldX, worldZ, name, slug) {
    const idx = nearestIndex(worldX, worldZ);
    const r = 3 * spotScale();
    const y = (heights[idx] || 0) + 8 * spotScale();
    const seedGeo = new THREE.SphereGeometry(r, 16, 16);
    const m = new THREE.Mesh(seedGeo, seedMat);
    m.position.set(worldX, y, worldZ);
    scene.add(m);
    const halo = new THREE.Mesh(
      new THREE.SphereGeometry(r * 2.2, 16, 16),
      new THREE.MeshBasicMaterial({ color: 0xffe9b0, transparent: true, opacity: 0.16 }),
    );
    halo.position.copy(m.position);
    scene.add(halo);
    const el = document.createElement('div');
    el.className = 'world-map-label';
    el.textContent = name;
    app.appendChild(el);
    spots.push({
      x: worldX,
      z: worldZ,
      name,
      slug,
      _m: m,
      _halo: halo,
      _el: el,
      _y: y,
    });
    const di = deletedSpotSlugs.indexOf(slug);
    if (di >= 0) deletedSpotSlugs.splice(di, 1);
    drawConstellation();
  }

  function removeSpot(sp) {
    const idx = spots.indexOf(sp);
    if (idx < 0) return;
    scene.remove(sp._m);
    scene.remove(sp._halo);
    sp._m.geometry.dispose();
    sp._halo.geometry.dispose();
    sp._el.remove();
    if (!deletedSpotSlugs.includes(sp.slug)) deletedSpotSlugs.push(sp.slug);
    spots.splice(idx, 1);
    drawConstellation();
  }

  let constLine = null;

  function drawConstellation() {
    if (constLine) {
      scene.remove(constLine);
      constLine.geometry.dispose();
      constLine = null;
    }
    if (spots.length < 2) return;
    const pts = [];
    for (let i = 0; i < spots.length; i++) {
      let nd = 1e9;
      let nj = -1;
      for (let j = i + 1; j < spots.length; j++) {
        const d = Math.hypot(spots[i].x - spots[j].x, spots[i].z - spots[j].z);
        if (d < nd) {
          nd = d;
          nj = j;
        }
      }
      if (nj >= 0) {
        pts.push(
          new THREE.Vector3(spots[i].x, spots[i]._y, spots[i].z),
          new THREE.Vector3(spots[nj].x, spots[nj]._y, spots[nj].z),
        );
      }
    }
    constLine = new THREE.LineSegments(
      new THREE.BufferGeometry().setFromPoints(pts),
      new THREE.LineBasicMaterial({ color: 0xffe9b0, transparent: true, opacity: 0.4 }),
    );
    scene.add(constLine);
  }

  function clearSpots() {
    spots.forEach((s) => {
      scene.remove(s._m);
      scene.remove(s._halo);
      s._el.remove();
    });
    spots.length = 0;
    if (constLine) {
      scene.remove(constLine);
      constLine.geometry.dispose();
      constLine = null;
    }
  }

  const trees = [];

  function syncTreeRadiusFromMeters() {
    treeBrushRadius = Math.max(0.05, treeBrushMeters / 2 / preset().metersPerUnit);
  }

  function treeSpacingUnits() {
    return Math.max(0.4, (treeCrownMeters * 0.85) / preset().metersPerUnit);
  }

  function hexToThreeColor(hex) {
    const h = (hex || '#888888').replace('#', '');
    if (h.length !== 6) return new THREE.Color(0x888888);
    return new THREE.Color(
      parseInt(h.slice(0, 2), 16) / 255,
      parseInt(h.slice(2, 4), 16) / 255,
      parseInt(h.slice(4, 6), 16) / 255,
    );
  }

  function buildTreeGroup(opts) {
    const heightM = opts.heightM ?? treeHeightMeters;
    const crownM = opts.crownM ?? treeCrownMeters;
    const shape = opts.shape ?? treeShape;
    const foliageColor = opts.foliageColor ?? treeFoliageColor;
    const trunkColor = opts.trunkColor ?? treeTrunkColor;
    const mpu = preset().metersPerUnit;
    const totalH = Math.max(0.2, heightM / mpu);
    const crownR = Math.max(0.15, crownM / mpu / 2);
    const trunkH = totalH * 0.38;
    const trunkR = Math.max(0.06, crownR * 0.14);

    const group = new THREE.Group();
    const trunkMat = new THREE.MeshStandardMaterial({
      color: hexToThreeColor(trunkColor),
      roughness: 0.92,
      metalness: 0,
    });
    const trunk = new THREE.Mesh(
      new THREE.CylinderGeometry(trunkR * 0.82, trunkR, trunkH, 8),
      trunkMat,
    );
    trunk.position.y = trunkH / 2;
    group.add(trunk);

    const foliageMat = new THREE.MeshStandardMaterial({
      color: hexToThreeColor(foliageColor),
      roughness: 0.88,
      metalness: 0,
    });
    let foliage;
    if (shape === 'pointed') {
      const coneH = Math.max(0.2, totalH - trunkH);
      foliage = new THREE.Mesh(new THREE.ConeGeometry(crownR, coneH, 10), foliageMat);
      foliage.position.y = trunkH + coneH / 2;
    } else {
      foliage = new THREE.Mesh(new THREE.SphereGeometry(crownR, 10, 8), foliageMat);
      foliage.position.y = trunkH + crownR * 0.55;
    }
    group.add(foliage);
    return group;
  }

  function buildTreePlanMarker(foliageColor) {
    const r = Math.max(0.35, (treeCrownMeters / preset().metersPerUnit) * 0.35);
    return new THREE.Mesh(
      new THREE.CircleGeometry(r, 16),
      new THREE.MeshBasicMaterial({
        color: hexToThreeColor(foliageColor || treeFoliageColor),
        transparent: true,
        opacity: 0.82,
        side: THREE.DoubleSide,
        depthWrite: false,
      }),
    );
  }

  function disposeTreeMeshes(tr) {
    if (tr._group) {
      scene.remove(tr._group);
      tr._group.traverse((o) => {
        if (o.geometry) o.geometry.dispose();
        if (o.material) o.material.dispose();
      });
    }
    if (tr._marker) {
      scene.remove(tr._marker);
      tr._marker.geometry.dispose();
      tr._marker.material.dispose();
    }
  }

  function clearTrees() {
    for (const tr of trees) disposeTreeMeshes(tr);
    trees.length = 0;
  }

  function syncTreeVisibility() {
    const show3d = viewMode === '3d';
    for (const tr of trees) {
      if (tr._group) tr._group.visible = show3d;
      if (tr._marker) {
        tr._marker.visible = !show3d;
        tr._marker.rotation.x = -Math.PI / 2;
      }
    }
  }

  function updateTreeGroundPos(tr) {
    const y = groundY(tr.x, tr.z);
    if (tr._group) tr._group.position.set(tr.x, y, tr.z);
    if (tr._marker) tr._marker.position.set(tr.x, y + 0.35, tr.z);
  }

  function updateAllTreeGroundY() {
    for (const tr of trees) updateTreeGroundPos(tr);
  }

  function treeMinDist() {
    return treeSpacingUnits() * 0.55;
  }

  function treeOverlaps(x, z, minDist) {
    const d = minDist ?? treeMinDist();
    for (const tr of trees) {
      if (Math.hypot(tr.x - x, tr.z - z) < d) return true;
    }
    return false;
  }

  function addTree(worldX, worldZ, opts = {}) {
    const id = opts.id ?? nextTreeId++;
    if (id >= nextTreeId) nextTreeId = id + 1;
    const tr = {
      id,
      x: worldX,
      z: worldZ,
      heightM: opts.heightM ?? treeHeightMeters,
      crownM: opts.crownM ?? treeCrownMeters,
      shape: opts.shape ?? treeShape,
      foliageColor: opts.foliageColor ?? treeFoliageColor,
      trunkColor: opts.trunkColor ?? treeTrunkColor,
    };
    tr._group = buildTreeGroup(tr);
    tr._group.userData.treeId = id;
    tr._group.traverse((o) => {
      o.userData.treeId = id;
    });
    tr._marker = buildTreePlanMarker(tr.foliageColor);
    tr._marker.userData.treeId = id;
    scene.add(tr._group);
    scene.add(tr._marker);
    updateTreeGroundPos(tr);
    syncTreeVisibility();
    trees.push(tr);
    return tr;
  }

  function removeTree(tr) {
    const idx = trees.indexOf(tr);
    if (idx < 0) return;
    disposeTreeMeshes(tr);
    trees.splice(idx, 1);
  }

  function removeTreeById(id) {
    const tr = trees.find((t) => t.id === id);
    if (tr) removeTree(tr);
  }

  function pickTree(e) {
    if (!trees.length) return null;
    const r = renderer.domElement.getBoundingClientRect();
    ndc.x = ((e.clientX - r.left) / r.width) * 2 - 1;
    ndc.y = -((e.clientY - r.top) / r.height) * 2 + 1;
    ray.setFromCamera(ndc, activeCamera);
    const meshes = trees.flatMap((t) => {
      const list = [];
      t._group.visible && t._group.traverse((o) => {
        if (o.isMesh) list.push(o);
      });
      if (t._marker.visible) list.push(t._marker);
      return list;
    });
    const hits = ray.intersectObjects(meshes, false);
    if (!hits.length) return null;
    const id = hits[0].object.userData.treeId;
    return trees.find((t) => t.id === id) || null;
  }

  function eraseTreesInBrush(cx, cz) {
    const r = treeBrushRadius;
    let removed = 0;
    for (let i = trees.length - 1; i >= 0; i--) {
      const tr = trees[i];
      if (Math.hypot(tr.x - cx, tr.z - cz) <= r) {
        removeTree(tr);
        removed++;
      }
    }
    return removed;
  }

  function plantTreesInBrush(cx, cz) {
    const r = treeBrushRadius;
    const step = treeSpacingUnits();
    let planted = 0;
    for (let dz = -r; dz <= r; dz += step) {
      for (let dx = -r; dx <= r; dx += step) {
        if (Math.hypot(dx, dz) > r) continue;
        const x = clampMapX(cx + dx);
        const z = clampMapZ(cz + dz);
        if (treeOverlaps(x, z)) continue;
        addTree(x, z);
        planted++;
      }
    }
    return planted;
  }

  function plantTreeAt(p) {
    if (treeEraseMode) {
      return eraseTreesInBrush(p.x, p.z) > 0;
    }
    if (treeOverlaps(p.x, p.z, treeSpacingUnits() * 0.45)) return false;
    addTree(p.x, p.z);
    return true;
  }

  function plantTreeStroke(from, to) {
    const dx = to.x - from.x;
    const dz = to.z - from.z;
    const dist = Math.hypot(dx, dz);
    const spacing = treeSpacingUnits();
    const steps = Math.max(1, Math.ceil(dist / spacing));
    let changed = false;
    for (let i = 0; i <= steps; i++) {
      const t = steps === 0 ? 0 : i / steps;
      const x = from.x + dx * t;
      const z = from.z + dz * t;
      if (treeEraseMode) {
        if (eraseTreesInBrush(x, z)) changed = true;
      } else if (plantTreesInBrush(x, z)) {
        changed = true;
      }
    }
    return changed;
  }

  function treePayload(tr) {
    const n = worldToNorm(tr.x, tr.z);
    return {
      id: tr.id,
      x: n.x,
      z: n.z,
      h: tr.heightM,
      w: tr.crownM,
      s: tr.shape,
      fc: tr.foliageColor,
      tc: tr.trunkColor,
    };
  }

  function loadTreesFromData(rows) {
    clearTrees();
    for (const row of rows || []) {
      let x;
      let z;
      if (row.x != null && row.z != null && row.x <= 1 && row.z <= 1) {
        const w = normToWorld(row.x, row.z);
        x = w.x;
        z = w.z;
      } else if (row.x != null && row.z != null) {
        x = row.x;
        z = row.z;
      } else {
        continue;
      }
      addTree(x, z, {
        id: row.id,
        heightM: row.h ?? row.heightM ?? 5,
        crownM: row.w ?? row.crownM ?? 3,
        shape: row.s ?? row.shape ?? 'round',
        foliageColor: row.fc ?? row.foliageColor ?? DEFAULT_TREE_FOLIAGE,
        trunkColor: row.tc ?? row.trunkColor ?? DEFAULT_TREE_TRUNK,
      });
    }
  }

  function mergeTreesFromLocal(remoteUpdatedAt = 0) {
    if (readOnly) return false;
    try {
      const d = readLocalData();
      if (!d?.t?.length) return false;
      const localAt = d.savedAt || 0;
      if (localAt <= remoteUpdatedAt + 500 && trees.length > 0) return false;
      loadTreesFromData(d.t);
      return true;
    } catch {
      return false;
    }
  }

  const HISTORY_MAX = 50;
  let history = [];
  let historyIndex = -1;
  let historyLock = false;

  function captureState() {
    return {
      h: Array.from(heights),
      w: Array.from(water),
      wy: Array.from(waterY),
      gm: Array.from(groundMat),
      hd: Array.from(highwayDeckH),
      ag: Array.from(areaGrid),
      a: areas.map((x) => ({ id: x.id, slug: x.slug, name: x.name, color: x.color })),
      curArea: currentAreaId,
      s: spots.map((s) => {
        const n = worldToNorm(s.x, s.z);
        return { name: s.name, slug: s.slug, x: n.x, z: n.z };
      }),
      t: trees.map((tr) => treePayload(tr)),
    };
  }

  function statesEqual(a, b) {
    if (!a || !b || a.h.length !== b.h.length) return false;
    for (let i = 0; i < a.h.length; i++) {
      if (a.h[i] !== b.h[i] || a.w[i] !== b.w[i]) return false;
    }
    const gmA = a.gm || [];
    const gmB = b.gm || [];
    if (gmA.length !== gmB.length) return false;
    for (let i = 0; i < gmA.length; i++) {
      if (gmA[i] !== gmB[i]) return false;
    }
    const hdA = a.hd || [];
    const hdB = b.hd || [];
    if (hdA.length !== hdB.length) return false;
    for (let i = 0; i < hdA.length; i++) {
      if (hdA[i] !== hdB[i]) return false;
    }
    const wyA = a.wy || [];
    const wyB = b.wy || [];
    if (wyA.length !== wyB.length) return false;
    for (let i = 0; i < wyA.length; i++) {
      if (wyA[i] !== wyB[i]) return false;
    }
    const agA = a.ag || [];
    const agB = b.ag || [];
    if (agA.length !== agB.length) return false;
    for (let i = 0; i < agA.length; i++) {
      if (agA[i] !== agB[i]) return false;
    }
    const arA = a.a || [];
    const arB = b.a || [];
    if (arA.length !== arB.length) return false;
    for (let i = 0; i < arA.length; i++) {
      const aa = arA[i];
      const ab = arB[i];
      if (aa.id !== ab.id || aa.slug !== ab.slug || aa.name !== ab.name || aa.color !== ab.color) return false;
    }
    if ((a.curArea || 0) !== (b.curArea || 0)) return false;
    if (a.s.length !== b.s.length) return false;
    for (let i = 0; i < a.s.length; i++) {
      const sa = a.s[i];
      const sb = b.s[i];
      if (sa.slug !== sb.slug || sa.x !== sb.x || sa.z !== sb.z || sa.name !== sb.name) return false;
    }
    const ta = a.t || [];
    const tb = b.t || [];
    if (ta.length !== tb.length) return false;
    for (let i = 0; i < ta.length; i++) {
      const aa = ta[i];
      const ab = tb[i];
      if (
        aa.id !== ab.id ||
        aa.x !== ab.x ||
        aa.z !== ab.z ||
        aa.h !== ab.h ||
        aa.w !== ab.w ||
        aa.s !== ab.s ||
        aa.fc !== ab.fc ||
        aa.tc !== ab.tc
      ) {
        return false;
      }
    }
    return true;
  }

  function applyState(state) {
    if (!state || state.h.length !== N) return;
    historyLock = true;
    for (let i = 0; i < N; i++) {
      heights[i] = state.h[i] || 0;
      water[i] = state.w[i] || 0;
      waterY[i] = state.wy?.[i] || 0;
      groundMat[i] = state.gm?.[i] || 0;
      highwayDeckH[i] = state.hd?.[i] || 0;
      areaGrid[i] = state.ag?.[i] || 0;
    }
    areas = (state.a || []).map((x) => ({
      id: x.id,
      slug: x.slug,
      name: x.name,
      color: x.color,
    }));
    currentAreaId = state.curArea || areas[0]?.id || 0;
    refreshAreaUI();
    clearSpots();
    for (const s of state.s || []) {
      const w = normToWorld(s.x, s.z);
      addSpot(w.x, w.z, s.name, s.slug);
    }
    loadTreesFromData(state.t || []);
    waterDirty = true;
    applyHeights();
    historyLock = false;
    updateHistoryButtons();
  }

  function pushHistory() {
    if (historyLock || !heights) return;
    const snap = captureState();
    if (historyIndex >= 0 && statesEqual(snap, history[historyIndex])) return;
    if (historyIndex < history.length - 1) {
      history = history.slice(0, historyIndex + 1);
    }
    history.push(snap);
    if (history.length > HISTORY_MAX) history.shift();
    historyIndex = history.length - 1;
    updateHistoryButtons();
  }

  function initHistory() {
    history = [];
    historyIndex = -1;
    historyLock = false;
    pushHistory();
  }

  function undo() {
    if (historyIndex <= 0) return;
    historyIndex--;
    applyState(history[historyIndex]);
    setStatus('1つ戻りました', 1000);
  }

  function redo() {
    if (historyIndex >= history.length - 1) return;
    historyIndex++;
    applyState(history[historyIndex]);
    setStatus('1つ進みました', 1000);
  }

  function updateHistoryButtons() {
    const undoBtn = document.getElementById('world-map-undo');
    const redoBtn = document.getElementById('world-map-redo');
    if (undoBtn) undoBtn.disabled = historyIndex <= 0;
    if (redoBtn) redoBtn.disabled = historyIndex >= history.length - 1;
  }

  function brushFalloff(d, radius) {
    if (d >= radius) return 0;
    const t = d / radius;
    return Math.cos(t * Math.PI * 0.5);
  }

  function smoothRegion(cx, cz, radius) {
    const temp = new Float32Array(heights);
    const cols = SEG + 1;
    for (let i = 0; i < N; i++) {
      const dx = pos.getX(i) - cx;
      const dz = pos.getZ(i) - cz;
      if (Math.hypot(dx, dz) > radius) continue;
      const gx = i % cols;
      const gz = Math.floor(i / cols);
      let sum = 0;
      let count = 0;
      for (let dz2 = -1; dz2 <= 1; dz2++) {
        for (let dx2 = -1; dx2 <= 1; dx2++) {
          const nx = gx + dx2;
          const nz = gz + dz2;
          if (nx < 0 || nx > SEG || nz < 0 || nz > SEG) continue;
          sum += temp[nz * cols + nx];
          count++;
        }
      }
      heights[i] = sum / count;
    }
  }

  function sculptAt(p, dir) {
    if (dir === 'dig') {
      sculptDigAt(p);
      return;
    }
    if (dir === 'ground') {
      sculptGroundAt(p);
      return;
    }
    if (dir === 'road') {
      paintRoadAt(p);
      return;
    }
    if (dir === 'highway') {
      paintHighwayAt(p);
      return;
    }
    if (dir === 'water') {
      paintWaterAt(p);
      return;
    }
    const radius = brushRadius;
    for (let i = 0; i < N; i++) {
      const dx = pos.getX(i) - p.x;
      const dz = pos.getZ(i) - p.z;
      const d = Math.hypot(dx, dz);
      if (d < radius) {
        const f = brushFalloff(d, radius);
        if (dir === 'raise') {
          heights[i] += brushStrength() * f;
          if (water[i] > 0.5) waterDirty = true;
          water[i] = 0;
          waterY[i] = 0;
          if (f > 0.25) groundMat[i] = 0;
        } else if (dir === 'lower') {
          heights[i] = Math.max(-30 * reliefScale(), heights[i] - brushStrength() * f);
        } else if (dir === 'erase') {
          const t = Math.min(1, f * 1.35);
          if (t >= 0.08) {
            heights[i] = heights[i] * (1 - t);
            water[i] = water[i] * (1 - t);
            // 深い川床でも確実に消えるよう、一定以上なら平地(0)に戻す
            if (t > 0.22) {
              heights[i] = 0;
              water[i] = 0;
              waterY[i] = 0;
              groundMat[i] = 0;
              highwayDeckH[i] = 0;
              areaGrid[i] = 0;
            } else if (t > 0.12) {
              waterY[i] = 0;
              groundMat[i] = 0;
              highwayDeckH[i] = 0;
            }
            if (Math.abs(heights[i]) < 0.4) heights[i] = 0;
            if (water[i] < 0.05) {
              water[i] = 0;
              waterY[i] = 0;
            }
            waterDirty = true;
          }
        }
      }
    }
  }

  /** 「川を掘る」：椀型の河床（素材は選択した土/草/コンクリ） */
  function sculptDigAt(p) {
    const radius = riverSculptRadius();
    const cell = terrainCellSize();
    const cols = SEG + 1;
    const gxCenter = gridCoordX(p.x);
    const gzCenter = gridCoordZ(p.z);
    const cr = Math.ceil(radius / cell) + 1;
    const gxi0 = Math.max(0, Math.floor(gxCenter - cr));
    const gxi1 = Math.min(SEG, Math.ceil(gxCenter + cr));
    const gzi0 = Math.max(0, Math.floor(gzCenter - cr));
    const gzi1 = Math.min(SEG, Math.ceil(gzCenter + cr));
    for (let gz = gzi0; gz <= gzi1; gz++) {
      for (let gx = gxi0; gx <= gxi1; gx++) {
        const i = gz * cols + gx;
        const dx = pos.getX(i) - p.x;
        const dz = pos.getZ(i) - p.z;
        const d = Math.hypot(dx, dz);
        if (d >= radius) continue;

        const t = Math.min(1, d / radius);
        const wallStart = 0.72;
        const f = t <= wallStart ? 1 : 1 - (t - wallStart) / (1 - wallStart);
        heights[i] = Math.min(heights[i], riverDepthTarget(f));
        if (f > 0.05) groundMat[i] = digMaterial;
      }
    }
  }

  /** 「地面を盛る」：指定高さの平坦な土台＋緩い法面（加算しない） */
  function sculptGroundAt(p) {
    if (groundHeightMeters <= 0) return;
    const radius = groundSculptRadius();
    const cell = terrainCellSize();
    const cols = SEG + 1;
    const gxCenter = gridCoordX(p.x);
    const gzCenter = gridCoordZ(p.z);
    const cr = Math.ceil(radius / cell) + 1;
    const gxi0 = Math.max(0, Math.floor(gxCenter - cr));
    const gxi1 = Math.min(SEG, Math.ceil(gxCenter + cr));
    const gzi0 = Math.max(0, Math.floor(gzCenter - cr));
    const gzi1 = Math.min(SEG, Math.ceil(gzCenter + cr));
    for (let gz = gzi0; gz <= gzi1; gz++) {
      for (let gx = gxi0; gx <= gxi1; gx++) {
        const i = gz * cols + gx;
        const dx = pos.getX(i) - p.x;
        const dz = pos.getZ(i) - p.z;
        const d = Math.hypot(dx, dz);
        if (d >= radius) continue;

        const targetH = groundTargetHeight(d, radius);
        if (targetH == null || targetH <= 0.01) continue;

        heights[i] = Math.max(heights[i], targetH);
        groundMat[i] = MAT_GRASS;
        if (water[i] > 0.5) waterDirty = true;
        water[i] = 0;
        waterY[i] = 0;
      }
    }
  }

  /** 「道路」：高さは変えずアスファルトだけ敷く */
  function paintRoadAt(p) {
    const radius = roadSculptRadius();
    for (let i = 0; i < N; i++) {
      const dx = pos.getX(i) - p.x;
      const dz = pos.getZ(i) - p.z;
      const d = Math.hypot(dx, dz);
      if (d >= radius) continue;
      const f = brushFalloff(d, radius);
      if (f > 0.12) groundMat[i] = MAT_ASPHALT;
    }
  }

  /** 「幹線道路」：路面高さを記録し、立体では高架メッシュで表示 */
  function paintHighwayAt(p) {
    const radius = roadSculptRadius();
    const useDeck = highwayDeckMeters > 0.01;
    for (let i = 0; i < N; i++) {
      const dx = pos.getX(i) - p.x;
      const dz = pos.getZ(i) - p.z;
      const d = Math.hypot(dx, dz);
      if (d >= radius) continue;
      const f = brushFalloff(d, radius);
      if (f > 0.12) {
        groundMat[i] = MAT_HIGHWAY;
        if (useDeck) {
          highwayDeckH[i] = metersToUnits(highwayDeckMeters);
        } else {
          highwayDeckH[i] = 0;
        }
      }
    }
  }

  /** 「水を流す」：水平な水面を塗る（高さは地表からの下がり。セル毎に保存→川ごとに変えられる） */
  function paintWaterAt(p) {
    const radius = waterSculptRadius();
    const cell = terrainCellSize();
    const cols = SEG + 1;
    const surfaceY = flatWaterSurfaceY();
    const gxCenter = gridCoordX(p.x);
    const gzCenter = gridCoordZ(p.z);
    const cr = Math.ceil(radius / cell) + 1;
    const gxi0 = Math.max(0, Math.floor(gxCenter - cr));
    const gxi1 = Math.min(SEG, Math.ceil(gxCenter + cr));
    const gzi0 = Math.max(0, Math.floor(gzCenter - cr));
    const gzi1 = Math.min(SEG, Math.ceil(gzCenter + cr));
    for (let gz = gzi0; gz <= gzi1; gz++) {
      for (let gx = gxi0; gx <= gxi1; gx++) {
        const i = gz * cols + gx;
        const dx = pos.getX(i) - p.x;
        const dz = pos.getZ(i) - p.z;
        const d = Math.hypot(dx, dz);
        if (d < radius) {
          water[i] = 1;
          // 水平な水面：地表から◯m下の絶対Y（U字断面の壁には追従しない）
          waterY[i] = surfaceY;
          waterDirty = true;
        }
      }
    }
  }

  function sculpt(p, dir) {
    sculptAt(p, dir);
    applyHeights();
    updateScaleLegend();
  }

  function sculptStroke(from, to, dir) {
    const isStrokeTool =
      dir === 'dig' || dir === 'water' || dir === 'ground' || dir === 'road' || dir === 'highway';
    const radius =
      dir === 'water'
        ? waterSculptRadius()
        : dir === 'dig'
          ? riverSculptRadius()
          : dir === 'ground'
            ? groundSculptRadius()
            : dir === 'road' || dir === 'highway'
              ? roadSculptRadius()
              : brushRadius;
    const step = isStrokeTool
      ? dir === 'ground'
        ? Math.max(terrainCellSize() * 0.85, radius * 0.5)
        : Math.max(terrainCellSize() * 0.35, radius * 0.4)
      : Math.max(0.5, radius * 0.4);
    const dx = to.x - from.x;
    const dz = to.z - from.z;
    const dist = Math.hypot(dx, dz);
    if (dist < 0.01) {
      sculptAt(to, dir);
    } else {
      const n = Math.ceil(dist / step);
      for (let i = 0; i <= n; i++) {
        const t = i / n;
        sculptAt({ x: from.x + dx * t, z: from.z + dz * t }, dir);
      }
    }
    applyHeights();
    updateScaleLegend();
  }

  let areaBrushRadius = 48;
  let areaEraseMode = false;
  let areaNewColor = AREA_PALETTE[0];

  function paintAreaAt(p, erase) {
    const radius = areaBrushRadius;
    const id = erase ? 0 : currentAreaId;
    if (!erase && !id) return;
    for (let i = 0; i < N; i++) {
      const dx = pos.getX(i) - p.x;
      const dz = pos.getZ(i) - p.z;
      const d = Math.hypot(dx, dz);
      if (d < radius) {
        const f = brushFalloff(d, radius);
        if (f > 0.1) areaGrid[i] = id;
      }
    }
  }

  function paintArea(p, erase) {
    paintAreaAt(p, erase);
    recolor();
  }

  function paintAreaStroke(from, to, erase) {
    const step = Math.max(2, areaBrushRadius * 0.4);
    const dx = to.x - from.x;
    const dz = to.z - from.z;
    const dist = Math.hypot(dx, dz);
    if (dist < 0.01) {
      paintAreaAt(to, erase);
    } else {
      const n = Math.ceil(dist / step);
      for (let i = 0; i <= n; i++) {
        const t = i / n;
        paintAreaAt({ x: from.x + dx * t, z: from.z + dz * t }, erase);
      }
    }
    recolor();
  }

  function refreshAreaUI() {
    const sel = document.getElementById('world-map-area-select');
    if (!sel) return;
    const prev = currentAreaId;
    sel.innerHTML = '';
    const empty = document.createElement('option');
    empty.value = '0';
    empty.textContent = '— 選んでください —';
    sel.appendChild(empty);
    for (const a of areas || []) {
      const opt = document.createElement('option');
      opt.value = String(a.id);
      opt.textContent = a.name;
      sel.appendChild(opt);
    }
    sel.value = String(prev || 0);
    currentAreaId = parseInt(sel.value, 10) || 0;
  }

  function addAreaDef(name, slug, color) {
    const id = areas.length ? Math.max(...areas.map((x) => x.id)) + 1 : 1;
    areas.push({ id, slug, name, color });
    currentAreaId = id;
    refreshAreaUI();
    return id;
  }

  function updateSpotWorldPos(sp, x, z) {
    const idx = nearestIndex(x, z);
    const y = (heights[idx] || 0) + 8 * spotScale();
    sp.x = x;
    sp.z = z;
    sp._y = y;
    sp._m.position.set(x, y, z);
    sp._halo.position.set(x, y, z);
    drawConstellation();
  }

  function pickSpot(e) {
    if (!spots.length) return null;
    const r = renderer.domElement.getBoundingClientRect();
    ndc.x = ((e.clientX - r.left) / r.width) * 2 - 1;
    ndc.y = -((e.clientY - r.top) / r.height) * 2 + 1;
    ray.setFromCamera(ndc, activeCamera);
    const meshes = spots.flatMap((s) => [s._m, s._halo]);
    const hits = ray.intersectObjects(meshes, false);
    if (!hits.length) return null;
    const mesh = hits[0].object;
    return spots.find((s) => s._m === mesh || s._halo === mesh);
  }

  const panelText = {
    raise: '地面をドラッグして山を盛り上げてください',
    lower: '地面をドラッグしてへこませます（微調整）',
    erase: 'ドラッグした範囲を平地に戻します（山・川を消す）',
    dig: 'なぞると椀型の河床を掘ります（素材：土/草/コンクリ）',
    water: '掘った所をなぞると水平な水面が流れます（水幅・水位を調整）',
    ground: '高さを指定してなぞると、草の土台を一定の形で盛ります（加算しない）',
    road: '盛った地面の上をなぞると道を敷きます（高さは変えない）',
    highway: '播但連絡など幹線道路を敷きます（道幅は道路と共通）',
    tree: 'クリックで1本 · なぞると植える · 木をクリックで削除 · 消すでブラシ削除',
    spot: '空き地クリックで登録 · スポットをクリックで削除 · ドラッグで移動',
    area: 'ドラッグで町や区域を塗ってください（消しゴムで消せます）',
    look: 'ドラッグで視点を回す · 十字キーで移動 · Shift+ドラッグでも移動',
  };
  const panelTextPlan = {
    raise: '平面モード：距離感を見ながら山を置いてください',
    lower: '平面モード：へこませます（微調整）',
    erase: '平面モード：なぞった範囲を平地に戻します',
    dig: '平面モード：川のルートを掘ります',
    water: '平面モード：掘った所に水を流します',
    ground: '平面モード：草の地面を微妙に盛ります',
    road: '平面モード：道を敷きます',
    highway: '平面モード：幹線道路を敷きます',
    tree: '平面：クリック/なぞりで植生 · 木クリックで削除',
    spot: '平面：クリックで置く/削除 · ドラッグで移動',
    area: '平面モード：なぞってエリアを塗ります',
    look: 'ドラッグで視点を回す · 十字キーで移動 · Shift+ドラッグでも移動',
  };

  function refreshPanelText() {
    // 常時表示の中央注釈は廃止。案内は setStatus のトースト（3秒）でのみ表示する。
  }

  function setViewMode(mode) {
    if (isKonuiZoned() && currentZoneId && mode === 'plan' && readOnly) return;
    if (isKonuiOverview()) mode = 'plan';
    viewMode = mode;
    document.querySelectorAll('.world-map-view-toggle button').forEach((b) => {
      b.classList.toggle('on', b.dataset.view === mode);
    });
    if (!land) {
      syncKonuiViewToggle();
      updateCam();
      return;
    }
    scene.fog = null;
    wireMesh.material.opacity = mode === 'plan' ? 0.35 : 0.05;
    gridHelper.material.opacity = mode === 'plan' ? 0.45 : 0.15;
    land.material.flatShading = mode === 'plan';
    if (minimapEl) {
      minimapEl.hidden = mode !== '3d' || isKonuiOverview() || (isKonuiZoned() && !!currentZoneId);
    }
    if (zoneContextEl) {
      zoneContextEl.hidden = isKonuiOverview() || !currentZoneId || mode !== '3d';
    }
    if (zoneMarkerGroup) zoneMarkerGroup.visible = isKonuiOverview() && mode === 'plan';
    if (mode !== '3d') closeMinimapModal();
    applyGuideVisibility();
    recolor();
    refreshPanelText();
    updateScaleLegend();
    syncKonuiViewToggle();
    syncKonuiZoneUI();
    syncTreeVisibility();
    syncHighwayViaductVisibility();
    updateZoneLinkPositions();
    updateGuideUI();
    updateCam();
  }

  function setupMinimapCamera() {
    if (!SIZE_X) return;
    const span = Math.max(SIZE_X, SIZE_Z);
    const half = span * 0.52;
    minimapCamera.left = -half;
    minimapCamera.right = half;
    minimapCamera.top = half;
    minimapCamera.bottom = -half;
    minimapCamera.position.set(0, span * 0.65, MAP_OFFSET_Z);
    minimapCamera.up.set(0, 0, -1);
    minimapCamera.lookAt(0, 0, MAP_OFFSET_Z);
    minimapCamera.updateProjectionMatrix();
  }

  function updateMinimapDot(dotEl) {
    if (!dotEl || !SIZE_X) return;
    const bx = mapBoundX();
    const bz = mapBoundZ();
    dotEl.style.left = ((target.x - bx.min) / (bx.max - bx.min)) * 100 + '%';
    dotEl.style.top = ((target.z - bz.min) / (bz.max - bz.min)) * 100 + '%';
  }

  function renderMinimapTo(miniRenderer, px) {
    if (!land || !miniRenderer || !SIZE) return;
    setupMinimapCamera();
    const pr = Math.min(window.devicePixelRatio, 2);
    miniRenderer.setPixelRatio(pr);
    miniRenderer.setSize(px, px, false);
    const restore = [];
    if (guidePlane?.visible) {
      guidePlane.visible = false;
      restore.push(() => {
        guidePlane.visible = true;
      });
    }
    if (riverPreview?.visible) {
      riverPreview.visible = false;
      restore.push(() => {
        riverPreview.visible = true;
      });
    }
    if (scaleMarkerGroup?.visible) {
      scaleMarkerGroup.visible = false;
      restore.push(() => {
        scaleMarkerGroup.visible = true;
      });
    }
    if (shirasagiShadow?.visible) {
      shirasagiShadow.visible = false;
      restore.push(() => {
        shirasagiShadow.visible = true;
      });
    }
    miniRenderer.render(scene, minimapCamera);
    restore.forEach((fn) => fn());
  }

  function renderMinimaps() {
    if (viewMode !== '3d' || !land) return;
    updateMinimapDot(minimapDot);
    if (minimapRenderer) renderMinimapTo(minimapRenderer, MINIMAP_PX);
    if (minimapModalOpen && minimapModalRenderer && minimapModalMode === 'scene') {
      updateMinimapDot(minimapModalDot);
      renderMinimapTo(minimapModalRenderer, MINIMAP_MODAL_PX);
    }
    if (minimapModalOpen && minimapModalMode === 'overview') {
      renderOverviewModal();
    }
  }

  function openMinimapModal() {
    if (viewMode !== '3d') return;
    minimapModalMode = 'scene';
    setMinimapModalPanels('scene');
    if (!minimapModalRenderer && minimapModalCanvas) {
      minimapModalRenderer = new THREE.WebGLRenderer({
        canvas: minimapModalCanvas,
        antialias: true,
        alpha: false,
      });
      minimapModalRenderer.setClearColor(0xe9e1d2, 1);
    }
    minimapModalOpen = true;
    if (minimapModal) minimapModal.hidden = false;
    renderMinimaps();
  }

  function openOverviewModal() {
    if (viewMode !== '3d') return;
    if (!overviewState && currentZoneId) {
      setStatus('全体マップのデータがありません', 3000);
      return;
    }
    if (!overviewMiniLand && overviewState) rebuildOverviewMiniLand();
    if (!overviewState || !overviewMiniLand) {
      setStatus('全体マップを読み込めませんでした', 3000);
      return;
    }
    minimapModalMode = 'overview';
    setMinimapModalPanels('overview');
    ensureOverviewModalRenderer();
    minimapModalOpen = true;
    if (minimapModal) minimapModal.hidden = false;
    renderOverviewModal();
  }

  function onMinimapOpenClick(e) {
    e.preventDefault();
    e.stopPropagation();
    openMinimapModal();
  }

  function onOverviewOpenClick(e) {
    e.preventDefault();
    e.stopPropagation();
    openOverviewModal();
  }

  function closeMinimapModal() {
    minimapModalOpen = false;
    minimapModalMode = 'scene';
    if (minimapModal) minimapModal.hidden = true;
    setMinimapModalPanels('scene');
  }

  if (minimapOpenBtn) {
    minimapOpenBtn.addEventListener('click', onMinimapOpenClick);
    minimapOpenBtn.addEventListener('pointerdown', (e) => e.stopPropagation());
  }
  if (zoneContextOpenBtn) {
    zoneContextOpenBtn.addEventListener('click', onOverviewOpenClick);
    zoneContextOpenBtn.addEventListener('pointerdown', (e) => e.stopPropagation());
  }
  if (minimapModalClose) minimapModalClose.addEventListener('click', closeMinimapModal);
  if (minimapModalBackdrop) minimapModalBackdrop.addEventListener('click', closeMinimapModal);
  addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && minimapModalOpen) closeMinimapModal();
  });

  document.querySelectorAll('.world-map-view-toggle button').forEach((b) => {
    b.onclick = () => setViewMode(b.dataset.view);
  });

  document.querySelectorAll('.world-map-tools button').forEach((b) => {
    b.classList.toggle('on', b.dataset.tool === 'look');
  });
  refreshPanelText();
  syncToolSettingsPanel();

  const toolSettingsClose = document.getElementById('world-map-tool-settings-close');
  const toolSettingsOpenBtn = document.getElementById('world-map-tool-settings-open');
  if (toolSettingsClose) {
    toolSettingsClose.addEventListener('click', () => {
      toolSettingsOpen = false;
      syncToolSettingsPanel();
    });
  }
  if (toolSettingsOpenBtn) {
    toolSettingsOpenBtn.addEventListener('click', () => {
      toolSettingsOpen = true;
      syncToolSettingsPanel();
      syncRiverBrushUI();
      syncBrushUI();
      syncTreeUI();
    });
  }

  document.querySelectorAll('.world-map-tools button').forEach((b) => {
    b.onclick = () => {
      tool = b.dataset.tool;
      document.querySelectorAll('.world-map-tools button').forEach((x) => x.classList.remove('on'));
      b.classList.add('on');
      if (panel) refreshPanelText();
      syncToolSettingsPanel();
      syncRiverBrushUI();
      syncBrushUI();
      syncTreeUI();
      if (!previewToolActive()) hideRiverPreview();
    };
  });

  const areaSelect = document.getElementById('world-map-area-select');
  const areaNewBtn = document.getElementById('world-map-area-new');
  const areaEraseBtn = document.getElementById('world-map-area-erase');
  const areaWidthSlider = document.getElementById('world-map-area-width');
  const areaNewForm = document.getElementById('world-map-area-newform');
  const areaNameInput = document.getElementById('world-map-area-name');
  const areaSlugInput = document.getElementById('world-map-area-slug');
  const areaAddBtn = document.getElementById('world-map-area-add');
  const areaColorsEl = document.getElementById('world-map-area-colors');

  if (areaColorsEl) {
    AREA_PALETTE.forEach((c) => {
      const sw = document.createElement('button');
      sw.type = 'button';
      sw.className = 'world-map-area-swatch';
      sw.style.background = c;
      sw.title = c;
      sw.onclick = () => {
        areaNewColor = c;
        areaColorsEl.querySelectorAll('.world-map-area-swatch').forEach((x) => x.classList.remove('on'));
        sw.classList.add('on');
      };
      if (c === areaNewColor) sw.classList.add('on');
      areaColorsEl.appendChild(sw);
    });
  }

  if (areaSelect) {
    areaSelect.addEventListener('change', () => {
      currentAreaId = parseInt(areaSelect.value, 10) || 0;
    });
  }

  if (areaNewBtn && areaNewForm) {
    areaNewBtn.onclick = () => {
      areaNewForm.hidden = !areaNewForm.hidden;
      if (!areaNewForm.hidden && areaNameInput) areaNameInput.focus();
    };
  }

  if (areaEraseBtn) {
    areaEraseBtn.onclick = () => {
      areaEraseMode = !areaEraseMode;
      areaEraseBtn.classList.toggle('on', areaEraseMode);
    };
  }

  if (areaWidthSlider) {
    areaWidthSlider.addEventListener('input', () => {
      areaBrushRadius = parseInt(areaWidthSlider.value, 10);
    });
    areaBrushRadius = parseInt(areaWidthSlider.value, 10) || 48;
  }

  if (areaAddBtn) {
    areaAddBtn.onclick = () => {
      const name = (areaNameInput?.value || '').trim() || '無名のエリア';
      const slug = (areaSlugInput?.value || '').trim() || slugify(name) || 'area-' + Date.now();
      addAreaDef(name, slug, areaNewColor);
      if (areaNameInput) areaNameInput.value = '';
      if (areaSlugInput) areaSlugInput.value = '';
      if (areaNewForm) areaNewForm.hidden = true;
      setStatus('エリアを追加: ' + name);
    };
  }

  refreshAreaUI();

  const riverSlider = document.getElementById('world-map-river-width');
  if (riverSlider) {
    riverSlider.addEventListener('input', () => {
      riverWidthMeters = parseInt(riverSlider.value, 10) || 2;
      syncRiverRadiusFromMeters();
      syncRiverBrushUI();
    });
  }

  function nudgeRiverWidth(delta) {
    const p = preset();
    const minM = p.riverWidthMinMeters ?? 2;
    const maxM = Math.min(RIVER_WIDTH_MAX, p.riverWidthMaxMeters ?? RIVER_WIDTH_MAX);
    riverWidthMeters = Math.max(minM, Math.min(maxM, Math.round(riverWidthMeters + delta)));
    syncRiverRadiusFromMeters();
    syncRiverBrushUI();
  }

  const riverWidthMinus = document.getElementById('world-map-river-width-minus');
  const riverWidthPlus = document.getElementById('world-map-river-width-plus');
  if (riverWidthMinus) riverWidthMinus.addEventListener('click', () => nudgeRiverWidth(-1));
  if (riverWidthPlus) riverWidthPlus.addEventListener('click', () => nudgeRiverWidth(1));

  const waterWidthSlider = document.getElementById('world-map-water-width');
  if (waterWidthSlider) {
    waterWidthSlider.addEventListener('input', () => {
      waterWidthMeters = parseInt(waterWidthSlider.value, 10) || 2;
      syncWaterRadiusFromMeters();
      syncRiverBrushUI();
    });
  }

  function nudgeWaterWidth(delta) {
    const minM = waterWidthMinMeters();
    const maxM = waterWidthMaxMeters();
    waterWidthMeters = Math.max(minM, Math.min(maxM, Math.round(waterWidthMeters + delta)));
    syncWaterRadiusFromMeters();
    syncRiverBrushUI();
  }

  const waterWidthMinus = document.getElementById('world-map-water-width-minus');
  const waterWidthPlus = document.getElementById('world-map-water-width-plus');
  if (waterWidthMinus) waterWidthMinus.addEventListener('click', () => nudgeWaterWidth(-1));
  if (waterWidthPlus) waterWidthPlus.addEventListener('click', () => nudgeWaterWidth(1));

  // 盛る/へこます/消す のブラシ幅
  function applyBrushMeters(m) {
    const maxM = brushMaxMeters();
    brushMeters = Math.max(2, Math.min(maxM, Math.round(m)));
    syncBrushRadiusFromMeters();
    syncBrushUI();
    updateRiverPreviewScale();
  }
  function nudgeBrush(dir) {
    const step = Math.max(1, Math.round(brushMeters * 0.12));
    applyBrushMeters(brushMeters + dir * step);
  }
  const brushSlider = document.getElementById('world-map-brush-size');
  if (brushSlider) {
    brushSlider.addEventListener('input', () => applyBrushMeters(parseInt(brushSlider.value, 10) || 2));
  }
  const brushMinus = document.getElementById('world-map-brush-minus');
  const brushPlus = document.getElementById('world-map-brush-plus');
  if (brushMinus) brushMinus.addEventListener('click', () => nudgeBrush(-1));
  if (brushPlus) brushPlus.addEventListener('click', () => nudgeBrush(1));

  const RIVER_DEPTH_MIN = 0.5;
  const RIVER_DEPTH_MAX = 8;
  const RIVER_DEPTH_STEP = 0.5;

  function setRiverDepth(v) {
    riverDepthMeters = Math.max(RIVER_DEPTH_MIN, Math.min(RIVER_DEPTH_MAX, Math.round(v / RIVER_DEPTH_STEP) * RIVER_DEPTH_STEP));
    syncRiverBrushUI();
  }

  const riverDepthSlider = document.getElementById('world-map-river-depth');
  if (riverDepthSlider) {
    riverDepthSlider.addEventListener('input', () => {
      setRiverDepth(parseFloat(riverDepthSlider.value) || RIVER_DEPTH_MIN);
    });
  }
  const riverDepthMinus = document.getElementById('world-map-river-depth-minus');
  const riverDepthPlus = document.getElementById('world-map-river-depth-plus');
  if (riverDepthMinus) riverDepthMinus.addEventListener('click', () => setRiverDepth(riverDepthMeters - RIVER_DEPTH_STEP));
  if (riverDepthPlus) riverDepthPlus.addEventListener('click', () => setRiverDepth(riverDepthMeters + RIVER_DEPTH_STEP));

  function setDigMaterial(id) {
    digMaterial = id;
    syncRiverBrushUI();
  }
  document.querySelectorAll('.world-map-mat-btn').forEach((b) => {
    b.addEventListener('click', () => setDigMaterial(parseInt(b.dataset.mat, 10) || MAT_EARTH));
  });

  function setGroundHeight(v) {
    groundHeightMeters = Math.max(
      GROUND_HEIGHT_MIN,
      Math.min(GROUND_HEIGHT_MAX, Math.round(v / GROUND_HEIGHT_STEP) * GROUND_HEIGHT_STEP),
    );
    syncRiverBrushUI();
  }
  const groundHeightSlider = document.getElementById('world-map-ground-height');
  if (groundHeightSlider) {
    groundHeightSlider.addEventListener('input', () => {
      setGroundHeight(parseFloat(groundHeightSlider.value) || GROUND_HEIGHT_MIN);
    });
  }
  const groundHeightMinus = document.getElementById('world-map-ground-height-minus');
  const groundHeightPlus = document.getElementById('world-map-ground-height-plus');
  if (groundHeightMinus) {
    groundHeightMinus.addEventListener('click', () => setGroundHeight(groundHeightMeters - GROUND_HEIGHT_STEP));
  }
  if (groundHeightPlus) {
    groundHeightPlus.addEventListener('click', () => setGroundHeight(groundHeightMeters + GROUND_HEIGHT_STEP));
  }

  function applyGroundBrushMeters(m) {
    const maxM = groundBrushMaxMeters();
    groundBrushMeters = Math.max(GROUND_BRUSH_MIN, Math.min(maxM, Math.round(m)));
    syncGroundRadiusFromMeters();
    syncRiverBrushUI();
    updateRiverPreviewScale();
  }
  function nudgeGroundBrush(delta) {
    applyGroundBrushMeters(groundBrushMeters + delta);
  }
  const groundSlider = document.getElementById('world-map-ground-width');
  if (groundSlider) {
    groundSlider.addEventListener('input', () => {
      applyGroundBrushMeters(parseInt(groundSlider.value, 10) || GROUND_BRUSH_MIN);
    });
  }
  const groundMinus = document.getElementById('world-map-ground-width-minus');
  const groundPlus = document.getElementById('world-map-ground-width-plus');
  if (groundMinus) groundMinus.addEventListener('click', () => nudgeGroundBrush(-2));
  if (groundPlus) groundPlus.addEventListener('click', () => nudgeGroundBrush(2));

  function setRoadWidth(v) {
    roadWidthMeters = Math.max(ROAD_WIDTH_MIN, Math.min(roadWidthMaxMeters(), Math.round(v)));
    syncRoadRadiusFromMeters();
    syncRiverBrushUI();
    rebuildHighwayViaduct();
  }
  const roadSlider = document.getElementById('world-map-road-width');
  if (roadSlider) {
    roadSlider.addEventListener('input', () => {
      setRoadWidth(parseInt(roadSlider.value, 10) || ROAD_WIDTH_MIN);
    });
  }
  const roadMinus = document.getElementById('world-map-road-width-minus');
  const roadPlus = document.getElementById('world-map-road-width-plus');
  if (roadMinus) roadMinus.addEventListener('click', () => setRoadWidth(roadWidthMeters - 1));
  if (roadPlus) roadPlus.addEventListener('click', () => setRoadWidth(roadWidthMeters + 1));

  const roadColorInput = document.getElementById('world-map-road-color');
  if (roadColorInput) {
    roadColorInput.addEventListener('input', () => {
      roadStyles.roadColor = roadColorInput.value;
      applyHexToColor(roadStyles.roadColor, cMatAsphalt);
      saveRoadStyles();
      recolor();
    });
  }
  const highwayColorInput = document.getElementById('world-map-highway-color');
  if (highwayColorInput) {
    highwayColorInput.addEventListener('input', () => {
      roadStyles.highwayColor = highwayColorInput.value;
      applyHexToColor(roadStyles.highwayColor, cMatHighway);
      saveRoadStyles();
      recolor();
      rebuildHighwayViaduct();
    });
  }
  const highwayGirderColorInput = document.getElementById('world-map-highway-girder-color');
  if (highwayGirderColorInput) {
    highwayGirderColorInput.addEventListener('input', () => {
      roadStyles.highwayGirderColor = highwayGirderColorInput.value;
      saveRoadStyles();
      rebuildHighwayViaduct();
    });
  }
  const highwayDeckSlider = document.getElementById('world-map-highway-deck');
  function setHighwayDeck(v) {
    highwayDeckMeters = Math.max(
      HIGHWAY_DECK_MIN,
      Math.min(HIGHWAY_DECK_MAX, Math.round(v / HIGHWAY_DECK_STEP) * HIGHWAY_DECK_STEP),
    );
    roadStyles.highwayDeckMeters = highwayDeckMeters;
    saveRoadStyles();
    syncRoadStyleUI();
    const legendRiver = document.getElementById('world-map-river-scale-hint');
    if (legendRiver && tool === 'highway') legendRiver.textContent = highwayLegendText();
  }
  if (highwayDeckSlider) {
    highwayDeckSlider.addEventListener('input', () => {
      setHighwayDeck(parseInt(highwayDeckSlider.value, 10) || HIGHWAY_DECK_DEFAULT);
    });
  }
  const highwayDeckMinus = document.getElementById('world-map-highway-deck-minus');
  const highwayDeckPlus = document.getElementById('world-map-highway-deck-plus');
  if (highwayDeckMinus) highwayDeckMinus.addEventListener('click', () => setHighwayDeck(highwayDeckMeters - HIGHWAY_DECK_STEP));
  if (highwayDeckPlus) highwayDeckPlus.addEventListener('click', () => setHighwayDeck(highwayDeckMeters + HIGHWAY_DECK_STEP));
  const highwayOutlineInput = document.getElementById('world-map-highway-outline');
  if (highwayOutlineInput) {
    highwayOutlineInput.addEventListener('change', () => {
      roadStyles.highwayOutline = highwayOutlineInput.checked;
      saveRoadStyles();
      recolor();
    });
  }
  syncRoadStyleUI();

  function setTreeHeight(v) {
    treeHeightMeters = Math.max(TREE_HEIGHT_MIN, Math.min(TREE_HEIGHT_MAX, Math.round(v)));
    syncTreeUI();
  }
  function setTreeCrown(v) {
    treeCrownMeters = Math.max(TREE_CROWN_MIN, Math.min(TREE_CROWN_MAX, Math.round(v)));
    syncTreeUI();
  }
  function setTreeBrush(v) {
    treeBrushMeters = Math.max(TREE_BRUSH_MIN, Math.min(TREE_BRUSH_MAX, Math.round(v)));
    syncTreeRadiusFromMeters();
    syncTreeUI();
  }
  const treeHeightSlider = document.getElementById('world-map-tree-height');
  if (treeHeightSlider) {
    treeHeightSlider.addEventListener('input', () => setTreeHeight(parseInt(treeHeightSlider.value, 10) || TREE_HEIGHT_MIN));
  }
  const treeHeightMinus = document.getElementById('world-map-tree-height-minus');
  const treeHeightPlus = document.getElementById('world-map-tree-height-plus');
  if (treeHeightMinus) treeHeightMinus.addEventListener('click', () => setTreeHeight(treeHeightMeters - 1));
  if (treeHeightPlus) treeHeightPlus.addEventListener('click', () => setTreeHeight(treeHeightMeters + 1));
  const treeCrownSlider = document.getElementById('world-map-tree-crown');
  if (treeCrownSlider) {
    treeCrownSlider.addEventListener('input', () => setTreeCrown(parseInt(treeCrownSlider.value, 10) || TREE_CROWN_MIN));
  }
  const treeCrownMinus = document.getElementById('world-map-tree-crown-minus');
  const treeCrownPlus = document.getElementById('world-map-tree-crown-plus');
  if (treeCrownMinus) treeCrownMinus.addEventListener('click', () => setTreeCrown(treeCrownMeters - 1));
  if (treeCrownPlus) treeCrownPlus.addEventListener('click', () => setTreeCrown(treeCrownMeters + 1));
  const treeBrushSlider = document.getElementById('world-map-tree-brush');
  if (treeBrushSlider) {
    treeBrushSlider.addEventListener('input', () => setTreeBrush(parseInt(treeBrushSlider.value, 10) || TREE_BRUSH_MIN));
  }
  const treeBrushMinus = document.getElementById('world-map-tree-brush-minus');
  const treeBrushPlus = document.getElementById('world-map-tree-brush-plus');
  if (treeBrushMinus) treeBrushMinus.addEventListener('click', () => setTreeBrush(treeBrushMeters - 1));
  if (treeBrushPlus) treeBrushPlus.addEventListener('click', () => setTreeBrush(treeBrushMeters + 1));
  const treeFoliageInput = document.getElementById('world-map-tree-foliage-color');
  if (treeFoliageInput) {
    treeFoliageInput.addEventListener('input', () => {
      treeFoliageColor = treeFoliageInput.value;
      syncTreeUI();
    });
  }
  const treeTrunkInput = document.getElementById('world-map-tree-trunk-color');
  if (treeTrunkInput) {
    treeTrunkInput.addEventListener('input', () => {
      treeTrunkColor = treeTrunkInput.value;
      syncTreeUI();
    });
  }
  document.querySelectorAll('.world-map-tree-shape-btn').forEach((b) => {
    b.addEventListener('click', () => {
      treeShape = b.dataset.shape === 'pointed' ? 'pointed' : 'round';
      syncTreeUI();
    });
  });
  const treeEraseBtn = document.getElementById('world-map-tree-erase');
  if (treeEraseBtn) {
    treeEraseBtn.addEventListener('click', () => {
      treeEraseMode = !treeEraseMode;
      syncTreeUI();
    });
  }
  syncTreeUI();

  // 水位（地表から水面までの下がり m）
  function setWaterLevel(v) {
    const snapped = Math.round(v / WATER_LEVEL_STEP) * WATER_LEVEL_STEP;
    riverWaterLevelMeters = Math.max(
      WATER_LEVEL_MIN,
      Math.min(WATER_LEVEL_MAX, Math.round(snapped * 10) / 10),
    );
    syncRiverBrushUI();
  }
  const waterLevelSlider = document.getElementById('world-map-river-waterlevel');
  if (waterLevelSlider) {
    waterLevelSlider.addEventListener('input', () => {
      setWaterLevel(parseFloat(waterLevelSlider.value) || WATER_LEVEL_MIN);
    });
  }
  const waterLevelMinus = document.getElementById('world-map-river-waterlevel-minus');
  const waterLevelPlus = document.getElementById('world-map-river-waterlevel-plus');
  if (waterLevelMinus)
    waterLevelMinus.addEventListener('click', () => setWaterLevel(riverWaterLevelMeters - WATER_LEVEL_STEP));
  if (waterLevelPlus)
    waterLevelPlus.addEventListener('click', () => setWaterLevel(riverWaterLevelMeters + WATER_LEVEL_STEP));

  const presetSelect = document.getElementById('world-map-preset');
  if (presetSelect) {
    presetSelect.addEventListener('change', () => {
      switchWorldPreset(presetSelect.value);
    });
    presetSelect.value = currentPresetId;
  }

  const presetPrevBtn = document.getElementById('world-map-preset-prev');
  const presetNextBtn = document.getElementById('world-map-preset-next');
  if (presetPrevBtn) presetPrevBtn.addEventListener('click', () => switchPresetStep(-1));
  if (presetNextBtn) presetNextBtn.addEventListener('click', () => switchPresetStep(1));
  syncPresetNav();

  const guideToggleBtn = document.getElementById('world-map-guide-toggle');
  if (guideToggleBtn) {
    guideToggleBtn.addEventListener('click', () => {
      guideVisible = !guideVisible;
      if (guideVisible && viewMode !== 'plan') setViewMode('plan');
      applyGuideVisibility();
      updateGuideUI();
    });
  }
  const guideOpacitySlider = document.getElementById('world-map-guide-opacity');
  if (guideOpacitySlider) {
    guideOpacitySlider.addEventListener('input', () => {
      guideOpacity = (parseInt(guideOpacitySlider.value, 10) || 50) / 100;
      applyGuideVisibility();
    });
  }
  const zoneTraceFile = document.getElementById('world-map-zone-trace-file');
  if (zoneTraceFile) {
    zoneTraceFile.addEventListener('change', () => {
      const file = zoneTraceFile.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') applyZoneTraceImage(reader.result);
        zoneTraceFile.value = '';
      };
      reader.readAsDataURL(file);
    });
  }
  const zoneTraceClearBtn = document.getElementById('world-map-zone-trace-clear');
  if (zoneTraceClearBtn) {
    zoneTraceClearBtn.addEventListener('click', () => {
      if (!isZoneTraceMode()) return;
      clearZoneTraceStorage();
      guideVisible = false;
      buildGuidePlane();
      updateGuideUI();
      setStatus('ブロックの下絵を削除しました', 3000);
    });
  }
  if (!readOnly) {
    document.addEventListener('paste', (e) => {
      if (!isZoneTraceMode()) return;
      const items = e.clipboardData?.items;
      if (!items) return;
      for (const item of items) {
        if (!item.type.startsWith('image/')) continue;
        const file = item.getAsFile();
        if (!file) continue;
        e.preventDefault();
        const reader = new FileReader();
        reader.onload = () => {
          if (typeof reader.result === 'string') applyZoneTraceImage(reader.result);
        };
        reader.readAsDataURL(file);
        break;
      }
    });
  }
  updateGuideUI();

  const ray = new THREE.Raycaster();
  const ndc = new THREE.Vector2();
  const _pickPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0);
  const _pickFallback = new THREE.Vector3();

  function pickGround(e) {
    if (!land) return null;
    const r = renderer.domElement.getBoundingClientRect();
    ndc.x = ((e.clientX - r.left) / r.width) * 2 - 1;
    ndc.y = -((e.clientY - r.top) / r.height) * 2 + 1;
    ray.setFromCamera(ndc, activeCamera);
    const hit = ray.intersectObject(land, false);
    if (hit.length) return hit[0].point;
    // 画面端でレイがメッシュ外に出ても、地面(Y=0)への交点をマップ内にクランプして編集できるようにする
    if (ray.ray.intersectPlane(_pickPlane, _pickFallback)) {
      const bx = mapBoundX();
      const bz = mapBoundZ();
      _pickFallback.x = Math.max(bx.min, Math.min(bx.max, _pickFallback.x));
      _pickFallback.z = Math.max(bz.min, Math.min(bz.max, _pickFallback.z));
      return _pickFallback.clone();
    }
    return null;
  }

  let painting = false;
  let dragMode = null;
  let sculptCenter = null;
  let lastSculptTool = null;
  let lastPaintPos = null;
  let draggingSpot = null;
  let spotDragMoved = false;
  let spotClickAt = null;

  renderer.domElement.addEventListener('contextmenu', (e) => e.preventDefault());

  renderer.domElement.addEventListener('mousedown', (e) => {
    const panDrag = e.button === 1 || e.button === 2 || (e.button === 0 && e.shiftKey);

    if (readOnly) {
      // 平面ビューはドラッグで地図移動、立体ビューはドラッグで角度回転
      dragMode = (panDrag || viewMode === 'plan') ? 'planpan' : 'orbit';
      ox = e.clientX;
      oy = e.clientY;
      if (panDrag) e.preventDefault();
      return;
    }

    if (panDrag) {
      dragMode = 'planpan';
      ox = e.clientX;
      oy = e.clientY;
      e.preventDefault();
      return;
    }

    if (tool === 'look') {
      // 平面ビューはドラッグで地図移動、立体ビューはドラッグで角度回転
      dragMode = viewMode === 'plan' ? 'planpan' : 'orbit';
      ox = e.clientX;
      oy = e.clientY;
      return;
    }
    if (tool === 'spot') {
      const sp = pickSpot(e);
      if (sp) {
        draggingSpot = sp;
        spotDragMoved = false;
        spotClickAt = { x: e.clientX, y: e.clientY };
        return;
      }
      const p = pickGround(e);
      if (p) openSpotForm(p, e);
      return;
    }
    if (tool === 'tree') {
      if (!treeEraseMode) {
        const tr = pickTree(e);
        if (tr) {
          removeTree(tr);
          pushHistory();
          return;
        }
      }
      const p = pickGround(e);
      if (p) {
        painting = true;
        lastPaintPos = { x: p.x, z: p.z };
        lastSculptTool = 'tree';
        plantTreeAt(p);
      }
      return;
    }
    if (tool === 'area') {
      if (!areaEraseMode && !currentAreaId) {
        setStatus('エリアを選ぶか「＋ 新規」で作成してください');
        return;
      }
      const p = pickGround(e);
      if (p) {
        painting = true;
        lastPaintPos = { x: p.x, z: p.z };
        sculptCenter = lastPaintPos;
        lastSculptTool = 'area';
        paintArea(p, areaEraseMode);
      }
      return;
    }
    const p = pickGround(e);
    if (p) {
      painting = true;
      lastPaintPos = { x: p.x, z: p.z };
      sculptCenter = lastPaintPos;
      lastSculptTool = tool;
      sculpt(p, tool);
    } else {
      dragMode = 'orbit';
      ox = e.clientX;
      oy = e.clientY;
    }
  });

  window.addEventListener('mousemove', (e) => {
    if (draggingSpot) {
      const p = pickGround(e);
      if (p) {
        updateSpotWorldPos(draggingSpot, p.x, p.z);
        spotDragMoved = true;
      }
      return;
    }
    if (painting) {
      const p = pickGround(e);
      if (p) {
        if (tool === 'area') {
          if (lastPaintPos) {
            paintAreaStroke(lastPaintPos, p, areaEraseMode);
          } else {
            paintArea(p, areaEraseMode);
          }
        } else if (tool === 'tree') {
          if (lastPaintPos) {
            plantTreeStroke(lastPaintPos, p);
          } else {
            plantTreeAt(p);
          }
        } else {
          const dir = tool;
          if (lastPaintPos) {
            sculptStroke(lastPaintPos, p, dir);
          } else {
            sculpt(p, dir);
          }
        }
        lastPaintPos = { x: p.x, z: p.z };
        sculptCenter = lastPaintPos;
      }
      return;
    }
    if (dragMode === 'planpan') {
      applyPanPixels(e.clientX - ox, e.clientY - oy);
      ox = e.clientX;
      oy = e.clientY;
      return;
    }
    if (dragMode === 'orbit') {
      azimuth -= (e.clientX - ox) * 0.005;
      if (viewMode === '3d') {
        polar = Math.max(POLAR_MIN, Math.min(POLAR_MAX, polar - (e.clientY - oy) * 0.004));
      }
      ox = e.clientX;
      oy = e.clientY;
      updateCam();
      updateShirasagiAvatar();
      return;
    }
    if (previewToolActive() && !painting && !draggingSpot) {
      updateRiverPreview(pickGround(e));
    }
  });

  window.addEventListener('mouseup', () => {
    const didSculpt = painting;
    const didSpotDrag = spotDragMoved;
    if (painting && sculptCenter && (lastSculptTool === 'raise' || lastSculptTool === 'lower')) {
      smoothRegion(sculptCenter.x, sculptCenter.z, brushRadius * 1.2);
      applyHeights();
    }
    painting = false;
    dragMode = null;
    sculptCenter = null;
    lastSculptTool = null;
    lastPaintPos = null;
    hideRiverPreview();
    if (draggingSpot) {
      if (!spotDragMoved && tool === 'spot' && spotClickAt) {
        openSpotEditForm(draggingSpot, spotClickAt);
      }
      draggingSpot = null;
      spotDragMoved = false;
      spotClickAt = null;
    }
    if (didSculpt || didSpotDrag) pushHistory();
  });

  renderer.domElement.addEventListener(
    'wheel',
    (e) => {
      e.preventDefault();
      if (viewMode === 'plan') {
        // 指数ズーム（ホイール）。下スクロールで引く・上で寄る
        planZoom = Math.max(
          planZoomMin(),
          Math.min(PLAN_ZOOM_MAX, planZoom * Math.exp(-e.deltaY * 0.0012)),
        );
      } else {
        orbit = Math.max(orbitMin(), Math.min(orbitMax(), orbit * Math.exp(e.deltaY * 0.0012)));
      }
    },
    { passive: false },
  );

  let pendingP = null;
  let editingSpot = null;

  function positionSpotbox(e) {
    if (!spotbox) return;
    spotbox.style.left = Math.min(W() - 240, Math.max(12, e.clientX)) + 'px';
    spotbox.style.top = Math.min(H() - 180, Math.max(12, e.clientY)) + 'px';
  }

  function closeSpotbox() {
    if (!spotbox) return;
    spotbox.style.display = 'none';
    pendingP = null;
    editingSpot = null;
    if (nameInput) nameInput.readOnly = false;
    if (slugInput) {
      slugInput.readOnly = false;
      slugInput.disabled = false;
    }
    if (spotDeleteBtn) spotDeleteBtn.hidden = true;
    const spotOkBtn = document.getElementById('world-map-spot-ok');
    if (spotOkBtn) spotOkBtn.hidden = false;
  }

  function openSpotForm(p, e) {
    editingSpot = null;
    pendingP = p;
    if (!spotbox) return;
    spotbox.style.display = 'flex';
    positionSpotbox(e);
    if (nameInput) {
      nameInput.value = '';
      nameInput.readOnly = false;
    }
    if (slugInput) {
      slugInput.value = '';
      slugInput.readOnly = false;
      slugInput.disabled = false;
    }
    if (spotDeleteBtn) spotDeleteBtn.hidden = true;
    const spotOkBtn = document.getElementById('world-map-spot-ok');
    if (spotOkBtn) {
      spotOkBtn.hidden = false;
      spotOkBtn.textContent = '登録';
    }
    nameInput?.focus();
  }

  function openSpotEditForm(sp, e) {
    editingSpot = sp;
    pendingP = null;
    if (!spotbox) return;
    spotbox.style.display = 'flex';
    positionSpotbox(e);
    if (nameInput) {
      nameInput.value = sp.name;
      nameInput.readOnly = true;
    }
    if (slugInput) {
      slugInput.value = sp.slug;
      slugInput.readOnly = true;
      slugInput.disabled = true;
    }
    if (spotDeleteBtn) spotDeleteBtn.hidden = false;
    const spotOkBtn = document.getElementById('world-map-spot-ok');
    if (spotOkBtn) spotOkBtn.hidden = true;
  }

  function slugify(text) {
    return text
      .trim()
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^a-z0-9-]/g, '')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  }

  const spotOkBtn = document.getElementById('world-map-spot-ok');
  if (spotOkBtn) {
    spotOkBtn.onclick = () => {
      if (!pendingP) return;
      const name = nameInput.value.trim() || '無名のスポット';
      const slug = slugInput.value.trim() || slugify(name) || 'spot-' + Date.now();
      addSpot(pendingP.x, pendingP.z, name, slug);
      closeSpotbox();
      pushHistory();
      if (panel) panel.textContent = 'スポットを登録しました: ' + name;
    };
  }

  if (spotDeleteBtn) {
    spotDeleteBtn.onclick = () => {
      if (!editingSpot) return;
      const label = editingSpot.name || editingSpot.slug;
      if (!confirm('スポット「' + label + '」を削除しますか？\n保存すると Supabase からも消えます。')) return;
      removeSpot(editingSpot);
      closeSpotbox();
      pushHistory();
      setStatus('スポットを削除しました: ' + label);
    };
  }

  if (spotCancelBtn) {
    spotCancelBtn.onclick = () => closeSpotbox();
  }

  if (nameInput) {
    nameInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') spotOkBtn?.click();
    });
  }
  if (slugInput) {
    slugInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') spotOkBtn?.click();
    });
  }

  const target = new THREE.Vector3(0, 0, 0);
  let orbit = preset().orbitDefault;
  let azimuth = 0;
  let polar = 0.95;
  let altitudeOffset = 0;
  let planZoom = 1;
  let ox = 0;
  let oy = 0;

  function groundY(x, z) {
    if (!heights) return 0;
    return heights[nearestIndex(x, z)] || 0;
  }

  function updateCam() {
    const ty = groundY(target.x, target.z);
    if (viewMode === 'plan') {
      const aspect = W() / H();
      const half = (SIZE * 0.58) / planZoom;
      orthoCamera.left = -half * aspect;
      orthoCamera.right = half * aspect;
      orthoCamera.top = half;
      orthoCamera.bottom = -half;
      orthoCamera.position.set(target.x, ty + SIZE * 0.52 + altitudeOffset * 0.3, target.z);
      // 平面ビューは常に北向き固定（立体ビューの角度に連動しない）
      orthoCamera.up.set(0, 0, -1);
      orthoCamera.lookAt(target.x, ty, target.z);
      orthoCamera.updateProjectionMatrix();
      activeCamera = orthoCamera;
    } else {
      const camY = ty + orbit * Math.cos(polar) + altitudeOffset;
      perspCamera.position.set(
        target.x + orbit * Math.sin(polar) * Math.sin(azimuth),
        camY,
        target.z + orbit * Math.sin(polar) * Math.cos(azimuth),
      );
      perspCamera.lookAt(target.x, ty + 12, target.z);
      activeCamera = perspCamera;
    }
  }

  const held = {
    up: false,
    down: false,
    left: false,
    right: false,
    rotateLeft: false,
    rotateRight: false,
    altitudeUp: false,
    altitudeDown: false,
    zoomIn: false,
    zoomOut: false,
  };

  function bindHoldButton(btn, key) {
    const on = (e) => {
      e.preventDefault();
      held[key] = true;
      btn.classList.add('on');
    };
    const off = (e) => {
      e.preventDefault();
      held[key] = false;
      btn.classList.remove('on');
    };
    btn.addEventListener('mousedown', on);
    btn.addEventListener('touchstart', on, { passive: false });
    window.addEventListener('mouseup', off);
    btn.addEventListener('touchend', off);
    btn.addEventListener('mouseleave', off);
  }

  document.querySelectorAll('.world-map-dpad button[data-dir]').forEach((b) => {
    bindHoldButton(b, b.dataset.dir);
  });

  document.querySelectorAll('.world-map-cam-row button[data-cam]').forEach((b) => {
    const camMap = {
      'rotate-left': 'rotateLeft',
      'rotate-right': 'rotateRight',
      'altitude-up': 'altitudeUp',
      'altitude-down': 'altitudeDown',
      'zoom-in': 'zoomIn',
      'zoom-out': 'zoomOut',
    };
    const key = camMap[b.dataset.cam];
    if (key) bindHoldButton(b, key);
  });

  function isTypingTarget() {
    const ae = document.activeElement;
    return ae && (ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA' || ae.isContentEditable);
  }

  const panKeyMap = { ArrowUp: 'up', ArrowDown: 'down', ArrowLeft: 'left', ArrowRight: 'right' };
  const camKeyDown = {
    q: 'rotateLeft',
    Q: 'rotateLeft',
    e: 'rotateRight',
    E: 'rotateRight',
    w: 'altitudeUp',
    W: 'altitudeUp',
    s: 'altitudeDown',
    S: 'altitudeDown',
    '+': 'zoomIn',
    '=': 'zoomIn',
    '-': 'zoomOut',
    _: 'zoomOut',
  };
  const camKeyUp = { ...camKeyDown };

  addEventListener('keydown', (e) => {
    if (isTypingTarget()) return;
    if (panKeyMap[e.key]) {
      held[panKeyMap[e.key]] = true;
      e.preventDefault();
    }
    if (camKeyDown[e.key]) {
      held[camKeyDown[e.key]] = true;
      e.preventDefault();
    }
    if ((e.metaKey || e.ctrlKey) && e.key === 'z' && !e.shiftKey) {
      e.preventDefault();
      undo();
    }
    if ((e.metaKey || e.ctrlKey) && ((e.key === 'z' && e.shiftKey) || e.key === 'y')) {
      e.preventDefault();
      redo();
    }
  });
  addEventListener('keyup', (e) => {
    if (panKeyMap[e.key]) held[panKeyMap[e.key]] = false;
    if (camKeyUp[e.key]) held[camKeyUp[e.key]] = false;
  });

  let statusTimer = null;
  function setStatus(text, duration = 3000) {
    if (onStatus) onStatus(text);
    if (panel) {
      panel.textContent = text;
      panel.classList.add('is-visible');
      if (statusTimer) clearTimeout(statusTimer);
      statusTimer = setTimeout(() => {
        panel.classList.remove('is-visible');
      }, duration);
    }
  }

  function terrainPayload() {
    return {
      world_id: WORLD_ID,
      layer_id: activeLayerId(),
      seg: SEG,
      heights: Array.from(heights),
      water: Array.from(water),
      water_y: Array.from(waterY),
      ground_mat: Array.from(groundMat),
      highway_deck: Array.from(highwayDeckH),
      area_defs: areas.map((x) => ({ id: x.id, slug: x.slug, name: x.name, color: x.color })),
      area_grid: Array.from(areaGrid),
      vegetation: trees.map((tr) => treePayload(tr)),
    };
  }

  function localPayload() {
    return {
      seg: SEG,
      savedAt: Date.now(),
      sizeX: SIZE_X,
      sizeZ: SIZE_Z,
      oz: MAP_OFFSET_Z,
      h: Array.from(heights),
      w: Array.from(water),
      wy: Array.from(waterY),
      gm: Array.from(groundMat),
      hd: Array.from(highwayDeckH),
      ag: Array.from(areaGrid),
      a: areas.map((x) => ({ id: x.id, slug: x.slug, name: x.name, color: x.color })),
      curArea: currentAreaId,
      s: spots.map((s) => {
        const n = worldToNorm(s.x, s.z);
        return { name: s.name, slug: s.slug, x: n.x, z: n.z };
      }),
      t: trees.map((tr) => treePayload(tr)),
    };
  }

  function saveLocal() {
    if (readOnly || !heights) return true;
    try {
      localStorage.setItem(localKey(), JSON.stringify(localPayload()));
      return true;
    } catch (err) {
      console.warn('localStorage save failed', err);
      return false;
    }
  }

  function readLocalData() {
    try {
      let raw = localStorage.getItem(localKey());
      if (!raw && isKonuiZoned() && currentZoneId === KONUI_LEGACY_ZONE_ID) {
        raw = localStorage.getItem(legacyKonuiLocalKey());
      }
      if (!raw && WORLD_ID === 'hime-memory') {
        raw = localStorage.getItem('banshu_world_map_v2');
      }
      if (!raw) return null;
      return JSON.parse(raw);
    } catch {
      return null;
    }
  }

  function applyLocalData(d) {
    if (!d) return false;
    if (d.h) loadTerrainFromArrays(d.h, d.w, d.gm, d.wy, d.hd);
    if (d.ag || d.a) loadAreasFromData(d.a, d.ag);
    if (d.s) {
      clearSpots();
      for (const s of d.s) {
        if (s.x != null && s.z != null && s.x <= 1 && s.z <= 1) {
          const w = normToWorld(s.x, s.z);
          addSpot(w.x, w.z, s.name, s.slug || slugify(s.name));
        } else if (s.x != null && s.z != null) {
          addSpot(s.x, s.z, s.name, s.slug || slugify(s.name));
        }
      }
    }
    if (d.t) loadTreesFromData(d.t);
    return true;
  }

  function tryLoadLocal() {
    return applyLocalData(readLocalData());
  }

  async function saveAll() {
    if (!heights) {
      setStatus('地形が読み込まれていません', 3000);
      return;
    }
    const localOk = saveLocal();
    if (!supabase) {
      setStatus(localOk ? 'ローカルに保存しました（Supabase 未接続）' : '保存失敗: ブラウザの保存容量が足りません');
      return;
    }

    const { data: authData } = await supabase.auth.getSession();
    if (!authData?.session) {
      setStatus(
        localOk ? 'ローカルのみ保存しました（クラウド保存にはログインが必要です）' : '保存失敗: ログインとブラウザ容量を確認してください',
        5000,
      );
      return;
    }

    let { data: savedLayer, error: layerErr } = await supabase
      .from('map_world_layers')
      .upsert(terrainPayload(), { onConflict: 'world_id,layer_id' })
      .select('updated_at')
      .maybeSingle();
    // 新カラム(water_y/ground_mat)が未追加のDBでも保存できるようフォールバック
    let groundMatCloudSaved = true;
    let vegetationCloudSaved = true;
    if (layerErr && /water_y|ground_mat|highway_deck|vegetation|column/i.test(layerErr.message || '')) {
      const payload = terrainPayload();
      delete payload.water_y;
      delete payload.ground_mat;
      delete payload.highway_deck;
      delete payload.vegetation;
      groundMatCloudSaved = false;
      vegetationCloudSaved = false;
      ({ data: savedLayer, error: layerErr } = await supabase
        .from('map_world_layers')
        .upsert(payload, { onConflict: 'world_id,layer_id' })
        .select('updated_at')
        .maybeSingle());
    }
    if (layerErr) {
      setStatus('地形の保存エラー: ' + layerErr.message + (localOk ? '（ローカルには保存済み）' : ''), 5000);
      return;
    }

    // クラウド保存成功時刻をローカルにも記録（次回起動時の比較用）
    if (savedLayer?.updated_at) {
      try {
        const d = localPayload();
        d.savedAt = Date.parse(savedLayer.updated_at) || Date.now();
        localStorage.setItem(localKey(), JSON.stringify(d));
      } catch {
        /* localStorage 容量不足でもクラウド保存は成功 */
      }
    }

    for (const s of spots) {
      const n = worldToNorm(s.x, s.z);
      const { error } = await supabase.from('map_spots').upsert(
        {
          world_id: WORLD_ID,
          layer: activeLayerId(),
          slug: s.slug,
          name: s.name,
          category: 'unknown',
          x: n.x,
          z: n.z,
          link_type: 'none',
          link_ref: null,
        },
        { onConflict: 'world_id,layer,slug' },
      );
      if (error) {
        setStatus('スポット保存エラー (' + s.slug + '): ' + error.message);
        return;
      }
    }

    for (const slug of deletedSpotSlugs) {
      const { error } = await supabase
        .from('map_spots')
        .delete()
        .eq('world_id', WORLD_ID)
        .eq('layer', activeLayerId())
        .eq('slug', slug);
      if (error) {
        setStatus('スポット削除エラー (' + slug + '): ' + error.message);
        return;
      }
    }
    deletedSpotSlugs.length = 0;

    if (!groundMatCloudSaved && !vegetationCloudSaved) {
      setStatus(
        '保存しました（地表素材・植生はローカルのみ。Supabase に ground_mat / vegetation 列が必要です）',
        7000,
      );
      return;
    }
    if (!groundMatCloudSaved) {
      setStatus('保存しました（地表素材・水位はローカルのみ。Supabase に ground_mat 列が必要です）', 7000);
      return;
    }
    if (!vegetationCloudSaved) {
      setStatus('保存しました（植生はローカルのみ。Supabase に vegetation 列が必要です）', 7000);
      return;
    }

    setStatus('保存しました（Supabase + ローカル）');
  }

  const saveBtn = document.getElementById('world-map-save');
  if (saveBtn) saveBtn.onclick = () => saveAll();

  const undoBtn = document.getElementById('world-map-undo');
  if (undoBtn) undoBtn.onclick = () => undo();

  const redoBtn = document.getElementById('world-map-redo');
  if (redoBtn) redoBtn.onclick = () => redo();

  const resetBtn = document.getElementById('world-map-reset');
  if (resetBtn) {
    resetBtn.onclick = () => {
      if (!confirm('地形・スポット・植生・エリアをまっさらに戻します。\n（Supabase 上のデータは削除しません）')) return;
      heights.fill(0);
      water.fill(0);
      waterY.fill(0);
      groundMat.fill(0);
      highwayDeckH.fill(0);
      areaGrid.fill(0);
      areas.length = 0;
      currentAreaId = 0;
      refreshAreaUI();
      applyHeights();
      clearSpots();
      clearTrees();
      deletedSpotSlugs.length = 0;
      pushHistory();
      setStatus('まっさらに戻しました（ローカルのみ）');
      updateScaleLegend();
    };
  }

  function loadAreasFromData(defs, grid) {
    areas = (defs || []).map((x) => ({
      id: x.id,
      slug: x.slug,
      name: x.name,
      color: x.color,
    }));
    if (grid && grid.length) {
      let g = grid;
      if (grid.length !== N) {
        const srcSeg = inferSeg(grid.length);
        g = srcSeg >= 1 ? resampleGrid(grid, srcSeg, 'nearest') : null;
      }
      if (g) for (let i = 0; i < N; i++) areaGrid[i] = Math.round(g[i]) || 0;
    }
    currentAreaId = areas[0]?.id || 0;
    refreshAreaUI();
    recolor();
  }

  function inferSeg(len) {
    const s = Math.round(Math.sqrt(len)) - 1;
    return (s + 1) * (s + 1) === len ? s : -1;
  }

  // 旧解像度の格子データを現在の解像度(SEG)へリサンプル（地形=bilinear / 水・エリア=nearest）
  function resampleGrid(src, srcSeg, mode) {
    const srcCols = srcSeg + 1;
    const dstCols = SEG + 1;
    const out = new Float32Array(dstCols * dstCols);
    for (let gz = 0; gz < dstCols; gz++) {
      const sz = (gz / SEG) * srcSeg;
      const z0 = Math.floor(sz);
      const z1 = Math.min(srcSeg, z0 + 1);
      const tz = sz - z0;
      for (let gx = 0; gx < dstCols; gx++) {
        const sx = (gx / SEG) * srcSeg;
        const x0 = Math.floor(sx);
        const x1 = Math.min(srcSeg, x0 + 1);
        const tx = sx - x0;
        const i = gz * dstCols + gx;
        if (mode === 'nearest') {
          const nx = tx < 0.5 ? x0 : x1;
          const nz = tz < 0.5 ? z0 : z1;
          out[i] = src[nz * srcCols + nx] || 0;
        } else {
          const a = src[z0 * srcCols + x0] || 0;
          const b = src[z0 * srcCols + x1] || 0;
          const c = src[z1 * srcCols + x0] || 0;
          const d = src[z1 * srcCols + x1] || 0;
          const top = a + (b - a) * tx;
          const bot = c + (d - c) * tx;
          out[i] = top + (bot - top) * tz;
        }
      }
    }
    return out;
  }

  function loadTerrainFromArrays(hArr, wArr, matArr, wyArr, hdArr) {
    if (!hArr) return false;
    let h = hArr;
    let w = wArr;
    let m = matArr;
    let wy = wyArr;
    let hd = hdArr;
    if (hArr.length !== N) {
      const srcSeg = inferSeg(hArr.length);
      if (srcSeg < 1) return false;
      h = resampleGrid(hArr, srcSeg, 'bilinear');
      w = wArr && inferSeg(wArr.length) >= 1 ? resampleGrid(wArr, srcSeg, 'nearest') : null;
      m = matArr && inferSeg(matArr.length) >= 1 ? resampleGrid(matArr, srcSeg, 'nearest') : null;
      wy = wyArr && inferSeg(wyArr.length) >= 1 ? resampleGrid(wyArr, srcSeg, 'bilinear') : null;
      hd = hdArr && inferSeg(hdArr.length) >= 1 ? resampleGrid(hdArr, srcSeg, 'bilinear') : null;
    }
    for (let i = 0; i < N; i++) {
      heights[i] = h[i] || 0;
      water[i] = w && w[i] > 0.5 ? 1 : 0;
      groundMat[i] = m ? Math.round(m[i] || 0) : 0;
      waterY[i] = wy ? wy[i] || 0 : 0;
      highwayDeckH[i] = hd ? hd[i] || 0 : 0;
    }
    snapHighwayDeckHeights();
    waterDirty = true;
    applyHeights();
    return true;
  }

  function loadSpotsFromRows(rows) {
    clearSpots();
    for (const row of rows || []) {
      const w = normToWorld(row.x, row.z);
      addSpot(w.x, w.z, row.name || row.slug, row.slug || 'spot');
    }
  }

  function resampleLocalArray(arr, mode) {
    if (!arr) return null;
    let a = arr;
    if (arr.length !== N) {
      const srcSeg = inferSeg(arr.length);
      if (srcSeg < 1) return null;
      a = resampleGrid(arr, srcSeg, mode);
    }
    return a;
  }

  /**
   * クラウド読込後にローカルの地表素材・水位をマージする。
   * 幹線道路(MAT_HIGHWAY=5)など、クラウドに未反映の素材が消えるのを防ぐ。
   */
  function mergeMatWaterYFromLocal(remoteUpdatedAt = 0) {
    if (readOnly) return false;
    try {
      const d = readLocalData();
      if (!d || (!d.gm && !d.wy && !d.hd)) return false;
      const localAt = d.savedAt || 0;
      const preferLocalFull = localAt > remoteUpdatedAt + 500;
      let changed = false;

      const localGm = resampleLocalArray(d.gm, 'nearest');
      if (localGm) {
        for (let i = 0; i < N; i++) {
          const lv = Math.round(localGm[i] || 0);
          const rv = groundMat[i] || 0;
          if (preferLocalFull) {
            if (groundMat[i] !== lv) {
              groundMat[i] = lv;
              changed = true;
            }
            continue;
          }
          if (lv === 0) continue;
          if (rv === 0 || localAt >= remoteUpdatedAt || lv > rv) {
            if (groundMat[i] !== lv) {
              groundMat[i] = lv;
              changed = true;
            }
          }
        }
      }

      const localWy = resampleLocalArray(d.wy, 'bilinear');
      if (localWy) {
        for (let i = 0; i < N; i++) {
          const lv = localWy[i] || 0;
          if (preferLocalFull) {
            if (waterY[i] !== lv) {
              waterY[i] = lv;
              changed = true;
            }
            continue;
          }
          if (lv === 0) continue;
          if (waterY[i] === 0 || localAt >= remoteUpdatedAt) {
            if (waterY[i] !== lv) {
              waterY[i] = lv;
              changed = true;
            }
          }
        }
      }

      const localHd = resampleLocalArray(d.hd, 'bilinear');
      if (localHd) {
        for (let i = 0; i < N; i++) {
          const lv = localHd[i] || 0;
          if (preferLocalFull) {
            if (highwayDeckH[i] !== lv) {
              highwayDeckH[i] = lv;
              changed = true;
            }
            continue;
          }
          if (lv <= 0) continue;
          if (highwayDeckH[i] <= 0 || localAt >= remoteUpdatedAt || lv > highwayDeckH[i]) {
            if (highwayDeckH[i] !== lv) {
              highwayDeckH[i] = lv;
              changed = true;
            }
          }
        }
      }

      if (changed) {
        waterDirty = true;
        applyHeights();
      }
      return changed;
    } catch {
      return false;
    }
  }

  async function fetchMapLayerRow(layerId) {
    const selects = [
      'seg, heights, water, water_y, ground_mat, highway_deck, vegetation, area_defs, area_grid, updated_at',
      'seg, heights, water, water_y, ground_mat, area_defs, area_grid, updated_at',
      'seg, heights, water, area_defs, area_grid, updated_at',
      'seg, heights, water, updated_at',
    ];
    for (const sel of selects) {
      const { data, error } = await supabase
        .from('map_world_layers')
        .select(sel)
        .eq('world_id', WORLD_ID)
        .eq('layer_id', layerId)
        .maybeSingle();
      if (error?.code === 'PGRST116') return null;
      if (error && /water_y|ground_mat|highway_deck|vegetation|area_|column/i.test(error.message || '')) {
        continue;
      }
      if (error) {
        console.warn('map layer fetch', layerId, error.message);
        return null;
      }
      return data;
    }
    return null;
  }

  function applyMapLayerRow(layer) {
    if (!layer?.heights) return 0;
    loadTerrainFromArrays(layer.heights, layer.water, layer.ground_mat, layer.water_y, layer.highway_deck);
    if (layer.area_defs || layer.area_grid) {
      loadAreasFromData(layer.area_defs, layer.area_grid);
    }
    if (layer.vegetation?.length) {
      loadTreesFromData(layer.vegetation);
    }
    return layer.updated_at ? Date.parse(layer.updated_at) : 0;
  }

  async function loadFromSupabase() {
    if (!supabase) return { loaded: false, updatedAt: 0 };

    let loaded = false;
    let updatedAt = 0;

    const layerIds = [activeLayerId()];
    if (
      isKonuiZoned() &&
      currentZoneId === KONUI_LEGACY_ZONE_ID &&
      activeLayerId() !== LAYER_ID
    ) {
      layerIds.push(LAYER_ID);
    }

    for (const layerId of layerIds) {
      const layer = await fetchMapLayerRow(layerId);
      if (!layer?.heights) continue;
      updatedAt = applyMapLayerRow(layer);
      mergeMatWaterYFromLocal(updatedAt);
      mergeTreesFromLocal(updatedAt);
      loaded = true;
      break;
    }

    const { data: spotRows, error: spotErr } = await supabase
      .from('map_spots')
      .select('slug, name, x, z')
      .eq('world_id', WORLD_ID)
      .eq('layer', activeLayerId())
      .order('created_at', { ascending: true });

    if (spotErr) {
      if (!spotErr.message.includes('does not exist')) {
        setStatus('スポット読込: ' + spotErr.message);
      }
    } else if (spotRows && spotRows.length > 0) {
      loadSpotsFromRows(spotRows);
      loaded = true;
    } else if (
      isKonuiZoned() &&
      currentZoneId === KONUI_LEGACY_ZONE_ID &&
      activeLayerId() !== LAYER_ID
    ) {
      const { data: legacySpots } = await supabase
        .from('map_spots')
        .select('slug, name, x, z')
        .eq('world_id', WORLD_ID)
        .eq('layer', LAYER_ID)
        .order('created_at', { ascending: true });
      if (legacySpots?.length) {
        loadSpotsFromRows(legacySpots);
        loaded = true;
      }
    }

    return { loaded, updatedAt };
  }

  async function boot() {
    try {
      if (isKonuiZoned()) {
        migrateKonuiLegacyLocal();
        if (bootZoneParam && findKonuiZone(bootZoneParam)) {
          await showKonuiOverview();
          await enterKonuiZone(bootZoneParam);
          if (readOnly) {
            setStatus(`${currentZoneLabel()} — 立体ビュー`, 5000);
          }
          return;
        }
        await showKonuiOverview();
        syncZoneUrl();
        if (readOnly) {
          setStatus('コヌイの路 — ブロックをタップして立体ビューへ', 5000);
        } else {
          setStatus('コヌイの路 — 平面ビューで編集 · ブロックは右の一覧から', 5000);
        }
        return;
      }
      applyHeights();
      planZoom = preset().planZoomDefault ?? 1;
      planZoom = Math.max(planZoomMin(), planZoom);
      const remote = await loadFromSupabase();
      const local = readOnly ? null : readLocalData();
      const localAt = local?.savedAt || 0;
      if (local && localAt > remote.updatedAt + 500) {
        applyLocalData(local);
      } else if (!remote.loaded && local) {
        applyLocalData(local);
      }
      setViewMode('3d');
      if (!readOnly) initHistory();
    } catch (err) {
      console.error('world-map boot error', err);
      setStatus('読み込みエラー: ' + (err.message || err));
    } finally {
      if (loadingEl) loadingEl.style.display = 'none';
      requestAnimationFrame(tick);
    }
  }

  const marginClampX = (v) => clampMapX(v);
  const marginClampZ = (v) => clampMapZ(v);

  let scaleLegendTick = 0;

  function tick(t) {
    const PAN = viewMode === 'plan' ? 9 : 7;
    const s = Math.sin(azimuth);
    const c = Math.cos(azimuth);

    if (viewMode === 'plan') {
      if (held.up) target.z -= PAN;
      if (held.down) target.z += PAN;
      if (held.left) target.x -= PAN;
      if (held.right) target.x += PAN;
      if (held.zoomIn || held.altitudeUp) {
        planZoom = Math.min(PLAN_ZOOM_MAX, planZoom * PLAN_ZOOM_FACTOR_KEY);
      }
      if (held.zoomOut || held.altitudeDown) {
        planZoom = Math.max(planZoomMin(), planZoom / PLAN_ZOOM_FACTOR_KEY);
      }
    } else {
      if (held.up) {
        target.x -= s * PAN;
        target.z -= c * PAN;
      }
      if (held.down) {
        target.x += s * PAN;
        target.z += c * PAN;
      }
      if (held.left) {
        target.x -= c * PAN;
        target.z += s * PAN;
      }
      if (held.right) {
        target.x += c * PAN;
        target.z -= s * PAN;
      }
      if (held.rotateLeft) azimuth -= AZIMUTH_KEY_STEP;
      if (held.rotateRight) azimuth += AZIMUTH_KEY_STEP;
      if (held.altitudeUp) {
        altitudeOffset = Math.min(ALTITUDE_MAX, altitudeOffset + ALTITUDE_KEY_STEP);
        polar = Math.max(POLAR_MIN, polar - POLAR_KEY_STEP * 0.6);
      }
      if (held.altitudeDown) {
        altitudeOffset = Math.max(ALTITUDE_MIN, altitudeOffset - ALTITUDE_KEY_STEP);
        polar = Math.min(POLAR_MAX, polar + POLAR_KEY_STEP * 0.6);
      }
      if (held.zoomIn) orbit = Math.max(orbitMin(), orbit * ZOOM_FACTOR_KEY);
      if (held.zoomOut) orbit = Math.min(orbitMax(), orbit / ZOOM_FACTOR_KEY);
    }

    target.x = marginClampX(target.x);
    target.z = marginClampZ(target.z);
    updateCam();
    updateScaleMarkerPosition();
    updateShirasagiShadow();
    updateShirasagiAvatar();

    const isMoving = held.up || held.down || held.left || held.right;
    if (shirasagiImg) {
      shirasagiImg.classList.toggle('is-moving', isMoving);
      shirasagiImg.classList.toggle('is-glide', !isMoving && viewMode === '3d');
    }

    scaleLegendTick++;
    if (scaleLegendTick % 45 === 0) updateScaleLegend();

    spots.forEach((sp, i) => {
      const pulse = 0.5 + 0.5 * Math.sin(t / 600 + i);
      sp._halo.scale.setScalar(0.9 + pulse * 0.5);
      sp._halo.material.opacity = 0.12 + pulse * 0.13;
      const v = sp._m.position.clone().project(activeCamera);
      const sx = (v.x * 0.5 + 0.5) * W();
      const sy = (-v.y * 0.5 + 0.5) * H();
      const vis = v.z < 1 && sx > -40 && sx < W() + 40 && sy > -20 && sy < H() + 20;
      sp._el.style.opacity = vis ? '1' : '0';
      sp._el.style.left = sx + 'px';
      sp._el.style.top = sy + 'px';
    });

    renderer.render(scene, activeCamera);
    if (land) renderMinimaps();
    renderOverviewPlanContext();
    updateZoneLinkPositions();
    requestAnimationFrame(tick);
  }

  addEventListener('resize', () => {
    const aspect = W() / H();
    perspCamera.aspect = aspect;
    perspCamera.updateProjectionMatrix();
    renderer.setSize(W(), H());
    updateCam();
  });

  boot();
}
